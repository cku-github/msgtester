var require = meteorInstall({"imports":{"api":{"DepartmentCodes":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/DepartmentCodes/server/publications.js                                                        //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let DepartmentCodes;
module.link("../DepartmentCodes", {
  default(v) {
    DepartmentCodes = v;
  }

}, 2);
Meteor.publish('departmentCodes', function departmentCodes() {
  return DepartmentCodes.find();
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"DepartmentCodes.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/DepartmentCodes/DepartmentCodes.js                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const DepartmentCodes = new Mongo.Collection('DepartmentCodes');
DepartmentCodes.allow({
  insert: () => false,
  update: () => false,
  remove: () => false
});
DepartmentCodes.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});
DepartmentCodes.schema = new SimpleSchema({
  name: String
});
DepartmentCodes.attachSchema(DepartmentCodes.schema);
module.exportDefault(DepartmentCodes);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/DepartmentCodes/methods.js                                                                    //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let DepartmentCodes;
module.link("./DepartmentCodes", {
  default(v) {
    DepartmentCodes = v;
  }

}, 2);
Meteor.methods({
  'departmentCodes.insert': function departmentCodesInsert(departmentCode) {
    check(departmentCode, {
      name: String
    });

    try {
      return DepartmentCodes.insert(departmentCode);
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Documents":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Documents/server/publications.js                                                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Documents;
module.link("../Documents", {
  default(v) {
    Documents = v;
  }

}, 2);
Meteor.publish('documents', function documents() {
  return Documents.find({
    owner: this.userId
  });
}); // Note: documents.view is also used when editing an existing document.

Meteor.publish('documents.view', function documentsView(documentId) {
  check(documentId, String);
  return Documents.find({
    _id: documentId,
    owner: this.userId
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Documents.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Documents/Documents.js                                                                        //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const Documents = new Mongo.Collection('Documents');
Documents.allow({
  insert: () => false,
  update: () => false,
  remove: () => false
});
Documents.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});
Documents.schema = new SimpleSchema({
  owner: {
    type: String,
    label: 'The ID of the user this document belongs to.'
  },
  createdAt: {
    type: String,
    label: 'The date this document was created.',

    autoValue() {
      if (this.isInsert) return new Date().toISOString();
    }

  },
  updatedAt: {
    type: String,
    label: 'The date this document was last updated.',

    autoValue() {
      if (this.isInsert || this.isUpdate) return new Date().toISOString();
    }

  },
  title: {
    type: String,
    label: 'The title of the document.'
  },
  body: {
    type: String,
    label: 'The body of the document.'
  }
});
Documents.attachSchema(Documents.schema);
module.exportDefault(Documents);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Documents/methods.js                                                                          //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _objectSpread2 = _interopRequireDefault(require("@babel/runtime/helpers/objectSpread"));

let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Documents;
module.link("./Documents", {
  default(v) {
    Documents = v;
  }

}, 2);
let rateLimit;
module.link("../../modules/rate-limit", {
  default(v) {
    rateLimit = v;
  }

}, 3);
Meteor.methods({
  'documents.insert': function documentsInsert(doc) {
    check(doc, {
      title: String,
      body: String
    });

    try {
      return Documents.insert((0, _objectSpread2.default)({
        owner: this.userId
      }, doc));
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  },
  'documents.update': function documentsUpdate(doc) {
    check(doc, {
      _id: String,
      title: String,
      body: String
    });

    try {
      const documentId = doc._id;
      Documents.update(documentId, {
        $set: doc
      });
      return documentId; // Return _id so we can redirect to document after update.
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  },
  'documents.remove': function documentsRemove(documentId) {
    check(documentId, String);

    try {
      return Documents.remove(documentId);
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  }
});
rateLimit({
  methods: ['documents.insert', 'documents.update', 'documents.remove'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Formats":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Formats/server/publications.js                                                                //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Formats;
module.link("../Formats", {
  default(v) {
    Formats = v;
  }

}, 2);
Meteor.publish('formats', function formats() {
  return Formats.find();
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Formats.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Formats/Formats.js                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const Formats = new Mongo.Collection('Formats');
Formats.allow({
  insert: () => false,
  update: () => false,
  remove: () => false
});
Formats.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});
Formats.schema = new SimpleSchema({
  name: String
});
Formats.attachSchema(Formats.schema);
module.exportDefault(Formats);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Formats/methods.js                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Formats;
module.link("./Formats", {
  default(v) {
    Formats = v;
  }

}, 2);
Meteor.methods({
  'formats.insert': function formatsInsert(format) {
    check(format, {
      name: String
    });

    try {
      return Formats.insert(format);
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Groups":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Groups/server/publications.js                                                                 //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Groups;
module.link("../Groups", {
  default(v) {
    Groups = v;
  }

}, 2);
Meteor.publish('groups', function groups() {
  return Groups.find();
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Groups.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Groups/Groups.js                                                                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const Groups = new Mongo.Collection('Groups');
Groups.allow({
  insert: () => false,
  update: () => false,
  remove: () => false
});
Groups.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});
Groups.schema = new SimpleSchema({
  name: String
});
Groups.attachSchema(Groups.schema);
module.exportDefault(Groups);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Groups/methods.js                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Groups;
module.link("./Groups", {
  default(v) {
    Groups = v;
  }

}, 2);
Meteor.methods({
  'groups.insert': function groupsInsert(group) {
    check(group, {
      name: String
    });

    try {
      return Groups.insert(group);
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"MessageTypes":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/MessageTypes/server/publications.js                                                           //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let MessageTypes;
module.link("../MessageTypes", {
  default(v) {
    MessageTypes = v;
  }

}, 2);
Meteor.publish('messageTypes', function messageTypes() {
  return MessageTypes.find();
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"MessageTypes.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/MessageTypes/MessageTypes.js                                                                  //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const MessageTypes = new Mongo.Collection('MessageTypes');
MessageTypes.allow({
  insert: () => false,
  update: () => false,
  remove: () => false
});
MessageTypes.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});
MessageTypes.schema = new SimpleSchema({
  name: String
});
MessageTypes.attachSchema(MessageTypes.schema);
module.exportDefault(MessageTypes);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/MessageTypes/methods.js                                                                       //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let MessageTypes;
module.link("./MessageTypes", {
  default(v) {
    MessageTypes = v;
  }

}, 2);
let rateLimit;
module.link("../../modules/rate-limit", {
  default(v) {
    rateLimit = v;
  }

}, 3);
Meteor.methods({
  'messageTypes.insert': function messageTypesInsert(messageType) {
    check(messageType, {
      name: String
    });

    try {
      return MessageTypes.insert(messageType);
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"OAuth":{"server":{"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/OAuth/server/methods.js                                                                       //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let ServiceConfiguration;
module.link("meteor/service-configuration", {
  ServiceConfiguration(v) {
    ServiceConfiguration = v;
  }

}, 2);
let rateLimit;
module.link("../../../modules/rate-limit", {
  default(v) {
    rateLimit = v;
  }

}, 3);
Meteor.methods({
  'oauth.verifyConfiguration': function oauthVerifyConfiguration(services) {
    check(services, Array);

    try {
      const verifiedServices = [];
      services.forEach(service => {
        if (ServiceConfiguration.configurations.findOne({
          service
        })) {
          verifiedServices.push(service);
        }
      });
      return verifiedServices.sort();
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  }
});
rateLimit({
  methods: ['oauth.verifyConfiguration'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"Queues":{"server":{"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Queues/server/publications.js                                                                 //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Queues;
module.link("../Queues", {
  default(v) {
    Queues = v;
  }

}, 2);
Meteor.publish('queues', function queues() {
  return Queues.find();
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Queues.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Queues/Queues.js                                                                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const Queues = new Mongo.Collection('Queues');
Queues.allow({
  insert: () => false,
  update: () => false,
  remove: () => false
});
Queues.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});
Queues.schema = new SimpleSchema({
  name: String
});
Queues.attachSchema(Queues.schema);
module.exportDefault(Queues);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Queues/methods.js                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Queues;
module.link("./Queues", {
  default(v) {
    Queues = v;
  }

}, 2);
let rateLimit;
module.link("../../modules/rate-limit", {
  default(v) {
    rateLimit = v;
  }

}, 3);
Meteor.methods({
  'queues.insert': function queuesInsert(queue) {
    check(queue, {
      name: String
    });

    try {
      return Queues.insert(queue);
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"TestCases":{"server":{"postgres.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/TestCases/server/postgres.js                                                                  //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Pool;
module.link("pg", {
  Pool(v) {
    Pool = v;
  }

}, 1);
let jsdiff;
module.link("diff", {
  default(v) {
    jsdiff = v;
  }

}, 2);
let TestCases;
module.link("../TestCases", {
  default(v) {
    TestCases = v;
  }

}, 3);
let Queues;
module.link("../../Queues/Queues", {
  default(v) {
    Queues = v;
  }

}, 4);
let Groups;
module.link("../../Groups/Groups", {
  default(v) {
    Groups = v;
  }

}, 5);
let MessageTypes;
module.link("../../MessageTypes/MessageTypes", {
  default(v) {
    MessageTypes = v;
  }

}, 6);
let DepartmentCodes;
module.link("../../DepartmentCodes/DepartmentCodes", {
  default(v) {
    DepartmentCodes = v;
  }

}, 7);
let Formats;
module.link("../../Formats/Formats", {
  default(v) {
    Formats = v;
  }

}, 8);
const pool = new Pool(Meteor.settings.private.postgres);
const oldPoolQuery = pool.query;

pool.query = (...args) => {
  console.log('QUERY:', args);
  return oldPoolQuery.apply(pool, args);
};

const fetch = (query, params) => Promise.asyncApply(() => {
  try {
    const client = Promise.await(pool.connect());
    const result = Promise.await(client.query(query, params));
    result.rows.forEach(result => {// NOTE: result here will likely need to be mapped to specific fields in MongoDB instead of a plain dump.
      //  TestCases.insert(result);
    });
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

const updateStatusAndDiffResult = (_id, diffCount) => Promise.asyncApply(() => {
  try {
    const client = Promise.await(pool.connect());
    var query = ``;

    if (diffCount == 0) {
      query = `
        update bus_test_cases
        set c_test_status = 'passed'
        , n_diff_count = ${diffCount}
        , c_notification_sent = ''
        where c_test_case_id = '${_id}'
      `;
    } else {
      query = `
        update bus_test_cases
        set c_test_status = 'failed'
        , n_diff_count = ${diffCount}
        , c_notification_sent = ''
        where c_test_case_id = '${_id}'
      `;
    }

    ;
    console.log("updateStatusAndDiffResult: ", query);
    const result = Promise.await(fetch(query));
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

const updateExpectedResult = (_id, testRunResult) => Promise.asyncApply(() => {
  try {
    const client = Promise.await(pool.connect()); // update bus_test_cases set test_message = $2 where test_case_id = $1;

    const query = `
    update bus_test_cases set
    c_expected_resulttrace = $token$${testRunResult}$token$
    , c_test_status = 'passed'
    , n_diff_count = 0
    , c_notification_sent = ''
    where
    c_test_case_id = '${_id}'
    `;
    console.log("updateExpectedResult: ", query);
    const result = Promise.await(client.query(query));
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

const pollReadyTests = () => Promise.asyncApply(() => {
  try {
    var today = new Date();
    const client = Promise.await(pool.connect());
    const query = `
      select c_test_case_id, coalesce(c_expected_resulttrace, '') as c_expected_resulttrace
      , coalesce(c_test_run_resulttrace, '') as c_test_run_resulttrace
      , coalesce(c_ipclink, '') as c_ipclink
      from bus_test_cases
      where c_test_status = 'ready'
    `;
    const result = Promise.await(client.query(query));
    result.rows.forEach(row => {
      const {
        c_test_case_id: _id,
        c_expected_resulttrace: expectedResult,
        c_test_run_resulttrace: testRunResult,
        c_ipclink: ipcLink
      } = row; //check if there is a MongoRecord to the Postgresql data. If not skip to the next msg

      if (TestCases.findOne(_id)) {
        const mongoExpectedResult = TestCases.findOne(_id).expectedResult;
        console.log('pollReadyTests Timestamp and ID: ', today, _id); // test result is empty, new test case

        if (!expectedResult || !mongoExpectedResult) {
          TestCases.update(_id, {
            $set: {
              testRunResult,
              expectedResult: testRunResult,
              testStatus: 'passed',
              diffCount: 0,
              testStart: today,
              ipcLink
            }
          });
          updateExpectedResult(_id, testRunResult);
        } else {
          // test result is same
          // test result is different
          // const diffCount = diff.filter(part => part.added || part.removed).length;
          //const ignoreWhitespace = true;
          //const newlineIsToken = true;
          console.log('Will now compare mongoExpectedResult with DB testRunResult for ID: ', _id);
          const diff = jsdiff.diffWords(testRunResult.substring(0, 40000) || '', mongoExpectedResult.substring(0, 40000) || ''); //const diff = jsdiff.diffLines(testRunResult.substring(0,40000) || '', mongoExpectedResult.substring(0,40000) || '', ignoreWhitespace, newlineIsToken);

          console.log('compare complete at: ', today);
          let diffCount = 0;
          const result = diff.map(function (part, index) {
            if (part.added || part.removed) {
              diffCount += 1;
            }
          }); //check diffcount == 0 and the length of either the expected result of the actual result is above 40000, compare the two lengths. 
          //If they don't match then report difference

          if (diffCount == 0 && (mongoExpectedResult.length > 40000 || testRunResult.length > 40000 && mongoExpectedResult.length != testRunResult.length)) {
            diffCount = 1;
          }

          ; //update the mongo DB instance

          TestCases.update(_id, {
            $set: {
              testRunResult,
              testStatus: diffCount === 0 ? 'passed' : 'failed',
              diffCount,
              testStart: today,
              ipcLink
            }
          }); //update the Postgresql with the same info

          console.log('call updateStatusAndDiffResult to store diffCount: ', diffCount);
          updateStatusAndDiffResult(_id, diffCount);
        }
      }
    });
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
}); // function to import all data from Postgresql. Deletes all existing data in Mongo.


const loadFromPostgresql = userId => Promise.asyncApply(() => {
  try {
    // define value lists used for checking input data
    var validLineBreaks = ["CR", "CRLF"];
    var validDepartmentCodes = ["cs", "is", "fs", "ss", "dev"];
    const client = Promise.await(pool.connect()); // query to get all test_cases from Postgresql

    const query = `
    select
    c_test_case_id,
    c_test_case_name,
    c_group_name,
    c_message_type,
    c_format,
    c_loading_queue,
    c_test_message,
    c_rhf2_header,
    c_comment,
    c_expected_resulttrace,
    c_test_run_resulttrace,
    c_last_editor,
    n_diff_count,
    n_autotest,
    n_delayed,
    n_runtime_in_sec,
    n_completes_in_ipc,
    c_mqmd_useridentifier,
    c_linebreak,
    c_testid_prefix,
    c_jira_url,
    c_department_code
    from bus_test_cases
    where c_test_message is not null
    `;
    const result = Promise.await(client.query(query)); // delete existing Mongo records
    // delete Queues

    Groups.remove({});
    Queues.remove({});
    MessageTypes.remove({});
    Formats.remove({});
    TestCases.remove({});
    DepartmentCodes.remove({});
    const setGroups = new Set();
    const setQueues = new Set();
    const setMessageTypes = new Set();
    const setFormats = new Set();
    console.log('process each row from Postgresql');
    result.rows.forEach(row => {
      const testCase = {
        _id: row.c_test_case_id,
        owner: userId,
        name: row.c_test_case_name,
        testIdPrefix: row.c_testid_prefix,
        jiraURL: row.c_jira_url,
        group: row.c_group_name,
        messageType: row.c_message_type,
        format: row.c_format,
        loadingQueue: row.c_loading_queue,
        testMessage: row.c_test_message,
        // clob
        testStatus: 'ready',
        rfh2Header: row.c_rhf2_header,
        // clob
        comment: row.c_comment,
        expectedResult: row.c_expected_resulttrace,
        // clob
        testRunResult: row.c_test_run_resulttrace,
        diffCount: row.n_diff_count,
        autoTest: row.n_autotest ? true : false,
        delayedTest: row.n_delayed ? true : false,
        runTimeSec: row.n_runtime_in_sec,
        completesInIpc: row.n_completes_in_ipc ? true : false,
        mqUserIdentifier: row.c_mqmd_useridentifier,
        linefeed: validLineBreaks.includes(row.c_linebreak) ? row.c_linebreak : "CRLF",
        departmentCode: validDepartmentCodes.includes(row.c_department_code) ? row.c_department_code : "dev"
      };
      console.log('testCase: ', testCase);
      TestCases.insert(testCase);
      setGroups.add(row.c_group_name);
      setQueues.add(row.c_loading_queue);
      setMessageTypes.add(row.c_message_type);
      setFormats.add(row.c_format);
    });
    setGroups.forEach(name => Groups.insert({
      name
    }));
    setQueues.forEach(name => Queues.insert({
      name
    }));
    setMessageTypes.forEach(name => MessageTypes.insert({
      name
    }));
    setFormats.forEach(name => Formats.insert({
      name
    })); // Set valid departmentCodes

    DepartmentCodes.insert({
      name: 'cs'
    });
    DepartmentCodes.insert({
      name: 'fs'
    });
    DepartmentCodes.insert({
      name: 'is'
    });
    DepartmentCodes.insert({
      name: 'ss'
    });
    DepartmentCodes.insert({
      name: 'dev'
    });
    console.log('Groups: ', Groups.find({}).fetch());
    console.log('DepartmentCodes: ', DepartmentCodes.find({}).fetch());
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

const insert = testCase => Promise.asyncApply(() => {
  try {
    const client = Promise.await(pool.connect());
    const {
      _id,
      owner,
      name,
      testIdPrefix,
      messageType,
      format,
      loadingQueue,
      runTimeSec,
      testMessage,
      completesInIpc,
      rfh2Header,
      comment,
      group,
      autoTest,
      delayedTest,
      mqUserIdentifier,
      linefeed,
      jiraURL,
      departmentCode
    } = testCase;
    const query = `
      insert into bus_test_cases(
        c_test_case_id, c_test_case_name, c_message_type, c_format,
        c_loading_queue, c_test_message, c_test_status, c_rhf2_header,
        c_comment, c_group_name, c_last_editor, n_runtime_in_sec,
        n_completes_in_ipc, n_autotest, n_delayed, c_mqmd_useridentifier, c_linebreak,
        c_testid_prefix, c_jira_url, c_department_code
      )
      values(
        '${_id}', '${name}', '${messageType}', '${format}',
        '${loadingQueue}', $token$${testMessage}$token$, 'new', $token$${rfh2Header}$token$,
        $token$${comment}$token$, '${group}', '${owner}', ${runTimeSec},
        ${completesInIpc ? 1 : 0}, ${autoTest ? 1 : 0}, ${delayedTest ? 1 : 0},
        '${mqUserIdentifier}', '${linefeed}', '${testIdPrefix}', '${jiraURL}',
        '${departmentCode}'
      );
    `;
    const cleanquery = query.replace(/'undefined',/g, '\'\',');
    console.log('Insert new testcase with:', cleanquery);
    const result = Promise.await(client.query(cleanquery));
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

const update = testCase => Promise.asyncApply(() => {
  try {
    const client = Promise.await(pool.connect());
    const {
      _id,
      owner,
      name,
      testIdPrefix,
      messageType,
      format,
      loadingQueue,
      runTimeSec,
      testMessage,
      testRunResult,
      completesInIpc,
      rfh2Header,
      comment,
      group,
      autoTest,
      delayedTest,
      mqUserIdentifier,
      linefeed,
      jiraURL,
      departmentCode
    } = testCase; // update bus_test_cases set test_message = $2 where test_case_id = $1;

    const query = `
    update bus_test_cases set
    c_test_case_name = '${name}',
    c_message_type = '${messageType}',
    c_format = '${format}',
    c_loading_queue = '${loadingQueue}',
    c_test_message = $token$${testMessage}$token$,
    c_expected_resulttrace = $token$${testRunResult}$token$,
    c_test_status = 'new',
    c_rhf2_header = $token$${rfh2Header}$token$,
    c_comment = $token$${comment}$token$,
    c_group_name = '${group}',
    c_last_editor = '${owner}',
    n_runtime_in_sec = ${runTimeSec},
    n_completes_in_ipc = ${completesInIpc ? 1 : 0},
    n_autotest = ${autoTest ? 1 : 0},
    n_delayed = ${delayedTest ? 1 : 0},
    c_mqmd_useridentifier = '${mqUserIdentifier}',
    c_linebreak = '${linefeed}',
    c_testid_prefix = '${testIdPrefix}',
    c_jira_url = '${jiraURL}',
    c_department_code = '${departmentCode}'
    where
    c_test_case_id = '${_id}'
    `; // enable here to see insert in case of errors

    console.log('Update postgresql with:', query);
    const result = Promise.await(client.query(query));
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

const runTest = testCase => Promise.asyncApply(() => {
  try {
    const client = Promise.await(pool.connect());
    const {
      _id,
      owner
    } = testCase;
    const query = `
    update bus_test_cases set
    c_test_status = 'run',
    c_last_editor = '${owner}',
    d_test_time = statement_timestamp()
    where
    c_test_case_id = '${_id}'
    `;
    console.log('Runtest with update:', query);
    const result = Promise.await(client.query(query));
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

const runTestsFiltered = ({
  group,
  loadingQueue,
  messageType,
  owner,
  departmentCode
}) => Promise.asyncApply(() => {
  try {
    const client = Promise.await(pool.connect());
    let query = `
    update bus_test_cases set
    c_test_status = 'run',
    c_last_editor = '${owner}',
    d_test_time = statement_timestamp()
    where 1 = 1
    `;

    if (group) {
      query += ` AND c_group_name = '${group}'`;
    }

    if (loadingQueue) {
      query += ` AND c_loading_queue = '${loadingQueue}'`;
    }

    if (messageType) {
      query += ` AND c_message_type = '${messageType}'`;
    }

    if (departmentCode) {
      query += ` AND c_department_code = '${departmentCode}'`;
    }

    console.log('RuntestFiltered with update:', query);
    const result = Promise.await(client.query(query));
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

const deleteTestCase = testCase => Promise.asyncApply(() => {
  try {
    const client = Promise.await(pool.connect());
    const {
      _id
    } = testCase;
    const query = `
      delete from bus_test_cases
      where c_test_case_id = '${_id}'
    `;
    console.log('DeleteTestCase with sql: ', query);
    const result = Promise.await(fetch(query));
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

const acceptTestResult = testCase => Promise.asyncApply(() => {
  try {
    const client = Promise.await(pool.connect());
    const {
      _id,
      testRunResult
    } = testCase;
    const query = `
    update bus_test_cases set
    c_expected_resulttrace = $token$${testRunResult}$token$
    where
    c_test_case_id = '${_id}'
    `;
    console.log('AcceptTestResult with sql: ', query);
    const result = Promise.await(client.query(query));
    Promise.await(client.release(true));
  } catch (exception) {
    throw new Error(exception.message);
  }
});

module.exportDefault({
  fetch,
  loadFromPostgresql,
  insert,
  update,
  runTest,
  runTestsFiltered,
  pollReadyTests,
  updateStatusAndDiffResult,
  deleteTestCase,
  acceptTestResult,
  updateExpectedResult
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/TestCases/server/publications.js                                                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let TestCases;
module.link("../TestCases", {
  default(v) {
    TestCases = v;
  }

}, 2);
Meteor.publish('testCases', function testCases() {
  return TestCases.find();
});
Meteor.publish('testCases.view', function testCasesView(testCaseId) {
  check(testCaseId, String);
  return TestCases.find(testCaseId);
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"TestCases.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/TestCases/TestCases.js                                                                        //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
const TestCases = new Mongo.Collection('TestCases');
TestCases.allow({
  insert: () => false,
  update: () => false,
  remove: () => false
});
TestCases.deny({
  insert: () => true,
  update: () => true,
  remove: () => true
});
TestCases.schema = new SimpleSchema({
  owner: SimpleSchema.RegEx.Id,
  name: String,
  testIdPrefix: {
    type: String,
    optional: true
  },
  jiraURL: {
    type: String,
    optional: true
  },
  messageType: String,
  format: String,
  loadingQueue: String,
  runTimeSec: Number,
  testMessage: String,
  // clob
  testRunResult: {
    type: String,
    optional: true
  },
  // clob
  testStatus: {
    type: String,
    allowedValues: ['run', 'loading', 'ready', 'passed', 'failed']
  },
  testStart: {
    type: Date,
    optional: true
  },
  // internal
  expectedResult: {
    type: String,
    optional: true
  },
  // overview not editor
  completesInIpc: Boolean,
  rfh2Header: {
    type: String,
    optional: true
  },
  // clob
  comment: {
    type: String,
    optional: true
  },
  // clob,
  group: String,
  autoTest: Boolean,
  delayedTest: Boolean,
  diffCount: {
    type: Number,
    optional: true
  },
  mqUserIdentifier: {
    type: String,
    optional: true
  },
  linefeed: {
    type: String,
    allowedValues: ['LF', 'CRLF']
  },
  ipcLink: {
    type: String,
    optional: true
  },
  departmentCode: {
    type: String,
    allowedValues: ['cs', 'fs', 'is', 'ss', 'dev']
  }
});
TestCases.attachSchema(TestCases.schema);
module.exportDefault(TestCases);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/TestCases/methods.js                                                                          //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _objectSpread2 = _interopRequireDefault(require("@babel/runtime/helpers/objectSpread"));

let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check, Match;
module.link("meteor/check", {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 1);
let TestCases;
module.link("./TestCases", {
  default(v) {
    TestCases = v;
  }

}, 2);
let rateLimit;
module.link("../../modules/rate-limit", {
  default(v) {
    rateLimit = v;
  }

}, 3);
Meteor.methods({
  'testCases.insert': function testCasesInsert(testCase) {
    check(testCase, {
      name: String,
      messageType: String,
      format: String,
      loadingQueue: String,
      runTimeSec: Number,
      testMessage: String,
      // clob
      // testRunResult: String, // clob
      testStatus: String,
      // testStart: Date,
      expectedResult: String,
      // testReport: String, // clob
      completesInIpc: Boolean,
      // lastRunResult: String, // clob
      rfh2Header: String,
      // clob
      comment: String,
      group: String,
      autoTest: Boolean,
      delayedTest: Boolean,
      mqUserIdentifier: String,
      linefeed: String,
      departmentCode: String,
      testIdPrefix: Match.Maybe(String),
      jiraURL: Match.Maybe(String)
    }); // console.log('methods.testCases.insert: ', testCase);

    try {
      const _id = TestCases.insert((0, _objectSpread2.default)({
        owner: this.userId
      }, testCase));

      if (Meteor.isServer) {
        module.dynamicImport('./server/postgres').then(({
          default: postgres
        }) => {
          postgres.insert((0, _objectSpread2.default)({
            _id,
            owner: this.userId
          }, testCase));
        });
      }

      return _id;
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  },
  'testCases.update': function testCasesUpdate(testCase) {
    check(testCase, {
      _id: String,
      name: String,
      messageType: String,
      format: String,
      loadingQueue: String,
      runTimeSec: Number,
      testMessage: String,
      // clob
      // testRunResult: String, // clob
      testStatus: String,
      // testStart: Date,
      expectedResult: String,
      // testReport: String, // clob
      completesInIpc: Boolean,
      // lastRunResult: String, // clob
      rfh2Header: String,
      // clob
      comment: String,
      group: String,
      autoTest: Boolean,
      delayedTest: Boolean,
      mqUserIdentifier: String,
      linefeed: String,
      departmentCode: String,
      testIdPrefix: Match.Maybe(String),
      jiraURL: Match.Maybe(String)
    });
    console.log('methods.testCases.update: ', testCase);

    try {
      const testCaseId = testCase._id;
      TestCases.update(testCaseId, {
        $set: (0, _objectSpread2.default)({
          owner: this.userId
        }, testCase)
      });

      if (Meteor.isServer) {
        module.dynamicImport('./server/postgres').then(({
          default: postgres
        }) => {
          postgres.update((0, _objectSpread2.default)({
            testCaseId,
            owner: this.userId
          }, testCase));
        });
      }

      return testCaseId; // Return _id so we can redirect to the testcase after update.
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  },
  'testCases.remove': function testCasesRemove(_id) {
    check(_id, String);

    try {
      //first try to delete from Postgresql
      if (Meteor.isServer) {
        module.dynamicImport('./server/postgres').then(({
          default: postgres
        }) => {
          postgres.deleteTestCase({
            _id
          });
        });
      } // then remove from MongoDB


      return TestCases.remove(_id);
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  },
  'testCases.runTest': function testCasesRunTest(_id, date) {
    check(_id, String);
    check(date, Date);
    console.log('called runTest method on Entry:', _id);

    try {
      const result = TestCases.update(_id, {
        $set: {
          testStatus: 'run',
          diffCount: '',
          testStart: date,
          ipcLink: ''
        }
      });

      if (Meteor.isServer) {
        module.dynamicImport('./server/postgres').then(({
          default: postgres
        }) => {
          postgres.runTest({
            _id,
            owner: this.userId
          });
        });
      }

      return result;
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  },
  'testCases.acceptTestResult': function testCasesAcceptTestResult(_id) {
    check(_id, String);
    console.log('called acceptTestResult method on Entry:', _id);

    try {
      const {
        testRunResult
      } = TestCases.findOne(_id);
      const result = TestCases.update(_id, {
        $set: {
          expectedResult: testRunResult,
          diffCount: 0,
          testStatus: 'passed'
        }
      });

      if (Meteor.isServer) {
        module.dynamicImport('./server/postgres').then(({
          default: postgres
        }) => {
          postgres.acceptTestResult({
            _id,
            testRunResult
          });
        });
      }

      return result;
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  },
  'testCases.runTestsFiltered': function testCasesRunTestsFiltered(params) {
    check(params, {
      group: Match.Maybe(String),
      loadingQueue: Match.Maybe(String),
      messageType: Match.Maybe(String),
      departmentCode: Match.Maybe(String)
    });
    const date = new Date();

    try {
      const updateParams = {};

      if (params.group) {
        updateParams.group = params.group;
      }

      if (params.loadingQueue) {
        updateParams.loadingQueue = params.loadingQueue;
      }

      if (params.messageType) {
        updateParams.messageType = params.messageType;
      }

      if (params.departmentCode) {
        updateParams.departmentCode = params.departmentCode;
      }

      const result = TestCases.update(updateParams, {
        $set: {
          owner: this.userId,
          testStatus: 'run',
          diffCount: '',
          testStart: date,
          ipcLink: ''
        }
      }, {
        multi: true
      });

      if (Meteor.isServer) {
        module.dynamicImport('./server/postgres').then(({
          default: postgres
        }) => {
          postgres.runTestsFiltered((0, _objectSpread2.default)({}, params, {
            owner: this.userId
          }));
        });
      }
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  },
  'testCases.copy': function testCasesCopy(oldTestCaseId) {
    check(oldTestCaseId, String);
    const testCase = TestCases.findOne(oldTestCaseId);
    delete testCase._id; //create new Name value with COPY string

    const name = testCase.name + ' Copy';
    const count = TestCases.find({
      name: new RegExp(`^${name}`)
    }).count();
    const newTestCase = (0, _objectSpread2.default)({}, testCase, {
      name: name + ` ${count ? count + 1 : ''}`
    });

    try {
      const _id = TestCases.insert((0, _objectSpread2.default)({
        owner: this.userId
      }, newTestCase));

      if (Meteor.isServer) {
        module.dynamicImport('./server/postgres').then(({
          default: postgres
        }) => {
          postgres.insert((0, _objectSpread2.default)({
            _id,
            owner: this.userId
          }, newTestCase));
        });
      }

      return _id;
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  },
  'importPostgresInfo': function importPostgresInfo() {
    try {
      if (Meteor.isServer) {
        module.dynamicImport('./server/postgres').then(({
          default: postgres
        }) => {
          postgres.loadFromPostgresql(this.userId);
        });
      }
    } catch (exception) {
      throw new Meteor.Error('500', exception);
    }
  }
});
rateLimit({
  methods: ['testCases.insert', 'testCases.update', 'testCases.remove'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Users":{"server":{"edit-profile.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Users/server/edit-profile.js                                                                  //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let action;

const updateUser = (userId, {
  emailAddress,
  profile
}) => {
  try {
    Meteor.users.update(userId, {
      $set: {
        'emails.0.address': emailAddress,
        profile
      }
    });
  } catch (exception) {
    throw new Error(`[editProfile.updateUser] ${exception.message}`);
  }
};

const editProfile = ({
  userId,
  profile
}, promise) => {
  try {
    action = promise;
    updateUser(userId, profile);
    action.resolve();
  } catch (exception) {
    action.reject(exception.message);
  }
};

module.exportDefault(options => new Promise((resolve, reject) => editProfile(options, {
  resolve,
  reject
})));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Users/server/methods.js                                                                       //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 2);
let editProfile;
module.link("./edit-profile", {
  default(v) {
    editProfile = v;
  }

}, 3);
let rateLimit;
module.link("../../../modules/rate-limit", {
  default(v) {
    rateLimit = v;
  }

}, 4);
Meteor.methods({
  'users.sendVerificationEmail': function usersSendVerificationEmail() {
    return Accounts.sendVerificationEmail(this.userId);
  },
  'users.editProfile': function usersEditProfile(profile) {
    check(profile, {
      emailAddress: String,
      profile: {
        name: {
          first: String,
          last: String
        }
      }
    });
    return editProfile({
      userId: this.userId,
      profile
    }).then(response => response).catch(exception => {
      throw new Meteor.Error('500', exception);
    });
  }
});
rateLimit({
  methods: ['users.sendVerificationEmail', 'users.editProfile'],
  limit: 5,
  timeRange: 1000
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Users/server/publications.js                                                                  //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.publish('users.editProfile', function usersProfile() {
  return Meteor.users.find(this.userId, {
    fields: {
      emails: 1,
      profile: 1,
      services: 1
    }
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"Utility":{"server":{"methods.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/api/Utility/server/methods.js                                                                     //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let getPrivateFile;
module.link("../../../modules/server/get-private-file", {
  default(v) {
    getPrivateFile = v;
  }

}, 2);
let parseMarkdown;
module.link("../../../modules/parse-markdown", {
  default(v) {
    parseMarkdown = v;
  }

}, 3);
Meteor.methods({
  'utility.getPage': function utilityGetPage(fileName) {
    check(fileName, String);
    return parseMarkdown(getPrivateFile(`pages/${fileName}.md`));
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"startup":{"server":{"accounts":{"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/startup/server/accounts/index.js                                                                  //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
module.link("./on-create-user.js");
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"on-create-user.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/startup/server/accounts/on-create-user.js                                                         //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 0);
Accounts.onCreateUser((options, user) => {
  const userToCreate = user;
  if (options.profile) userToCreate.profile = options.profile;
  return userToCreate;
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"api.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/startup/server/api.js                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
module.link("../../api/Documents/server/publications");
module.link("../../api/TestCases/server/publications");
module.link("../../api/Groups/server/publications");
module.link("../../api/Queues/server/publications");
module.link("../../api/MessageTypes/server/publications");
module.link("../../api/Formats/server/publications");
module.link("../../api/DepartmentCodes/server/publications");
module.link("../../api/OAuth/server/methods");
module.link("../../api/Users/server/methods");
module.link("../../api/Users/server/publications");
module.link("../../api/Utility/server/methods");
let postgres;
module.link("../../api/TestCases/server/postgres", {
  default(v) {
    postgres = v;
  }

}, 0);
let TestCases;
module.link("../../api/TestCases/TestCases", {
  default(v) {
    TestCases = v;
  }

}, 1);
const testCase = {
  _id: '_id',
  owner: 'owner',
  name: 'name',
  messageType: 'messageType',
  format: 'format',
  loadingQueue: 'loadingQueue',
  runTimeSec: 60,
  testMessage: 'testMessage',
  completesInIpc: true,
  rfh2Header: 'rfh2Header',
  comment: 'comment',
  group: 'group',
  departmentCode: 'departmentCode',
  autoTest: true
}; // postgres.insert(testCase);
// postgres.fetch(`
//   select fk_test_case_id as testCaseId,
//   result as expectedResult
//   from bus_test_runs
//   where runstate = 'ready'
// `);
// postgres.update({...testCase, testMessage: 'new test message'});
// postgres.runTest(testCase);
// postgres.pollReadyTests();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cron.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/startup/server/cron.js                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let SyncedCron;
module.link("meteor/percolate:synced-cron", {
  SyncedCron(v) {
    SyncedCron = v;
  }

}, 0);
let postgres;
module.link("../../api/TestCases/server/postgres", {
  default(v) {
    postgres = v;
  }

}, 1);
SyncedCron.config({
  log: false
});
SyncedCron.add({
  name: 'Poll postgres',

  schedule(parser) {
    return parser.text('every 1 minute');
  },

  job() {
    return postgres.pollReadyTests();
  }

});
SyncedCron.start();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"email.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/startup/server/email.js                                                                           //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
if (Meteor.isDevelopment) process.env.MAIL_URL = Meteor.settings.private.MAIL_URL;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fixtures.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/startup/server/fixtures.js                                                                        //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let seeder;
module.link("@cleverbeagle/seeder", {
  default(v) {
    seeder = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Documents;
module.link("../../api/Documents/Documents", {
  default(v) {
    Documents = v;
  }

}, 2);

const documentsSeed = userId => ({
  collection: Documents,
  environments: ['development', 'staging'],
  noLimit: true,
  modelCount: 5,

  model(dataIndex) {
    return {
      owner: userId,
      title: `Document #${dataIndex + 1}`,
      body: `This is the body of document #${dataIndex + 1}`
    };
  }

});

seeder(Meteor.users, {
  environments: ['development', 'staging'],
  noLimit: true,
  data: [{
    email: 'admin@admin.com',
    password: 'password',
    profile: {
      name: {
        first: 'Andy',
        last: 'Warhol'
      }
    },
    roles: ['admin'],

    data(userId) {
      return documentsSeed(userId);
    }

  }],
  modelCount: 5,

  model(index, faker) {
    const userCount = index + 1;
    return {
      email: `user+${userCount}@test.com`,
      password: 'password',
      profile: {
        name: {
          first: faker.name.firstName(),
          last: faker.name.lastName()
        }
      },
      roles: ['user'],

      data(userId) {
        return documentsSeed(userId);
      }

    };
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/startup/server/index.js                                                                           //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
module.link("./accounts");
module.link("../both/api");
module.link("./api");
module.link("./fixtures");
module.link("./email");
module.link("./cron");
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"both":{"api.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/startup/both/api.js                                                                               //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
module.link("../../api/Documents/methods");
module.link("../../api/TestCases/methods");
module.link("../../api/Groups/methods");
module.link("../../api/Queues/methods");
module.link("../../api/MessageTypes/methods");
module.link("../../api/Formats/methods");
module.link("../../api/DepartmentCodes/methods");
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"modules":{"server":{"get-private-file.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/modules/server/get-private-file.js                                                                //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }

}, 0);
module.exportDefault(path => fs.readFileSync(`assets/app/${path}`, 'utf8'));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"parse-markdown.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/modules/parse-markdown.js                                                                         //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Parser, HtmlRenderer;
module.link("commonmark", {
  Parser(v) {
    Parser = v;
  },

  HtmlRenderer(v) {
    HtmlRenderer = v;
  }

}, 0);
module.exportDefault((markdown, options) => {
  const reader = new Parser();
  const writer = options ? new HtmlRenderer(options) : new HtmlRenderer();
  const parsed = reader.parse(markdown);
  return writer.render(parsed);
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"rate-limit.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// imports/modules/rate-limit.js                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let DDPRateLimiter;
module.link("meteor/ddp-rate-limiter", {
  DDPRateLimiter(v) {
    DDPRateLimiter = v;
  }

}, 1);
module.exportDefault(({
  methods,
  limit,
  timeRange
}) => {
  if (Meteor.isServer) {
    DDPRateLimiter.addRule({
      name(name) {
        return methods.indexOf(name) > -1;
      },

      connectionId() {
        return true;
      }

    }, limit, timeRange);
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/main.js                                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
module.link("../imports/startup/server");
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvRGVwYXJ0bWVudENvZGVzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL0RlcGFydG1lbnRDb2Rlcy9EZXBhcnRtZW50Q29kZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL0RlcGFydG1lbnRDb2Rlcy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Eb2N1bWVudHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvRG9jdW1lbnRzL0RvY3VtZW50cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvRG9jdW1lbnRzL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL0Zvcm1hdHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvRm9ybWF0cy9Gb3JtYXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Gb3JtYXRzL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL0dyb3Vwcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Hcm91cHMvR3JvdXBzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Hcm91cHMvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvTWVzc2FnZVR5cGVzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL01lc3NhZ2VUeXBlcy9NZXNzYWdlVHlwZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL01lc3NhZ2VUeXBlcy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9PQXV0aC9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvUXVldWVzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1F1ZXVlcy9RdWV1ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1F1ZXVlcy9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9UZXN0Q2FzZXMvc2VydmVyL3Bvc3RncmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9UZXN0Q2FzZXMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvVGVzdENhc2VzL1Rlc3RDYXNlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvVGVzdENhc2VzL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1VzZXJzL3NlcnZlci9lZGl0LXByb2ZpbGUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1VzZXJzL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Vc2Vycy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9VdGlsaXR5L3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2FjY291bnRzL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2FjY291bnRzL29uLWNyZWF0ZS11c2VyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2FwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9jcm9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2VtYWlsLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2ZpeHR1cmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvYm90aC9hcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvbW9kdWxlcy9zZXJ2ZXIvZ2V0LXByaXZhdGUtZmlsZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9tb2R1bGVzL3BhcnNlLW1hcmtkb3duLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL21vZHVsZXMvcmF0ZS1saW1pdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJjaGVjayIsIkRlcGFydG1lbnRDb2RlcyIsImRlZmF1bHQiLCJwdWJsaXNoIiwiZGVwYXJ0bWVudENvZGVzIiwiZmluZCIsIk1vbmdvIiwiU2ltcGxlU2NoZW1hIiwiQ29sbGVjdGlvbiIsImFsbG93IiwiaW5zZXJ0IiwidXBkYXRlIiwicmVtb3ZlIiwiZGVueSIsInNjaGVtYSIsIm5hbWUiLCJTdHJpbmciLCJhdHRhY2hTY2hlbWEiLCJleHBvcnREZWZhdWx0IiwibWV0aG9kcyIsImRlcGFydG1lbnRDb2Rlc0luc2VydCIsImRlcGFydG1lbnRDb2RlIiwiZXhjZXB0aW9uIiwiRXJyb3IiLCJEb2N1bWVudHMiLCJkb2N1bWVudHMiLCJvd25lciIsInVzZXJJZCIsImRvY3VtZW50c1ZpZXciLCJkb2N1bWVudElkIiwiX2lkIiwidHlwZSIsImxhYmVsIiwiY3JlYXRlZEF0IiwiYXV0b1ZhbHVlIiwiaXNJbnNlcnQiLCJEYXRlIiwidG9JU09TdHJpbmciLCJ1cGRhdGVkQXQiLCJpc1VwZGF0ZSIsInRpdGxlIiwiYm9keSIsInJhdGVMaW1pdCIsImRvY3VtZW50c0luc2VydCIsImRvYyIsImRvY3VtZW50c1VwZGF0ZSIsIiRzZXQiLCJkb2N1bWVudHNSZW1vdmUiLCJsaW1pdCIsInRpbWVSYW5nZSIsIkZvcm1hdHMiLCJmb3JtYXRzIiwiZm9ybWF0c0luc2VydCIsImZvcm1hdCIsIkdyb3VwcyIsImdyb3VwcyIsImdyb3Vwc0luc2VydCIsImdyb3VwIiwiTWVzc2FnZVR5cGVzIiwibWVzc2FnZVR5cGVzIiwibWVzc2FnZVR5cGVzSW5zZXJ0IiwibWVzc2FnZVR5cGUiLCJTZXJ2aWNlQ29uZmlndXJhdGlvbiIsIm9hdXRoVmVyaWZ5Q29uZmlndXJhdGlvbiIsInNlcnZpY2VzIiwiQXJyYXkiLCJ2ZXJpZmllZFNlcnZpY2VzIiwiZm9yRWFjaCIsInNlcnZpY2UiLCJjb25maWd1cmF0aW9ucyIsImZpbmRPbmUiLCJwdXNoIiwic29ydCIsIlF1ZXVlcyIsInF1ZXVlcyIsInF1ZXVlc0luc2VydCIsInF1ZXVlIiwiUG9vbCIsImpzZGlmZiIsIlRlc3RDYXNlcyIsInBvb2wiLCJzZXR0aW5ncyIsInByaXZhdGUiLCJwb3N0Z3JlcyIsIm9sZFBvb2xRdWVyeSIsInF1ZXJ5IiwiYXJncyIsImNvbnNvbGUiLCJsb2ciLCJhcHBseSIsImZldGNoIiwicGFyYW1zIiwiY2xpZW50IiwiY29ubmVjdCIsInJlc3VsdCIsInJvd3MiLCJyZWxlYXNlIiwibWVzc2FnZSIsInVwZGF0ZVN0YXR1c0FuZERpZmZSZXN1bHQiLCJkaWZmQ291bnQiLCJ1cGRhdGVFeHBlY3RlZFJlc3VsdCIsInRlc3RSdW5SZXN1bHQiLCJwb2xsUmVhZHlUZXN0cyIsInRvZGF5Iiwicm93IiwiY190ZXN0X2Nhc2VfaWQiLCJjX2V4cGVjdGVkX3Jlc3VsdHRyYWNlIiwiZXhwZWN0ZWRSZXN1bHQiLCJjX3Rlc3RfcnVuX3Jlc3VsdHRyYWNlIiwiY19pcGNsaW5rIiwiaXBjTGluayIsIm1vbmdvRXhwZWN0ZWRSZXN1bHQiLCJ0ZXN0U3RhdHVzIiwidGVzdFN0YXJ0IiwiZGlmZiIsImRpZmZXb3JkcyIsInN1YnN0cmluZyIsIm1hcCIsInBhcnQiLCJpbmRleCIsImFkZGVkIiwicmVtb3ZlZCIsImxlbmd0aCIsImxvYWRGcm9tUG9zdGdyZXNxbCIsInZhbGlkTGluZUJyZWFrcyIsInZhbGlkRGVwYXJ0bWVudENvZGVzIiwic2V0R3JvdXBzIiwiU2V0Iiwic2V0UXVldWVzIiwic2V0TWVzc2FnZVR5cGVzIiwic2V0Rm9ybWF0cyIsInRlc3RDYXNlIiwiY190ZXN0X2Nhc2VfbmFtZSIsInRlc3RJZFByZWZpeCIsImNfdGVzdGlkX3ByZWZpeCIsImppcmFVUkwiLCJjX2ppcmFfdXJsIiwiY19ncm91cF9uYW1lIiwiY19tZXNzYWdlX3R5cGUiLCJjX2Zvcm1hdCIsImxvYWRpbmdRdWV1ZSIsImNfbG9hZGluZ19xdWV1ZSIsInRlc3RNZXNzYWdlIiwiY190ZXN0X21lc3NhZ2UiLCJyZmgySGVhZGVyIiwiY19yaGYyX2hlYWRlciIsImNvbW1lbnQiLCJjX2NvbW1lbnQiLCJuX2RpZmZfY291bnQiLCJhdXRvVGVzdCIsIm5fYXV0b3Rlc3QiLCJkZWxheWVkVGVzdCIsIm5fZGVsYXllZCIsInJ1blRpbWVTZWMiLCJuX3J1bnRpbWVfaW5fc2VjIiwiY29tcGxldGVzSW5JcGMiLCJuX2NvbXBsZXRlc19pbl9pcGMiLCJtcVVzZXJJZGVudGlmaWVyIiwiY19tcW1kX3VzZXJpZGVudGlmaWVyIiwibGluZWZlZWQiLCJpbmNsdWRlcyIsImNfbGluZWJyZWFrIiwiY19kZXBhcnRtZW50X2NvZGUiLCJhZGQiLCJjbGVhbnF1ZXJ5IiwicmVwbGFjZSIsInJ1blRlc3QiLCJydW5UZXN0c0ZpbHRlcmVkIiwiZGVsZXRlVGVzdENhc2UiLCJhY2NlcHRUZXN0UmVzdWx0IiwidGVzdENhc2VzIiwidGVzdENhc2VzVmlldyIsInRlc3RDYXNlSWQiLCJSZWdFeCIsIklkIiwib3B0aW9uYWwiLCJOdW1iZXIiLCJhbGxvd2VkVmFsdWVzIiwiQm9vbGVhbiIsIk1hdGNoIiwidGVzdENhc2VzSW5zZXJ0IiwiTWF5YmUiLCJpc1NlcnZlciIsInRoZW4iLCJ0ZXN0Q2FzZXNVcGRhdGUiLCJ0ZXN0Q2FzZXNSZW1vdmUiLCJ0ZXN0Q2FzZXNSdW5UZXN0IiwiZGF0ZSIsInRlc3RDYXNlc0FjY2VwdFRlc3RSZXN1bHQiLCJ0ZXN0Q2FzZXNSdW5UZXN0c0ZpbHRlcmVkIiwidXBkYXRlUGFyYW1zIiwibXVsdGkiLCJ0ZXN0Q2FzZXNDb3B5Iiwib2xkVGVzdENhc2VJZCIsImNvdW50IiwiUmVnRXhwIiwibmV3VGVzdENhc2UiLCJpbXBvcnRQb3N0Z3Jlc0luZm8iLCJhY3Rpb24iLCJ1cGRhdGVVc2VyIiwiZW1haWxBZGRyZXNzIiwicHJvZmlsZSIsInVzZXJzIiwiZWRpdFByb2ZpbGUiLCJwcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsIm9wdGlvbnMiLCJQcm9taXNlIiwiQWNjb3VudHMiLCJ1c2Vyc1NlbmRWZXJpZmljYXRpb25FbWFpbCIsInNlbmRWZXJpZmljYXRpb25FbWFpbCIsInVzZXJzRWRpdFByb2ZpbGUiLCJmaXJzdCIsImxhc3QiLCJyZXNwb25zZSIsImNhdGNoIiwidXNlcnNQcm9maWxlIiwiZmllbGRzIiwiZW1haWxzIiwiZ2V0UHJpdmF0ZUZpbGUiLCJwYXJzZU1hcmtkb3duIiwidXRpbGl0eUdldFBhZ2UiLCJmaWxlTmFtZSIsIm9uQ3JlYXRlVXNlciIsInVzZXIiLCJ1c2VyVG9DcmVhdGUiLCJTeW5jZWRDcm9uIiwiY29uZmlnIiwic2NoZWR1bGUiLCJwYXJzZXIiLCJ0ZXh0Iiwiam9iIiwic3RhcnQiLCJpc0RldmVsb3BtZW50IiwicHJvY2VzcyIsImVudiIsIk1BSUxfVVJMIiwic2VlZGVyIiwiZG9jdW1lbnRzU2VlZCIsImNvbGxlY3Rpb24iLCJlbnZpcm9ubWVudHMiLCJub0xpbWl0IiwibW9kZWxDb3VudCIsIm1vZGVsIiwiZGF0YUluZGV4IiwiZGF0YSIsImVtYWlsIiwicGFzc3dvcmQiLCJyb2xlcyIsImZha2VyIiwidXNlckNvdW50IiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJmcyIsInBhdGgiLCJyZWFkRmlsZVN5bmMiLCJQYXJzZXIiLCJIdG1sUmVuZGVyZXIiLCJtYXJrZG93biIsInJlYWRlciIsIndyaXRlciIsInBhcnNlZCIsInBhcnNlIiwicmVuZGVyIiwiRERQUmF0ZUxpbWl0ZXIiLCJhZGRSdWxlIiwiaW5kZXhPZiIsImNvbm5lY3Rpb25JZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVUgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsZUFBSjtBQUFvQkosTUFBTSxDQUFDQyxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ0UsbUJBQWUsR0FBQ0YsQ0FBaEI7QUFBa0I7O0FBQTlCLENBQWpDLEVBQWlFLENBQWpFO0FBSWhKSCxNQUFNLENBQUNPLE9BQVAsQ0FBZSxpQkFBZixFQUFrQyxTQUFTQyxlQUFULEdBQTJCO0FBQzNELFNBQU9ILGVBQWUsQ0FBQ0ksSUFBaEIsRUFBUDtBQUNELENBRkQsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJQyxLQUFKO0FBQVVULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1EsT0FBSyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sU0FBSyxHQUFDUCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlRLFlBQUo7QUFBaUJWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ1EsZ0JBQVksR0FBQ1IsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDtBQUs3RSxNQUFNRSxlQUFlLEdBQUcsSUFBSUssS0FBSyxDQUFDRSxVQUFWLENBQXFCLGlCQUFyQixDQUF4QjtBQUVBUCxlQUFlLENBQUNRLEtBQWhCLENBQXNCO0FBQ3BCQyxRQUFNLEVBQUUsTUFBTSxLQURNO0FBRXBCQyxRQUFNLEVBQUUsTUFBTSxLQUZNO0FBR3BCQyxRQUFNLEVBQUUsTUFBTTtBQUhNLENBQXRCO0FBTUFYLGVBQWUsQ0FBQ1ksSUFBaEIsQ0FBcUI7QUFDbkJILFFBQU0sRUFBRSxNQUFNLElBREs7QUFFbkJDLFFBQU0sRUFBRSxNQUFNLElBRks7QUFHbkJDLFFBQU0sRUFBRSxNQUFNO0FBSEssQ0FBckI7QUFNQVgsZUFBZSxDQUFDYSxNQUFoQixHQUF5QixJQUFJUCxZQUFKLENBQWlCO0FBQ3hDUSxNQUFJLEVBQUVDO0FBRGtDLENBQWpCLENBQXpCO0FBSUFmLGVBQWUsQ0FBQ2dCLFlBQWhCLENBQTZCaEIsZUFBZSxDQUFDYSxNQUE3QztBQXZCQWpCLE1BQU0sQ0FBQ3FCLGFBQVAsQ0F5QmVqQixlQXpCZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlMLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxlQUFKO0FBQW9CSixNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDRSxtQkFBZSxHQUFDRixDQUFoQjtBQUFrQjs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7QUFJaEpILE1BQU0sQ0FBQ3VCLE9BQVAsQ0FBZTtBQUNiLDRCQUEwQixTQUFTQyxxQkFBVCxDQUErQkMsY0FBL0IsRUFBK0M7QUFDdkVyQixTQUFLLENBQUNxQixjQUFELEVBQWlCO0FBQ3BCTixVQUFJLEVBQUVDO0FBRGMsS0FBakIsQ0FBTDs7QUFJQSxRQUFJO0FBQ0YsYUFBT2YsZUFBZSxDQUFDUyxNQUFoQixDQUF1QlcsY0FBdkIsQ0FBUDtBQUNELEtBRkQsQ0FFRSxPQUFPQyxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTFCLE1BQU0sQ0FBQzJCLEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JELFNBQXhCLENBQU47QUFDRDtBQUNGO0FBWFksQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBLElBQUkxQixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVUgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSXlCLFNBQUo7QUFBYzNCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ3lCLGFBQVMsR0FBQ3pCLENBQVY7QUFBWTs7QUFBeEIsQ0FBM0IsRUFBcUQsQ0FBckQ7QUFJMUlILE1BQU0sQ0FBQ08sT0FBUCxDQUFlLFdBQWYsRUFBNEIsU0FBU3NCLFNBQVQsR0FBcUI7QUFDL0MsU0FBT0QsU0FBUyxDQUFDbkIsSUFBVixDQUFlO0FBQUVxQixTQUFLLEVBQUUsS0FBS0M7QUFBZCxHQUFmLENBQVA7QUFDRCxDQUZELEUsQ0FJQTs7QUFDQS9CLE1BQU0sQ0FBQ08sT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFNBQVN5QixhQUFULENBQXVCQyxVQUF2QixFQUFtQztBQUNsRTdCLE9BQUssQ0FBQzZCLFVBQUQsRUFBYWIsTUFBYixDQUFMO0FBQ0EsU0FBT1EsU0FBUyxDQUFDbkIsSUFBVixDQUFlO0FBQUV5QixPQUFHLEVBQUVELFVBQVA7QUFBbUJILFNBQUssRUFBRSxLQUFLQztBQUEvQixHQUFmLENBQVA7QUFDRCxDQUhELEU7Ozs7Ozs7Ozs7O0FDVEEsSUFBSXJCLEtBQUo7QUFBVVQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSVEsWUFBSjtBQUFpQlYsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDUSxnQkFBWSxHQUFDUixDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBSzdFLE1BQU15QixTQUFTLEdBQUcsSUFBSWxCLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixXQUFyQixDQUFsQjtBQUVBZ0IsU0FBUyxDQUFDZixLQUFWLENBQWdCO0FBQ2RDLFFBQU0sRUFBRSxNQUFNLEtBREE7QUFFZEMsUUFBTSxFQUFFLE1BQU0sS0FGQTtBQUdkQyxRQUFNLEVBQUUsTUFBTTtBQUhBLENBQWhCO0FBTUFZLFNBQVMsQ0FBQ1gsSUFBVixDQUFlO0FBQ2JILFFBQU0sRUFBRSxNQUFNLElBREQ7QUFFYkMsUUFBTSxFQUFFLE1BQU0sSUFGRDtBQUdiQyxRQUFNLEVBQUUsTUFBTTtBQUhELENBQWY7QUFNQVksU0FBUyxDQUFDVixNQUFWLEdBQW1CLElBQUlQLFlBQUosQ0FBaUI7QUFDbENtQixPQUFLLEVBQUU7QUFDTEssUUFBSSxFQUFFZixNQUREO0FBRUxnQixTQUFLLEVBQUU7QUFGRixHQUQyQjtBQUtsQ0MsV0FBUyxFQUFFO0FBQ1RGLFFBQUksRUFBRWYsTUFERztBQUVUZ0IsU0FBSyxFQUFFLHFDQUZFOztBQUdURSxhQUFTLEdBQUc7QUFDVixVQUFJLEtBQUtDLFFBQVQsRUFBbUIsT0FBUSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsV0FBYixFQUFQO0FBQ3BCOztBQUxRLEdBTHVCO0FBWWxDQyxXQUFTLEVBQUU7QUFDVFAsUUFBSSxFQUFFZixNQURHO0FBRVRnQixTQUFLLEVBQUUsMENBRkU7O0FBR1RFLGFBQVMsR0FBRztBQUNWLFVBQUksS0FBS0MsUUFBTCxJQUFpQixLQUFLSSxRQUExQixFQUFvQyxPQUFRLElBQUlILElBQUosRUFBRCxDQUFhQyxXQUFiLEVBQVA7QUFDckM7O0FBTFEsR0FadUI7QUFtQmxDRyxPQUFLLEVBQUU7QUFDTFQsUUFBSSxFQUFFZixNQUREO0FBRUxnQixTQUFLLEVBQUU7QUFGRixHQW5CMkI7QUF1QmxDUyxNQUFJLEVBQUU7QUFDSlYsUUFBSSxFQUFFZixNQURGO0FBRUpnQixTQUFLLEVBQUU7QUFGSDtBQXZCNEIsQ0FBakIsQ0FBbkI7QUE2QkFSLFNBQVMsQ0FBQ1AsWUFBVixDQUF1Qk8sU0FBUyxDQUFDVixNQUFqQztBQWhEQWpCLE1BQU0sQ0FBQ3FCLGFBQVAsQ0FrRGVNLFNBbERmLEU7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLElBQUk1QixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVUgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSXlCLFNBQUo7QUFBYzNCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ3lCLGFBQVMsR0FBQ3pCLENBQVY7QUFBWTs7QUFBeEIsQ0FBMUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSTJDLFNBQUo7QUFBYzdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUMyQyxhQUFTLEdBQUMzQyxDQUFWO0FBQVk7O0FBQXhCLENBQXZDLEVBQWlFLENBQWpFO0FBSy9NSCxNQUFNLENBQUN1QixPQUFQLENBQWU7QUFDYixzQkFBb0IsU0FBU3dCLGVBQVQsQ0FBeUJDLEdBQXpCLEVBQThCO0FBQ2hENUMsU0FBSyxDQUFDNEMsR0FBRCxFQUFNO0FBQ1RKLFdBQUssRUFBRXhCLE1BREU7QUFFVHlCLFVBQUksRUFBRXpCO0FBRkcsS0FBTixDQUFMOztBQUtBLFFBQUk7QUFDRixhQUFPUSxTQUFTLENBQUNkLE1BQVY7QUFBbUJnQixhQUFLLEVBQUUsS0FBS0M7QUFBL0IsU0FBMENpQixHQUExQyxFQUFQO0FBQ0QsS0FGRCxDQUVFLE9BQU90QixTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTFCLE1BQU0sQ0FBQzJCLEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JELFNBQXhCLENBQU47QUFDRDtBQUNGLEdBWlk7QUFhYixzQkFBb0IsU0FBU3VCLGVBQVQsQ0FBeUJELEdBQXpCLEVBQThCO0FBQ2hENUMsU0FBSyxDQUFDNEMsR0FBRCxFQUFNO0FBQ1RkLFNBQUcsRUFBRWQsTUFESTtBQUVUd0IsV0FBSyxFQUFFeEIsTUFGRTtBQUdUeUIsVUFBSSxFQUFFekI7QUFIRyxLQUFOLENBQUw7O0FBTUEsUUFBSTtBQUNGLFlBQU1hLFVBQVUsR0FBR2UsR0FBRyxDQUFDZCxHQUF2QjtBQUNBTixlQUFTLENBQUNiLE1BQVYsQ0FBaUJrQixVQUFqQixFQUE2QjtBQUFFaUIsWUFBSSxFQUFFRjtBQUFSLE9BQTdCO0FBQ0EsYUFBT2YsVUFBUCxDQUhFLENBR2lCO0FBQ3BCLEtBSkQsQ0FJRSxPQUFPUCxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTFCLE1BQU0sQ0FBQzJCLEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JELFNBQXhCLENBQU47QUFDRDtBQUNGLEdBM0JZO0FBNEJiLHNCQUFvQixTQUFTeUIsZUFBVCxDQUF5QmxCLFVBQXpCLEVBQXFDO0FBQ3ZEN0IsU0FBSyxDQUFDNkIsVUFBRCxFQUFhYixNQUFiLENBQUw7O0FBRUEsUUFBSTtBQUNGLGFBQU9RLFNBQVMsQ0FBQ1osTUFBVixDQUFpQmlCLFVBQWpCLENBQVA7QUFDRCxLQUZELENBRUUsT0FBT1AsU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUkxQixNQUFNLENBQUMyQixLQUFYLENBQWlCLEtBQWpCLEVBQXdCRCxTQUF4QixDQUFOO0FBQ0Q7QUFDRjtBQXBDWSxDQUFmO0FBdUNBb0IsU0FBUyxDQUFDO0FBQ1J2QixTQUFPLEVBQUUsQ0FDUCxrQkFETyxFQUVQLGtCQUZPLEVBR1Asa0JBSE8sQ0FERDtBQU1SNkIsT0FBSyxFQUFFLENBTkM7QUFPUkMsV0FBUyxFQUFFO0FBUEgsQ0FBRCxDQUFULEM7Ozs7Ozs7Ozs7O0FDNUNBLElBQUlyRCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVUgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSW1ELE9BQUo7QUFBWXJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ21ELFdBQU8sR0FBQ25ELENBQVI7QUFBVTs7QUFBdEIsQ0FBekIsRUFBaUQsQ0FBakQ7QUFJeElILE1BQU0sQ0FBQ08sT0FBUCxDQUFlLFNBQWYsRUFBMEIsU0FBU2dELE9BQVQsR0FBbUI7QUFDM0MsU0FBT0QsT0FBTyxDQUFDN0MsSUFBUixFQUFQO0FBQ0QsQ0FGRCxFOzs7Ozs7Ozs7OztBQ0pBLElBQUlDLEtBQUo7QUFBVVQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSVEsWUFBSjtBQUFpQlYsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDUSxnQkFBWSxHQUFDUixDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBSzdFLE1BQU1tRCxPQUFPLEdBQUcsSUFBSTVDLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixTQUFyQixDQUFoQjtBQUVBMEMsT0FBTyxDQUFDekMsS0FBUixDQUFjO0FBQ1pDLFFBQU0sRUFBRSxNQUFNLEtBREY7QUFFWkMsUUFBTSxFQUFFLE1BQU0sS0FGRjtBQUdaQyxRQUFNLEVBQUUsTUFBTTtBQUhGLENBQWQ7QUFNQXNDLE9BQU8sQ0FBQ3JDLElBQVIsQ0FBYTtBQUNYSCxRQUFNLEVBQUUsTUFBTSxJQURIO0FBRVhDLFFBQU0sRUFBRSxNQUFNLElBRkg7QUFHWEMsUUFBTSxFQUFFLE1BQU07QUFISCxDQUFiO0FBTUFzQyxPQUFPLENBQUNwQyxNQUFSLEdBQWlCLElBQUlQLFlBQUosQ0FBaUI7QUFDaENRLE1BQUksRUFBRUM7QUFEMEIsQ0FBakIsQ0FBakI7QUFJQWtDLE9BQU8sQ0FBQ2pDLFlBQVIsQ0FBcUJpQyxPQUFPLENBQUNwQyxNQUE3QjtBQXZCQWpCLE1BQU0sQ0FBQ3FCLGFBQVAsQ0F5QmVnQyxPQXpCZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUl0RCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVUgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSW1ELE9BQUo7QUFBWXJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ21ELFdBQU8sR0FBQ25ELENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFJeElILE1BQU0sQ0FBQ3VCLE9BQVAsQ0FBZTtBQUNiLG9CQUFrQixTQUFTaUMsYUFBVCxDQUF1QkMsTUFBdkIsRUFBK0I7QUFDL0NyRCxTQUFLLENBQUNxRCxNQUFELEVBQVM7QUFDWnRDLFVBQUksRUFBRUM7QUFETSxLQUFULENBQUw7O0FBSUEsUUFBSTtBQUNGLGFBQU9rQyxPQUFPLENBQUN4QyxNQUFSLENBQWUyQyxNQUFmLENBQVA7QUFDRCxLQUZELENBRUUsT0FBTy9CLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJMUIsTUFBTSxDQUFDMkIsS0FBWCxDQUFpQixLQUFqQixFQUF3QkQsU0FBeEIsQ0FBTjtBQUNEO0FBQ0Y7QUFYWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSTFCLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJdUQsTUFBSjtBQUFXekQsTUFBTSxDQUFDQyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDdUQsVUFBTSxHQUFDdkQsQ0FBUDtBQUFTOztBQUFyQixDQUF4QixFQUErQyxDQUEvQztBQUl2SUgsTUFBTSxDQUFDTyxPQUFQLENBQWUsUUFBZixFQUF5QixTQUFTb0QsTUFBVCxHQUFrQjtBQUN6QyxTQUFPRCxNQUFNLENBQUNqRCxJQUFQLEVBQVA7QUFDRCxDQUZELEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSUMsS0FBSjtBQUFVVCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNRLE9BQUssQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNPLFNBQUssR0FBQ1AsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJUSxZQUFKO0FBQWlCVixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNRLGdCQUFZLEdBQUNSLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFLN0UsTUFBTXVELE1BQU0sR0FBRyxJQUFJaEQsS0FBSyxDQUFDRSxVQUFWLENBQXFCLFFBQXJCLENBQWY7QUFFQThDLE1BQU0sQ0FBQzdDLEtBQVAsQ0FBYTtBQUNYQyxRQUFNLEVBQUUsTUFBTSxLQURIO0FBRVhDLFFBQU0sRUFBRSxNQUFNLEtBRkg7QUFHWEMsUUFBTSxFQUFFLE1BQU07QUFISCxDQUFiO0FBTUEwQyxNQUFNLENBQUN6QyxJQUFQLENBQVk7QUFDVkgsUUFBTSxFQUFFLE1BQU0sSUFESjtBQUVWQyxRQUFNLEVBQUUsTUFBTSxJQUZKO0FBR1ZDLFFBQU0sRUFBRSxNQUFNO0FBSEosQ0FBWjtBQU1BMEMsTUFBTSxDQUFDeEMsTUFBUCxHQUFnQixJQUFJUCxZQUFKLENBQWlCO0FBQy9CUSxNQUFJLEVBQUVDO0FBRHlCLENBQWpCLENBQWhCO0FBSUFzQyxNQUFNLENBQUNyQyxZQUFQLENBQW9CcUMsTUFBTSxDQUFDeEMsTUFBM0I7QUF2QkFqQixNQUFNLENBQUNxQixhQUFQLENBeUJlb0MsTUF6QmYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJMUQsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUl1RCxNQUFKO0FBQVd6RCxNQUFNLENBQUNDLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUN1RCxVQUFNLEdBQUN2RCxDQUFQO0FBQVM7O0FBQXJCLENBQXZCLEVBQThDLENBQTlDO0FBSXZJSCxNQUFNLENBQUN1QixPQUFQLENBQWU7QUFDYixtQkFBaUIsU0FBU3FDLFlBQVQsQ0FBc0JDLEtBQXRCLEVBQTZCO0FBQzVDekQsU0FBSyxDQUFDeUQsS0FBRCxFQUFRO0FBQ1gxQyxVQUFJLEVBQUVDO0FBREssS0FBUixDQUFMOztBQUlBLFFBQUk7QUFDRixhQUFPc0MsTUFBTSxDQUFDNUMsTUFBUCxDQUFjK0MsS0FBZCxDQUFQO0FBQ0QsS0FGRCxDQUVFLE9BQU9uQyxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTFCLE1BQU0sQ0FBQzJCLEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JELFNBQXhCLENBQU47QUFDRDtBQUNGO0FBWFksQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBLElBQUkxQixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVUgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTJELFlBQUo7QUFBaUI3RCxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQkFBWixFQUE4QjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDMkQsZ0JBQVksR0FBQzNELENBQWI7QUFBZTs7QUFBM0IsQ0FBOUIsRUFBMkQsQ0FBM0Q7QUFJN0lILE1BQU0sQ0FBQ08sT0FBUCxDQUFlLGNBQWYsRUFBK0IsU0FBU3dELFlBQVQsR0FBd0I7QUFDckQsU0FBT0QsWUFBWSxDQUFDckQsSUFBYixFQUFQO0FBQ0QsQ0FGRCxFOzs7Ozs7Ozs7OztBQ0pBLElBQUlDLEtBQUo7QUFBVVQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSVEsWUFBSjtBQUFpQlYsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDUSxnQkFBWSxHQUFDUixDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBSzdFLE1BQU0yRCxZQUFZLEdBQUcsSUFBSXBELEtBQUssQ0FBQ0UsVUFBVixDQUFxQixjQUFyQixDQUFyQjtBQUVBa0QsWUFBWSxDQUFDakQsS0FBYixDQUFtQjtBQUNqQkMsUUFBTSxFQUFFLE1BQU0sS0FERztBQUVqQkMsUUFBTSxFQUFFLE1BQU0sS0FGRztBQUdqQkMsUUFBTSxFQUFFLE1BQU07QUFIRyxDQUFuQjtBQU1BOEMsWUFBWSxDQUFDN0MsSUFBYixDQUFrQjtBQUNoQkgsUUFBTSxFQUFFLE1BQU0sSUFERTtBQUVoQkMsUUFBTSxFQUFFLE1BQU0sSUFGRTtBQUdoQkMsUUFBTSxFQUFFLE1BQU07QUFIRSxDQUFsQjtBQU1BOEMsWUFBWSxDQUFDNUMsTUFBYixHQUFzQixJQUFJUCxZQUFKLENBQWlCO0FBQ3JDUSxNQUFJLEVBQUVDO0FBRCtCLENBQWpCLENBQXRCO0FBSUEwQyxZQUFZLENBQUN6QyxZQUFiLENBQTBCeUMsWUFBWSxDQUFDNUMsTUFBdkM7QUF2QkFqQixNQUFNLENBQUNxQixhQUFQLENBeUJld0MsWUF6QmYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJOUQsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUkyRCxZQUFKO0FBQWlCN0QsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQzJELGdCQUFZLEdBQUMzRCxDQUFiO0FBQWU7O0FBQTNCLENBQTdCLEVBQTBELENBQTFEO0FBQTZELElBQUkyQyxTQUFKO0FBQWM3QyxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDMkMsYUFBUyxHQUFDM0MsQ0FBVjtBQUFZOztBQUF4QixDQUF2QyxFQUFpRSxDQUFqRTtBQUt4TkgsTUFBTSxDQUFDdUIsT0FBUCxDQUFlO0FBQ2IseUJBQXVCLFNBQVN5QyxrQkFBVCxDQUE0QkMsV0FBNUIsRUFBeUM7QUFDOUQ3RCxTQUFLLENBQUM2RCxXQUFELEVBQWM7QUFDakI5QyxVQUFJLEVBQUVDO0FBRFcsS0FBZCxDQUFMOztBQUlBLFFBQUk7QUFDRixhQUFPMEMsWUFBWSxDQUFDaEQsTUFBYixDQUFvQm1ELFdBQXBCLENBQVA7QUFDRCxLQUZELENBRUUsT0FBT3ZDLFNBQVAsRUFBa0I7QUFDbEIsWUFBTSxJQUFJMUIsTUFBTSxDQUFDMkIsS0FBWCxDQUFpQixLQUFqQixFQUF3QkQsU0FBeEIsQ0FBTjtBQUNEO0FBQ0Y7QUFYWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSTFCLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJK0Qsb0JBQUo7QUFBeUJqRSxNQUFNLENBQUNDLElBQVAsQ0FBWSw4QkFBWixFQUEyQztBQUFDZ0Usc0JBQW9CLENBQUMvRCxDQUFELEVBQUc7QUFBQytELHdCQUFvQixHQUFDL0QsQ0FBckI7QUFBdUI7O0FBQWhELENBQTNDLEVBQTZGLENBQTdGO0FBQWdHLElBQUkyQyxTQUFKO0FBQWM3QyxNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDMkMsYUFBUyxHQUFDM0MsQ0FBVjtBQUFZOztBQUF4QixDQUExQyxFQUFvRSxDQUFwRTtBQUtuUUgsTUFBTSxDQUFDdUIsT0FBUCxDQUFlO0FBQ2IsK0JBQTZCLFNBQVM0Qyx3QkFBVCxDQUFrQ0MsUUFBbEMsRUFBNEM7QUFDdkVoRSxTQUFLLENBQUNnRSxRQUFELEVBQVdDLEtBQVgsQ0FBTDs7QUFFQSxRQUFJO0FBQ0YsWUFBTUMsZ0JBQWdCLEdBQUcsRUFBekI7QUFDQUYsY0FBUSxDQUFDRyxPQUFULENBQWtCQyxPQUFELElBQWE7QUFDNUIsWUFBSU4sb0JBQW9CLENBQUNPLGNBQXJCLENBQW9DQyxPQUFwQyxDQUE0QztBQUFFRjtBQUFGLFNBQTVDLENBQUosRUFBOEQ7QUFDNURGLDBCQUFnQixDQUFDSyxJQUFqQixDQUFzQkgsT0FBdEI7QUFDRDtBQUNGLE9BSkQ7QUFLQSxhQUFPRixnQkFBZ0IsQ0FBQ00sSUFBakIsRUFBUDtBQUNELEtBUkQsQ0FRRSxPQUFPbEQsU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUkxQixNQUFNLENBQUMyQixLQUFYLENBQWlCLEtBQWpCLEVBQXdCRCxTQUF4QixDQUFOO0FBQ0Q7QUFDRjtBQWZZLENBQWY7QUFrQkFvQixTQUFTLENBQUM7QUFDUnZCLFNBQU8sRUFBRSxDQUNQLDJCQURPLENBREQ7QUFJUjZCLE9BQUssRUFBRSxDQUpDO0FBS1JDLFdBQVMsRUFBRTtBQUxILENBQUQsQ0FBVCxDOzs7Ozs7Ozs7OztBQ3ZCQSxJQUFJckQsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUkwRSxNQUFKO0FBQVc1RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUMwRSxVQUFNLEdBQUMxRSxDQUFQO0FBQVM7O0FBQXJCLENBQXhCLEVBQStDLENBQS9DO0FBSXZJSCxNQUFNLENBQUNPLE9BQVAsQ0FBZSxRQUFmLEVBQXlCLFNBQVN1RSxNQUFULEdBQWtCO0FBQ3pDLFNBQU9ELE1BQU0sQ0FBQ3BFLElBQVAsRUFBUDtBQUNELENBRkQsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJQyxLQUFKO0FBQVVULE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1EsT0FBSyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sU0FBSyxHQUFDUCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlRLFlBQUo7QUFBaUJWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ1EsZ0JBQVksR0FBQ1IsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDtBQUs3RSxNQUFNMEUsTUFBTSxHQUFHLElBQUluRSxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsUUFBckIsQ0FBZjtBQUVBaUUsTUFBTSxDQUFDaEUsS0FBUCxDQUFhO0FBQ1hDLFFBQU0sRUFBRSxNQUFNLEtBREg7QUFFWEMsUUFBTSxFQUFFLE1BQU0sS0FGSDtBQUdYQyxRQUFNLEVBQUUsTUFBTTtBQUhILENBQWI7QUFNQTZELE1BQU0sQ0FBQzVELElBQVAsQ0FBWTtBQUNWSCxRQUFNLEVBQUUsTUFBTSxJQURKO0FBRVZDLFFBQU0sRUFBRSxNQUFNLElBRko7QUFHVkMsUUFBTSxFQUFFLE1BQU07QUFISixDQUFaO0FBTUE2RCxNQUFNLENBQUMzRCxNQUFQLEdBQWdCLElBQUlQLFlBQUosQ0FBaUI7QUFDL0JRLE1BQUksRUFBRUM7QUFEeUIsQ0FBakIsQ0FBaEI7QUFJQXlELE1BQU0sQ0FBQ3hELFlBQVAsQ0FBb0J3RCxNQUFNLENBQUMzRCxNQUEzQjtBQXZCQWpCLE1BQU0sQ0FBQ3FCLGFBQVAsQ0F5QmV1RCxNQXpCZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUk3RSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUo7QUFBVUgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTBFLE1BQUo7QUFBVzVFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQzBFLFVBQU0sR0FBQzFFLENBQVA7QUFBUzs7QUFBckIsQ0FBdkIsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSTJDLFNBQUo7QUFBYzdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUMyQyxhQUFTLEdBQUMzQyxDQUFWO0FBQVk7O0FBQXhCLENBQXZDLEVBQWlFLENBQWpFO0FBS3RNSCxNQUFNLENBQUN1QixPQUFQLENBQWU7QUFDYixtQkFBaUIsU0FBU3dELFlBQVQsQ0FBc0JDLEtBQXRCLEVBQTZCO0FBQzVDNUUsU0FBSyxDQUFDNEUsS0FBRCxFQUFRO0FBQ1g3RCxVQUFJLEVBQUVDO0FBREssS0FBUixDQUFMOztBQUlBLFFBQUk7QUFDRixhQUFPeUQsTUFBTSxDQUFDL0QsTUFBUCxDQUFja0UsS0FBZCxDQUFQO0FBQ0QsS0FGRCxDQUVFLE9BQU90RCxTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTFCLE1BQU0sQ0FBQzJCLEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JELFNBQXhCLENBQU47QUFDRDtBQUNGO0FBWFksQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBLElBQUkxQixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUk4RSxJQUFKO0FBQVNoRixNQUFNLENBQUNDLElBQVAsQ0FBWSxJQUFaLEVBQWlCO0FBQUMrRSxNQUFJLENBQUM5RSxDQUFELEVBQUc7QUFBQzhFLFFBQUksR0FBQzlFLENBQUw7QUFBTzs7QUFBaEIsQ0FBakIsRUFBbUMsQ0FBbkM7QUFBc0MsSUFBSStFLE1BQUo7QUFBV2pGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLE1BQVosRUFBbUI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQytFLFVBQU0sR0FBQy9FLENBQVA7QUFBUzs7QUFBckIsQ0FBbkIsRUFBMEMsQ0FBMUM7QUFBNkMsSUFBSWdGLFNBQUo7QUFBY2xGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ2dGLGFBQVMsR0FBQ2hGLENBQVY7QUFBWTs7QUFBeEIsQ0FBM0IsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSTBFLE1BQUo7QUFBVzVFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUMwRSxVQUFNLEdBQUMxRSxDQUFQO0FBQVM7O0FBQXJCLENBQWxDLEVBQXlELENBQXpEO0FBQTRELElBQUl1RCxNQUFKO0FBQVd6RCxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDdUQsVUFBTSxHQUFDdkQsQ0FBUDtBQUFTOztBQUFyQixDQUFsQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJMkQsWUFBSjtBQUFpQjdELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGlDQUFaLEVBQThDO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUMyRCxnQkFBWSxHQUFDM0QsQ0FBYjtBQUFlOztBQUEzQixDQUE5QyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJRSxlQUFKO0FBQW9CSixNQUFNLENBQUNDLElBQVAsQ0FBWSx1Q0FBWixFQUFvRDtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDRSxtQkFBZSxHQUFDRixDQUFoQjtBQUFrQjs7QUFBOUIsQ0FBcEQsRUFBb0YsQ0FBcEY7QUFBdUYsSUFBSW1ELE9BQUo7QUFBWXJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNtRCxXQUFPLEdBQUNuRCxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEO0FBVWpsQixNQUFNaUYsSUFBSSxHQUFHLElBQUlILElBQUosQ0FBU2pGLE1BQU0sQ0FBQ3FGLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCQyxRQUFqQyxDQUFiO0FBRUEsTUFBTUMsWUFBWSxHQUFHSixJQUFJLENBQUNLLEtBQTFCOztBQUNBTCxJQUFJLENBQUNLLEtBQUwsR0FBYSxDQUFDLEdBQUdDLElBQUosS0FBYTtBQUN4QkMsU0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFzQkYsSUFBdEI7QUFDQSxTQUFPRixZQUFZLENBQUNLLEtBQWIsQ0FBbUJULElBQW5CLEVBQXlCTSxJQUF6QixDQUFQO0FBQ0QsQ0FIRDs7QUFLQSxNQUFNSSxLQUFLLEdBQUcsQ0FBT0wsS0FBUCxFQUFjTSxNQUFkLDhCQUF5QjtBQUNyQyxNQUFJO0FBQ0YsVUFBTUMsTUFBTSxpQkFBU1osSUFBSSxDQUFDYSxPQUFMLEVBQVQsQ0FBWjtBQUNBLFVBQU1DLE1BQU0saUJBQVNGLE1BQU0sQ0FBQ1AsS0FBUCxDQUFhQSxLQUFiLEVBQW9CTSxNQUFwQixDQUFULENBQVo7QUFDQUcsVUFBTSxDQUFDQyxJQUFQLENBQVk1QixPQUFaLENBQXFCMkIsTUFBRCxJQUFZLENBQzlCO0FBQ0E7QUFDRCxLQUhEO0FBS0Esa0JBQU1GLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlLElBQWYsQ0FBTjtBQUNELEdBVEQsQ0FTRSxPQUFPMUUsU0FBUCxFQUFrQjtBQUNsQixVQUFNLElBQUlDLEtBQUosQ0FBVUQsU0FBUyxDQUFDMkUsT0FBcEIsQ0FBTjtBQUNEO0FBQ0YsQ0FiYSxDQUFkOztBQWVBLE1BQU1DLHlCQUF5QixHQUFHLENBQU9wRSxHQUFQLEVBQVlxRSxTQUFaLDhCQUEwQjtBQUMxRCxNQUFJO0FBQ0YsVUFBTVAsTUFBTSxpQkFBU1osSUFBSSxDQUFDYSxPQUFMLEVBQVQsQ0FBWjtBQUNBLFFBQUlSLEtBQUssR0FBSSxFQUFiOztBQUVBLFFBQUljLFNBQVMsSUFBSSxDQUFqQixFQUFvQjtBQUNsQmQsV0FBSyxHQUFJOzs7MkJBR1ljLFNBQVU7O2tDQUVIckUsR0FBSTtPQUxoQztBQU9ELEtBUkQsTUFRTztBQUNMdUQsV0FBSyxHQUFJOzs7MkJBR1ljLFNBQVU7O2tDQUVIckUsR0FBSTtPQUxoQztBQU9EOztBQUFBO0FBRUR5RCxXQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEyQ0gsS0FBM0M7QUFDQSxVQUFNUyxNQUFNLGlCQUFTSixLQUFLLENBQUNMLEtBQUQsQ0FBZCxDQUFaO0FBQ0Esa0JBQU1PLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlLElBQWYsQ0FBTjtBQUNELEdBekJELENBeUJFLE9BQU8xRSxTQUFQLEVBQWtCO0FBQ2xCLFVBQU0sSUFBSUMsS0FBSixDQUFVRCxTQUFTLENBQUMyRSxPQUFwQixDQUFOO0FBQ0Q7QUFDRixDQTdCaUMsQ0FBbEM7O0FBK0JBLE1BQU1HLG9CQUFvQixHQUFHLENBQU90RSxHQUFQLEVBQVl1RSxhQUFaLDhCQUE4QjtBQUN6RCxNQUFJO0FBQ0YsVUFBTVQsTUFBTSxpQkFBU1osSUFBSSxDQUFDYSxPQUFMLEVBQVQsQ0FBWixDQURFLENBR0Y7O0FBQ0EsVUFBTVIsS0FBSyxHQUFJOztzQ0FFbUJnQixhQUFjOzs7Ozt3QkFLNUJ2RSxHQUFJO0tBUHhCO0FBVUF5RCxXQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBWixFQUFzQ0gsS0FBdEM7QUFDQSxVQUFNUyxNQUFNLGlCQUFTRixNQUFNLENBQUNQLEtBQVAsQ0FBYUEsS0FBYixDQUFULENBQVo7QUFDQSxrQkFBTU8sTUFBTSxDQUFDSSxPQUFQLENBQWUsSUFBZixDQUFOO0FBQ0QsR0FqQkQsQ0FpQkUsT0FBTzFFLFNBQVAsRUFBa0I7QUFDbEIsVUFBTSxJQUFJQyxLQUFKLENBQVVELFNBQVMsQ0FBQzJFLE9BQXBCLENBQU47QUFDRDtBQUNGLENBckI0QixDQUE3Qjs7QUF1QkEsTUFBTUssY0FBYyxHQUFHLCtCQUFZO0FBQ2pDLE1BQUk7QUFDRixRQUFJQyxLQUFLLEdBQUcsSUFBSW5FLElBQUosRUFBWjtBQUNBLFVBQU13RCxNQUFNLGlCQUFTWixJQUFJLENBQUNhLE9BQUwsRUFBVCxDQUFaO0FBQ0EsVUFBTVIsS0FBSyxHQUFJOzs7Ozs7S0FBZjtBQVFBLFVBQU1TLE1BQU0saUJBQVNGLE1BQU0sQ0FBQ1AsS0FBUCxDQUFhQSxLQUFiLENBQVQsQ0FBWjtBQUNBUyxVQUFNLENBQUNDLElBQVAsQ0FBWTVCLE9BQVosQ0FBcUJxQyxHQUFELElBQVM7QUFDM0IsWUFBTTtBQUNKQyxzQkFBYyxFQUFFM0UsR0FEWjtBQUVKNEUsOEJBQXNCLEVBQUVDLGNBRnBCO0FBR0pDLDhCQUFzQixFQUFFUCxhQUhwQjtBQUlKUSxpQkFBUyxFQUFFQztBQUpQLFVBS0ZOLEdBTEosQ0FEMkIsQ0FRM0I7O0FBQ0EsVUFBSXpCLFNBQVMsQ0FBQ1QsT0FBVixDQUFrQnhDLEdBQWxCLENBQUosRUFBNEI7QUFDMUIsY0FBTWlGLG1CQUFtQixHQUFHaEMsU0FBUyxDQUFDVCxPQUFWLENBQWtCeEMsR0FBbEIsRUFBdUI2RSxjQUFuRDtBQUVBcEIsZUFBTyxDQUFDQyxHQUFSLENBQVksbUNBQVosRUFBaURlLEtBQWpELEVBQXdEekUsR0FBeEQsRUFIMEIsQ0FJMUI7O0FBQ0EsWUFBSSxDQUFDNkUsY0FBRCxJQUFtQixDQUFDSSxtQkFBeEIsRUFBNkM7QUFDM0NoQyxtQkFBUyxDQUFDcEUsTUFBVixDQUFpQm1CLEdBQWpCLEVBQXNCO0FBQ3BCZ0IsZ0JBQUksRUFBRTtBQUNKdUQsMkJBREk7QUFFSk0sNEJBQWMsRUFBRU4sYUFGWjtBQUdKVyx3QkFBVSxFQUFFLFFBSFI7QUFJSmIsdUJBQVMsRUFBRSxDQUpQO0FBS0pjLHVCQUFTLEVBQUVWLEtBTFA7QUFNSk87QUFOSTtBQURjLFdBQXRCO0FBV0FWLDhCQUFvQixDQUFDdEUsR0FBRCxFQUFNdUUsYUFBTixDQUFwQjtBQUNELFNBYkQsTUFhTztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQWQsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHFFQUFaLEVBQW1GMUQsR0FBbkY7QUFDQSxnQkFBTW9GLElBQUksR0FBR3BDLE1BQU0sQ0FBQ3FDLFNBQVAsQ0FBaUJkLGFBQWEsQ0FBQ2UsU0FBZCxDQUF3QixDQUF4QixFQUEwQixLQUExQixLQUFvQyxFQUFyRCxFQUF5REwsbUJBQW1CLENBQUNLLFNBQXBCLENBQThCLENBQTlCLEVBQWdDLEtBQWhDLEtBQTBDLEVBQW5HLENBQWIsQ0FSSyxDQVNMOztBQUNBN0IsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHVCQUFaLEVBQXFDZSxLQUFyQztBQUNBLGNBQUlKLFNBQVMsR0FBRyxDQUFoQjtBQUVBLGdCQUFNTCxNQUFNLEdBQUdvQixJQUFJLENBQUNHLEdBQUwsQ0FBUyxVQUFTQyxJQUFULEVBQWVDLEtBQWYsRUFBc0I7QUFDNUMsZ0JBQUlELElBQUksQ0FBQ0UsS0FBTCxJQUFjRixJQUFJLENBQUNHLE9BQXZCLEVBQWdDO0FBQzlCdEIsdUJBQVMsSUFBSSxDQUFiO0FBQ0Q7QUFBQyxXQUhXLENBQWYsQ0FiSyxDQWtCTDtBQUNBOztBQUNBLGNBQUlBLFNBQVMsSUFBSSxDQUFiLEtBQW1CWSxtQkFBbUIsQ0FBQ1csTUFBcEIsR0FBNkIsS0FBN0IsSUFBdUNyQixhQUFhLENBQUNxQixNQUFkLEdBQXVCLEtBQXhCLElBQWtDWCxtQkFBbUIsQ0FBQ1csTUFBcEIsSUFBOEJyQixhQUFhLENBQUNxQixNQUF2SSxDQUFKLEVBQW9KO0FBQ2xKdkIscUJBQVMsR0FBRyxDQUFaO0FBQ0Q7O0FBQUEsV0F0QkksQ0F3Qkw7O0FBQ0FwQixtQkFBUyxDQUFDcEUsTUFBVixDQUFpQm1CLEdBQWpCLEVBQXNCO0FBQ3BCZ0IsZ0JBQUksRUFBRTtBQUNKdUQsMkJBREk7QUFFSlcsd0JBQVUsRUFBRWIsU0FBUyxLQUFLLENBQWQsR0FBa0IsUUFBbEIsR0FBNkIsUUFGckM7QUFHSkEsdUJBSEk7QUFJSmMsdUJBQVMsRUFBRVYsS0FKUDtBQUtKTztBQUxJO0FBRGMsV0FBdEIsRUF6QkssQ0FtQ0w7O0FBQ0F2QixpQkFBTyxDQUFDQyxHQUFSLENBQVkscURBQVosRUFBbUVXLFNBQW5FO0FBQ0FELG1DQUF5QixDQUFDcEUsR0FBRCxFQUFNcUUsU0FBTixDQUF6QjtBQUNEO0FBQ0Y7QUFDRixLQW5FRDtBQXFFQSxrQkFBTVAsTUFBTSxDQUFDSSxPQUFQLENBQWUsSUFBZixDQUFOO0FBQ0QsR0FsRkQsQ0FrRkUsT0FBTzFFLFNBQVAsRUFBa0I7QUFDbEIsVUFBTSxJQUFJQyxLQUFKLENBQVVELFNBQVMsQ0FBQzJFLE9BQXBCLENBQU47QUFDRDtBQUNGLENBdEZzQixDQUF2QixDLENBd0ZBOzs7QUFDQSxNQUFNMEIsa0JBQWtCLEdBQVVoRyxNQUFQLDZCQUFrQjtBQUMzQyxNQUFJO0FBQ0Y7QUFDQSxRQUFJaUcsZUFBZSxHQUFHLENBQUMsSUFBRCxFQUFPLE1BQVAsQ0FBdEI7QUFDQSxRQUFJQyxvQkFBb0IsR0FBRyxDQUFDLElBQUQsRUFBTSxJQUFOLEVBQVcsSUFBWCxFQUFnQixJQUFoQixFQUFxQixLQUFyQixDQUEzQjtBQUVBLFVBQU1qQyxNQUFNLGlCQUFTWixJQUFJLENBQUNhLE9BQUwsRUFBVCxDQUFaLENBTEUsQ0FNRjs7QUFDQSxVQUFNUixLQUFLLEdBQUk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBQWY7QUE0QkEsVUFBTVMsTUFBTSxpQkFBU0YsTUFBTSxDQUFDUCxLQUFQLENBQWFBLEtBQWIsQ0FBVCxDQUFaLENBbkNFLENBcUNGO0FBQ0E7O0FBQ0EvQixVQUFNLENBQUMxQyxNQUFQLENBQWMsRUFBZDtBQUNBNkQsVUFBTSxDQUFDN0QsTUFBUCxDQUFjLEVBQWQ7QUFDQThDLGdCQUFZLENBQUM5QyxNQUFiLENBQW9CLEVBQXBCO0FBQ0FzQyxXQUFPLENBQUN0QyxNQUFSLENBQWUsRUFBZjtBQUNBbUUsYUFBUyxDQUFDbkUsTUFBVixDQUFpQixFQUFqQjtBQUNBWCxtQkFBZSxDQUFDVyxNQUFoQixDQUF1QixFQUF2QjtBQUVBLFVBQU1rSCxTQUFTLEdBQUcsSUFBSUMsR0FBSixFQUFsQjtBQUNBLFVBQU1DLFNBQVMsR0FBRyxJQUFJRCxHQUFKLEVBQWxCO0FBQ0EsVUFBTUUsZUFBZSxHQUFHLElBQUlGLEdBQUosRUFBeEI7QUFDQSxVQUFNRyxVQUFVLEdBQUcsSUFBSUgsR0FBSixFQUFuQjtBQUVBeEMsV0FBTyxDQUFDQyxHQUFSLENBQVksa0NBQVo7QUFDQU0sVUFBTSxDQUFDQyxJQUFQLENBQVk1QixPQUFaLENBQXFCcUMsR0FBRCxJQUFTO0FBQzNCLFlBQU0yQixRQUFRLEdBQUc7QUFDZnJHLFdBQUcsRUFBRTBFLEdBQUcsQ0FBQ0MsY0FETTtBQUVmL0UsYUFBSyxFQUFFQyxNQUZRO0FBR2ZaLFlBQUksRUFBRXlGLEdBQUcsQ0FBQzRCLGdCQUhLO0FBSWZDLG9CQUFZLEVBQUU3QixHQUFHLENBQUM4QixlQUpIO0FBS2ZDLGVBQU8sRUFBRS9CLEdBQUcsQ0FBQ2dDLFVBTEU7QUFNZi9FLGFBQUssRUFBRStDLEdBQUcsQ0FBQ2lDLFlBTkk7QUFPZjVFLG1CQUFXLEVBQUUyQyxHQUFHLENBQUNrQyxjQVBGO0FBUWZyRixjQUFNLEVBQUVtRCxHQUFHLENBQUNtQyxRQVJHO0FBU2ZDLG9CQUFZLEVBQUVwQyxHQUFHLENBQUNxQyxlQVRIO0FBVWZDLG1CQUFXLEVBQUV0QyxHQUFHLENBQUN1QyxjQVZGO0FBVWtCO0FBQ2pDL0Isa0JBQVUsRUFBRSxPQVhHO0FBWWZnQyxrQkFBVSxFQUFFeEMsR0FBRyxDQUFDeUMsYUFaRDtBQVlnQjtBQUMvQkMsZUFBTyxFQUFFMUMsR0FBRyxDQUFDMkMsU0FiRTtBQWNmeEMsc0JBQWMsRUFBRUgsR0FBRyxDQUFDRSxzQkFkTDtBQWM2QjtBQUM1Q0wscUJBQWEsRUFBRUcsR0FBRyxDQUFDSSxzQkFmSjtBQWdCZlQsaUJBQVMsRUFBRUssR0FBRyxDQUFDNEMsWUFoQkE7QUFpQmZDLGdCQUFRLEVBQUU3QyxHQUFHLENBQUM4QyxVQUFKLEdBQWlCLElBQWpCLEdBQXdCLEtBakJuQjtBQWtCZkMsbUJBQVcsRUFBRS9DLEdBQUcsQ0FBQ2dELFNBQUosR0FBZ0IsSUFBaEIsR0FBdUIsS0FsQnJCO0FBbUJmQyxrQkFBVSxFQUFFakQsR0FBRyxDQUFDa0QsZ0JBbkJEO0FBb0JmQyxzQkFBYyxFQUFFbkQsR0FBRyxDQUFDb0Qsa0JBQUosR0FBeUIsSUFBekIsR0FBZ0MsS0FwQmpDO0FBcUJmQyx3QkFBZ0IsRUFBRXJELEdBQUcsQ0FBQ3NELHFCQXJCUDtBQXNCZkMsZ0JBQVEsRUFBRW5DLGVBQWUsQ0FBQ29DLFFBQWhCLENBQXlCeEQsR0FBRyxDQUFDeUQsV0FBN0IsSUFBNEN6RCxHQUFHLENBQUN5RCxXQUFoRCxHQUE4RCxNQXRCekQ7QUF1QmY1SSxzQkFBYyxFQUFFd0csb0JBQW9CLENBQUNtQyxRQUFyQixDQUE4QnhELEdBQUcsQ0FBQzBELGlCQUFsQyxJQUF1RDFELEdBQUcsQ0FBQzBELGlCQUEzRCxHQUErRTtBQXZCaEYsT0FBakI7QUEyQkEzRSxhQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQTBCMkMsUUFBMUI7QUFDQXBELGVBQVMsQ0FBQ3JFLE1BQVYsQ0FBaUJ5SCxRQUFqQjtBQUNBTCxlQUFTLENBQUNxQyxHQUFWLENBQWMzRCxHQUFHLENBQUNpQyxZQUFsQjtBQUNBVCxlQUFTLENBQUNtQyxHQUFWLENBQWMzRCxHQUFHLENBQUNxQyxlQUFsQjtBQUNBWixxQkFBZSxDQUFDa0MsR0FBaEIsQ0FBb0IzRCxHQUFHLENBQUNrQyxjQUF4QjtBQUNBUixnQkFBVSxDQUFDaUMsR0FBWCxDQUFlM0QsR0FBRyxDQUFDbUMsUUFBbkI7QUFDRCxLQWxDRDtBQW9DQWIsYUFBUyxDQUFDM0QsT0FBVixDQUFrQnBELElBQUksSUFBSXVDLE1BQU0sQ0FBQzVDLE1BQVAsQ0FBYztBQUFFSztBQUFGLEtBQWQsQ0FBMUI7QUFDQWlILGFBQVMsQ0FBQzdELE9BQVYsQ0FBa0JwRCxJQUFJLElBQUkwRCxNQUFNLENBQUMvRCxNQUFQLENBQWM7QUFBRUs7QUFBRixLQUFkLENBQTFCO0FBQ0FrSCxtQkFBZSxDQUFDOUQsT0FBaEIsQ0FBd0JwRCxJQUFJLElBQUkyQyxZQUFZLENBQUNoRCxNQUFiLENBQW9CO0FBQUVLO0FBQUYsS0FBcEIsQ0FBaEM7QUFDQW1ILGNBQVUsQ0FBQy9ELE9BQVgsQ0FBbUJwRCxJQUFJLElBQUltQyxPQUFPLENBQUN4QyxNQUFSLENBQWU7QUFBRUs7QUFBRixLQUFmLENBQTNCLEVBM0ZFLENBNkZGOztBQUNBZCxtQkFBZSxDQUFDUyxNQUFoQixDQUF1QjtBQUFFSyxVQUFJLEVBQUU7QUFBUixLQUF2QjtBQUNBZCxtQkFBZSxDQUFDUyxNQUFoQixDQUF1QjtBQUFFSyxVQUFJLEVBQUU7QUFBUixLQUF2QjtBQUNBZCxtQkFBZSxDQUFDUyxNQUFoQixDQUF1QjtBQUFFSyxVQUFJLEVBQUU7QUFBUixLQUF2QjtBQUNBZCxtQkFBZSxDQUFDUyxNQUFoQixDQUF1QjtBQUFFSyxVQUFJLEVBQUU7QUFBUixLQUF2QjtBQUNBZCxtQkFBZSxDQUFDUyxNQUFoQixDQUF1QjtBQUFFSyxVQUFJLEVBQUU7QUFBUixLQUF2QjtBQUVBd0UsV0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF3QmxDLE1BQU0sQ0FBQ2pELElBQVAsQ0FBWSxFQUFaLEVBQWdCcUYsS0FBaEIsRUFBeEI7QUFDQUgsV0FBTyxDQUFDQyxHQUFSLENBQVksbUJBQVosRUFBaUN2RixlQUFlLENBQUNJLElBQWhCLENBQXFCLEVBQXJCLEVBQXlCcUYsS0FBekIsRUFBakM7QUFFQSxrQkFBTUUsTUFBTSxDQUFDSSxPQUFQLENBQWUsSUFBZixDQUFOO0FBQ0QsR0F4R0QsQ0F3R0UsT0FBTzFFLFNBQVAsRUFBa0I7QUFDbEIsVUFBTSxJQUFJQyxLQUFKLENBQVVELFNBQVMsQ0FBQzJFLE9BQXBCLENBQU47QUFDRDtBQUNGLENBNUcwQixDQUEzQjs7QUE4R0EsTUFBTXZGLE1BQU0sR0FBVXlILFFBQVAsNkJBQW9CO0FBQ2pDLE1BQUk7QUFDRixVQUFNdkMsTUFBTSxpQkFBU1osSUFBSSxDQUFDYSxPQUFMLEVBQVQsQ0FBWjtBQUNBLFVBQU07QUFDSi9ELFNBREk7QUFFSkosV0FGSTtBQUdKWCxVQUhJO0FBSUpzSCxrQkFKSTtBQUtKeEUsaUJBTEk7QUFNSlIsWUFOSTtBQU9KdUYsa0JBUEk7QUFRSmEsZ0JBUkk7QUFTSlgsaUJBVEk7QUFVSmEsb0JBVkk7QUFXSlgsZ0JBWEk7QUFZSkUsYUFaSTtBQWFKekYsV0FiSTtBQWNKNEYsY0FkSTtBQWVKRSxpQkFmSTtBQWdCSk0sc0JBaEJJO0FBaUJKRSxjQWpCSTtBQWtCSnhCLGFBbEJJO0FBbUJKbEg7QUFuQkksUUFvQkY4RyxRQXBCSjtBQXNCQSxVQUFNOUMsS0FBSyxHQUFJOzs7Ozs7Ozs7V0FTUnZELEdBQUksT0FBTWYsSUFBSyxPQUFNOEMsV0FBWSxPQUFNUixNQUFPO1dBQzlDdUYsWUFBYSxhQUFZRSxXQUFZLDBCQUF5QkUsVUFBVztpQkFDbkVFLE9BQVEsYUFBWXpGLEtBQU0sT0FBTS9CLEtBQU0sTUFBSytILFVBQVc7VUFDN0RFLGNBQWMsR0FBRyxDQUFILEdBQU8sQ0FBRSxLQUFJTixRQUFRLEdBQUcsQ0FBSCxHQUFPLENBQUUsS0FBSUUsV0FBVyxHQUFHLENBQUgsR0FBTyxDQUFFO1dBQ25FTSxnQkFBaUIsT0FBTUUsUUFBUyxPQUFNMUIsWUFBYSxPQUFNRSxPQUFRO1dBQ2pFbEgsY0FBZTs7S0FkdEI7QUFrQkEsVUFBTStJLFVBQVUsR0FBRy9FLEtBQUssQ0FBQ2dGLE9BQU4sQ0FBYyxlQUFkLEVBQStCLE9BQS9CLENBQW5CO0FBRUE5RSxXQUFPLENBQUNDLEdBQVIsQ0FBWSwyQkFBWixFQUF5QzRFLFVBQXpDO0FBQ0EsVUFBTXRFLE1BQU0saUJBQVNGLE1BQU0sQ0FBQ1AsS0FBUCxDQUFhK0UsVUFBYixDQUFULENBQVo7QUFDQSxrQkFBTXhFLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlLElBQWYsQ0FBTjtBQUNELEdBL0NELENBK0NFLE9BQU8xRSxTQUFQLEVBQWtCO0FBQ2xCLFVBQU0sSUFBSUMsS0FBSixDQUFVRCxTQUFTLENBQUMyRSxPQUFwQixDQUFOO0FBQ0Q7QUFDRixDQW5EYyxDQUFmOztBQXFEQSxNQUFNdEYsTUFBTSxHQUFVd0gsUUFBUCw2QkFBb0I7QUFDakMsTUFBSTtBQUNGLFVBQU12QyxNQUFNLGlCQUFTWixJQUFJLENBQUNhLE9BQUwsRUFBVCxDQUFaO0FBQ0EsVUFBTTtBQUNKL0QsU0FESTtBQUVKSixXQUZJO0FBR0pYLFVBSEk7QUFJSnNILGtCQUpJO0FBS0p4RSxpQkFMSTtBQU1KUixZQU5JO0FBT0p1RixrQkFQSTtBQVFKYSxnQkFSSTtBQVNKWCxpQkFUSTtBQVVKekMsbUJBVkk7QUFXSnNELG9CQVhJO0FBWUpYLGdCQVpJO0FBYUpFLGFBYkk7QUFjSnpGLFdBZEk7QUFlSjRGLGNBZkk7QUFnQkpFLGlCQWhCSTtBQWlCSk0sc0JBakJJO0FBa0JKRSxjQWxCSTtBQW1CSnhCLGFBbkJJO0FBb0JKbEg7QUFwQkksUUFxQkY4RyxRQXJCSixDQUZFLENBeUJGOztBQUNBLFVBQU05QyxLQUFLLEdBQUk7OzBCQUVPdEUsSUFBSzt3QkFDUDhDLFdBQVk7a0JBQ2xCUixNQUFPO3lCQUNBdUYsWUFBYTs4QkFDUkUsV0FBWTtzQ0FDSnpDLGFBQWM7OzZCQUV2QjJDLFVBQVc7eUJBQ2ZFLE9BQVE7c0JBQ1h6RixLQUFNO3VCQUNML0IsS0FBTTt5QkFDSitILFVBQVc7MkJBQ1RFLGNBQWMsR0FBRyxDQUFILEdBQU8sQ0FBRTttQkFDL0JOLFFBQVEsR0FBRyxDQUFILEdBQU8sQ0FBRTtrQkFDbEJFLFdBQVcsR0FBRyxDQUFILEdBQU8sQ0FBRTsrQkFDUE0sZ0JBQWlCO3FCQUMzQkUsUUFBUzt5QkFDTDFCLFlBQWE7b0JBQ2xCRSxPQUFROzJCQUNEbEgsY0FBZTs7d0JBRWxCUyxHQUFJO0tBdkJ4QixDQTFCRSxDQW9ERjs7QUFDQXlELFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUFaLEVBQXVDSCxLQUF2QztBQUNBLFVBQU1TLE1BQU0saUJBQVNGLE1BQU0sQ0FBQ1AsS0FBUCxDQUFhQSxLQUFiLENBQVQsQ0FBWjtBQUNBLGtCQUFNTyxNQUFNLENBQUNJLE9BQVAsQ0FBZSxJQUFmLENBQU47QUFDRCxHQXhERCxDQXdERSxPQUFPMUUsU0FBUCxFQUFrQjtBQUNsQixVQUFNLElBQUlDLEtBQUosQ0FBVUQsU0FBUyxDQUFDMkUsT0FBcEIsQ0FBTjtBQUNEO0FBQ0YsQ0E1RGMsQ0FBZjs7QUE4REEsTUFBTXFFLE9BQU8sR0FBVW5DLFFBQVAsNkJBQW9CO0FBQ2xDLE1BQUk7QUFDRixVQUFNdkMsTUFBTSxpQkFBU1osSUFBSSxDQUFDYSxPQUFMLEVBQVQsQ0FBWjtBQUNBLFVBQU07QUFDSi9ELFNBREk7QUFFSko7QUFGSSxRQUdGeUcsUUFISjtBQUtBLFVBQU05QyxLQUFLLEdBQUk7Ozt1QkFHSTNELEtBQU07Ozt3QkFHTEksR0FBSTtLQU54QjtBQVNBeUQsV0FBTyxDQUFDQyxHQUFSLENBQVksc0JBQVosRUFBb0NILEtBQXBDO0FBQ0EsVUFBTVMsTUFBTSxpQkFBU0YsTUFBTSxDQUFDUCxLQUFQLENBQWFBLEtBQWIsQ0FBVCxDQUFaO0FBQ0Esa0JBQU1PLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlLElBQWYsQ0FBTjtBQUNELEdBbkJELENBbUJFLE9BQU8xRSxTQUFQLEVBQWtCO0FBQ2xCLFVBQU0sSUFBSUMsS0FBSixDQUFVRCxTQUFTLENBQUMyRSxPQUFwQixDQUFOO0FBQ0Q7QUFDRixDQXZCZSxDQUFoQjs7QUF5QkEsTUFBTXNFLGdCQUFnQixHQUFHLENBQU87QUFDOUI5RyxPQUQ4QjtBQUN2Qm1GLGNBRHVCO0FBQ1QvRSxhQURTO0FBQ0luQyxPQURKO0FBQ1dMO0FBRFgsQ0FBUCw4QkFFbkI7QUFDSixNQUFJO0FBQ0YsVUFBTXVFLE1BQU0saUJBQVNaLElBQUksQ0FBQ2EsT0FBTCxFQUFULENBQVo7QUFFQSxRQUFJUixLQUFLLEdBQUk7Ozt1QkFHTTNELEtBQU07OztLQUh6Qjs7QUFRQSxRQUFJK0IsS0FBSixFQUFXO0FBQ1Q0QixXQUFLLElBQUssd0JBQXVCNUIsS0FBTSxHQUF2QztBQUNEOztBQUVELFFBQUltRixZQUFKLEVBQWtCO0FBQ2hCdkQsV0FBSyxJQUFLLDJCQUEwQnVELFlBQWEsR0FBakQ7QUFDRDs7QUFFRCxRQUFJL0UsV0FBSixFQUFpQjtBQUNmd0IsV0FBSyxJQUFLLDBCQUF5QnhCLFdBQVksR0FBL0M7QUFDRDs7QUFFRCxRQUFJeEMsY0FBSixFQUFvQjtBQUNsQmdFLFdBQUssSUFBSyw2QkFBNEJoRSxjQUFlLEdBQXJEO0FBQ0Q7O0FBRURrRSxXQUFPLENBQUNDLEdBQVIsQ0FBWSw4QkFBWixFQUE0Q0gsS0FBNUM7QUFDQSxVQUFNUyxNQUFNLGlCQUFTRixNQUFNLENBQUNQLEtBQVAsQ0FBYUEsS0FBYixDQUFULENBQVo7QUFDQSxrQkFBTU8sTUFBTSxDQUFDSSxPQUFQLENBQWUsSUFBZixDQUFOO0FBQ0QsR0E5QkQsQ0E4QkUsT0FBTzFFLFNBQVAsRUFBa0I7QUFDbEIsVUFBTSxJQUFJQyxLQUFKLENBQVVELFNBQVMsQ0FBQzJFLE9BQXBCLENBQU47QUFDRDtBQUNGLENBcEN3QixDQUF6Qjs7QUFzQ0EsTUFBTXVFLGNBQWMsR0FBVXJDLFFBQVAsNkJBQW9CO0FBQ3pDLE1BQUk7QUFDRixVQUFNdkMsTUFBTSxpQkFBU1osSUFBSSxDQUFDYSxPQUFMLEVBQVQsQ0FBWjtBQUNBLFVBQU07QUFDSi9EO0FBREksUUFFRnFHLFFBRko7QUFJQSxVQUFNOUMsS0FBSyxHQUFJOztnQ0FFYXZELEdBQUk7S0FGaEM7QUFLQXlELFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUFaLEVBQXlDSCxLQUF6QztBQUNBLFVBQU1TLE1BQU0saUJBQVNKLEtBQUssQ0FBQ0wsS0FBRCxDQUFkLENBQVo7QUFDQSxrQkFBTU8sTUFBTSxDQUFDSSxPQUFQLENBQWUsSUFBZixDQUFOO0FBQ0QsR0FkRCxDQWNFLE9BQU8xRSxTQUFQLEVBQWtCO0FBQ2xCLFVBQU0sSUFBSUMsS0FBSixDQUFVRCxTQUFTLENBQUMyRSxPQUFwQixDQUFOO0FBQ0Q7QUFDRixDQWxCc0IsQ0FBdkI7O0FBb0JBLE1BQU13RSxnQkFBZ0IsR0FBVXRDLFFBQVAsNkJBQW9CO0FBQzNDLE1BQUk7QUFDRixVQUFNdkMsTUFBTSxpQkFBU1osSUFBSSxDQUFDYSxPQUFMLEVBQVQsQ0FBWjtBQUNBLFVBQU07QUFDSi9ELFNBREk7QUFFSnVFO0FBRkksUUFHRjhCLFFBSEo7QUFLQSxVQUFNOUMsS0FBSyxHQUFJOztzQ0FFbUJnQixhQUFjOzt3QkFFNUJ2RSxHQUFJO0tBSnhCO0FBT0F5RCxXQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEyQ0gsS0FBM0M7QUFDQSxVQUFNUyxNQUFNLGlCQUFTRixNQUFNLENBQUNQLEtBQVAsQ0FBYUEsS0FBYixDQUFULENBQVo7QUFDQSxrQkFBTU8sTUFBTSxDQUFDSSxPQUFQLENBQWUsSUFBZixDQUFOO0FBQ0QsR0FqQkQsQ0FpQkUsT0FBTzFFLFNBQVAsRUFBa0I7QUFDbEIsVUFBTSxJQUFJQyxLQUFKLENBQVVELFNBQVMsQ0FBQzJFLE9BQXBCLENBQU47QUFDRDtBQUNGLENBckJ3QixDQUF6Qjs7QUFwZUFwRyxNQUFNLENBQUNxQixhQUFQLENBMmZlO0FBQ2J3RSxPQURhO0FBRWJpQyxvQkFGYTtBQUdiakgsUUFIYTtBQUliQyxRQUphO0FBS2IySixTQUxhO0FBTWJDLGtCQU5hO0FBT2JqRSxnQkFQYTtBQVFiSiwyQkFSYTtBQVNic0UsZ0JBVGE7QUFVYkMsa0JBVmE7QUFXYnJFO0FBWGEsQ0EzZmYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJeEcsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0UsT0FBSyxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsU0FBSyxHQUFDRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlnRixTQUFKO0FBQWNsRixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNnRixhQUFTLEdBQUNoRixDQUFWO0FBQVk7O0FBQXhCLENBQTNCLEVBQXFELENBQXJEO0FBSTFJSCxNQUFNLENBQUNPLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFNBQVN1SyxTQUFULEdBQXFCO0FBQy9DLFNBQU8zRixTQUFTLENBQUMxRSxJQUFWLEVBQVA7QUFDRCxDQUZEO0FBSUFULE1BQU0sQ0FBQ08sT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFNBQVN3SyxhQUFULENBQXVCQyxVQUF2QixFQUFtQztBQUNsRTVLLE9BQUssQ0FBQzRLLFVBQUQsRUFBYTVKLE1BQWIsQ0FBTDtBQUNBLFNBQU8rRCxTQUFTLENBQUMxRSxJQUFWLENBQWV1SyxVQUFmLENBQVA7QUFDRCxDQUhELEU7Ozs7Ozs7Ozs7O0FDUkEsSUFBSXRLLEtBQUo7QUFBVVQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNQLENBQUQsRUFBRztBQUFDTyxTQUFLLEdBQUNQLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSVEsWUFBSjtBQUFpQlYsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDUSxnQkFBWSxHQUFDUixDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBSzdFLE1BQU1nRixTQUFTLEdBQUcsSUFBSXpFLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixXQUFyQixDQUFsQjtBQUVBdUUsU0FBUyxDQUFDdEUsS0FBVixDQUFnQjtBQUNkQyxRQUFNLEVBQUUsTUFBTSxLQURBO0FBRWRDLFFBQU0sRUFBRSxNQUFNLEtBRkE7QUFHZEMsUUFBTSxFQUFFLE1BQU07QUFIQSxDQUFoQjtBQU1BbUUsU0FBUyxDQUFDbEUsSUFBVixDQUFlO0FBQ2JILFFBQU0sRUFBRSxNQUFNLElBREQ7QUFFYkMsUUFBTSxFQUFFLE1BQU0sSUFGRDtBQUdiQyxRQUFNLEVBQUUsTUFBTTtBQUhELENBQWY7QUFNQW1FLFNBQVMsQ0FBQ2pFLE1BQVYsR0FBbUIsSUFBSVAsWUFBSixDQUFpQjtBQUNsQ21CLE9BQUssRUFBRW5CLFlBQVksQ0FBQ3NLLEtBQWIsQ0FBbUJDLEVBRFE7QUFFbEMvSixNQUFJLEVBQUVDLE1BRjRCO0FBR2xDcUgsY0FBWSxFQUFFO0FBQ1p0RyxRQUFJLEVBQUVmLE1BRE07QUFFWitKLFlBQVEsRUFBRTtBQUZFLEdBSG9CO0FBT2xDeEMsU0FBTyxFQUFFO0FBQ1B4RyxRQUFJLEVBQUVmLE1BREM7QUFFUCtKLFlBQVEsRUFBRTtBQUZILEdBUHlCO0FBV2xDbEgsYUFBVyxFQUFFN0MsTUFYcUI7QUFZbENxQyxRQUFNLEVBQUVyQyxNQVowQjtBQWFsQzRILGNBQVksRUFBRTVILE1BYm9CO0FBY2xDeUksWUFBVSxFQUFFdUIsTUFkc0I7QUFlbENsQyxhQUFXLEVBQUU5SCxNQWZxQjtBQWViO0FBQ3JCcUYsZUFBYSxFQUFFO0FBQ2J0RSxRQUFJLEVBQUVmLE1BRE87QUFFYitKLFlBQVEsRUFBRTtBQUZHLEdBaEJtQjtBQW1CL0I7QUFDSC9ELFlBQVUsRUFBRTtBQUNWakYsUUFBSSxFQUFFZixNQURJO0FBRVZpSyxpQkFBYSxFQUFFLENBQUMsS0FBRCxFQUFRLFNBQVIsRUFBbUIsT0FBbkIsRUFBNEIsUUFBNUIsRUFBc0MsUUFBdEM7QUFGTCxHQXBCc0I7QUF3QmxDaEUsV0FBUyxFQUFFO0FBQ1RsRixRQUFJLEVBQUVLLElBREc7QUFFVDJJLFlBQVEsRUFBRTtBQUZELEdBeEJ1QjtBQTJCL0I7QUFDSHBFLGdCQUFjLEVBQUU7QUFDZDVFLFFBQUksRUFBRWYsTUFEUTtBQUVkK0osWUFBUSxFQUFFO0FBRkksR0E1QmtCO0FBK0IvQjtBQUNIcEIsZ0JBQWMsRUFBRXVCLE9BaENrQjtBQWlDbENsQyxZQUFVLEVBQUU7QUFDVmpILFFBQUksRUFBRWYsTUFESTtBQUVWK0osWUFBUSxFQUFFO0FBRkEsR0FqQ3NCO0FBb0MvQjtBQUNIN0IsU0FBTyxFQUFFO0FBQ1BuSCxRQUFJLEVBQUVmLE1BREM7QUFFUCtKLFlBQVEsRUFBRTtBQUZILEdBckN5QjtBQXdDL0I7QUFDSHRILE9BQUssRUFBRXpDLE1BekMyQjtBQTBDbENxSSxVQUFRLEVBQUU2QixPQTFDd0I7QUEyQ2xDM0IsYUFBVyxFQUFFMkIsT0EzQ3FCO0FBNENsQy9FLFdBQVMsRUFBRTtBQUNUcEUsUUFBSSxFQUFFaUosTUFERztBQUVURCxZQUFRLEVBQUU7QUFGRCxHQTVDdUI7QUFnRGxDbEIsa0JBQWdCLEVBQUU7QUFDaEI5SCxRQUFJLEVBQUVmLE1BRFU7QUFFaEIrSixZQUFRLEVBQUU7QUFGTSxHQWhEZ0I7QUFvRGxDaEIsVUFBUSxFQUFFO0FBQ1JoSSxRQUFJLEVBQUVmLE1BREU7QUFFUmlLLGlCQUFhLEVBQUUsQ0FBQyxJQUFELEVBQU8sTUFBUDtBQUZQLEdBcER3QjtBQXdEbENuRSxTQUFPLEVBQUU7QUFDUC9FLFFBQUksRUFBRWYsTUFEQztBQUVQK0osWUFBUSxFQUFFO0FBRkgsR0F4RHlCO0FBNERsQzFKLGdCQUFjLEVBQUU7QUFDZFUsUUFBSSxFQUFFZixNQURRO0FBRWRpSyxpQkFBYSxFQUFFLENBQUMsSUFBRCxFQUFPLElBQVAsRUFBYSxJQUFiLEVBQW1CLElBQW5CLEVBQXlCLEtBQXpCO0FBRkQ7QUE1RGtCLENBQWpCLENBQW5CO0FBa0VBbEcsU0FBUyxDQUFDOUQsWUFBVixDQUF1QjhELFNBQVMsQ0FBQ2pFLE1BQWpDO0FBckZBakIsTUFBTSxDQUFDcUIsYUFBUCxDQXVGZTZELFNBdkZmLEU7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLElBQUluRixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLEtBQUosRUFBVW1MLEtBQVY7QUFBZ0J0TCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQm9MLE9BQUssQ0FBQ3BMLENBQUQsRUFBRztBQUFDb0wsU0FBSyxHQUFDcEwsQ0FBTjtBQUFROztBQUFwQyxDQUEzQixFQUFpRSxDQUFqRTtBQUFvRSxJQUFJZ0YsU0FBSjtBQUFjbEYsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDZ0YsYUFBUyxHQUFDaEYsQ0FBVjtBQUFZOztBQUF4QixDQUExQixFQUFvRCxDQUFwRDtBQUF1RCxJQUFJMkMsU0FBSjtBQUFjN0MsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQzJDLGFBQVMsR0FBQzNDLENBQVY7QUFBWTs7QUFBeEIsQ0FBdkMsRUFBaUUsQ0FBakU7QUFLdk9ILE1BQU0sQ0FBQ3VCLE9BQVAsQ0FBZTtBQUNiLHNCQUFvQixTQUFTaUssZUFBVCxDQUF5QmpELFFBQXpCLEVBQW1DO0FBQ3JEbkksU0FBSyxDQUFDbUksUUFBRCxFQUFXO0FBQ2RwSCxVQUFJLEVBQUVDLE1BRFE7QUFFZDZDLGlCQUFXLEVBQUU3QyxNQUZDO0FBR2RxQyxZQUFNLEVBQUVyQyxNQUhNO0FBSWQ0SCxrQkFBWSxFQUFFNUgsTUFKQTtBQUtkeUksZ0JBQVUsRUFBRXVCLE1BTEU7QUFNZGxDLGlCQUFXLEVBQUU5SCxNQU5DO0FBTU87QUFDckI7QUFDQWdHLGdCQUFVLEVBQUVoRyxNQVJFO0FBU2Q7QUFDQTJGLG9CQUFjLEVBQUUzRixNQVZGO0FBV2Q7QUFDQTJJLG9CQUFjLEVBQUV1QixPQVpGO0FBYWQ7QUFDQWxDLGdCQUFVLEVBQUVoSSxNQWRFO0FBY007QUFDcEJrSSxhQUFPLEVBQUVsSSxNQWZLO0FBZ0JkeUMsV0FBSyxFQUFFekMsTUFoQk87QUFpQmRxSSxjQUFRLEVBQUU2QixPQWpCSTtBQWtCZDNCLGlCQUFXLEVBQUUyQixPQWxCQztBQW1CZHJCLHNCQUFnQixFQUFFN0ksTUFuQko7QUFvQmQrSSxjQUFRLEVBQUUvSSxNQXBCSTtBQXFCZEssb0JBQWMsRUFBRUwsTUFyQkY7QUFzQmRxSCxrQkFBWSxFQUFFOEMsS0FBSyxDQUFDRSxLQUFOLENBQVlySyxNQUFaLENBdEJBO0FBdUJkdUgsYUFBTyxFQUFFNEMsS0FBSyxDQUFDRSxLQUFOLENBQVlySyxNQUFaO0FBdkJLLEtBQVgsQ0FBTCxDQURxRCxDQTBCckQ7O0FBRUEsUUFBSTtBQUNGLFlBQU1jLEdBQUcsR0FBR2lELFNBQVMsQ0FBQ3JFLE1BQVY7QUFBbUJnQixhQUFLLEVBQUUsS0FBS0M7QUFBL0IsU0FBMEN3RyxRQUExQyxFQUFaOztBQUNBLFVBQUl2SSxNQUFNLENBQUMwTCxRQUFYLEVBQXFCO0FBQ25CLDZCQUFPLG1CQUFQLEVBQTRCQyxJQUE1QixDQUFpQyxDQUFDO0FBQUNyTCxpQkFBTyxFQUFFaUY7QUFBVixTQUFELEtBQXlCO0FBQ3hEQSxrQkFBUSxDQUFDekUsTUFBVDtBQUFrQm9CLGVBQWxCO0FBQXVCSixpQkFBSyxFQUFFLEtBQUtDO0FBQW5DLGFBQThDd0csUUFBOUM7QUFDRCxTQUZEO0FBR0Q7O0FBQ0QsYUFBT3JHLEdBQVA7QUFDRCxLQVJELENBUUUsT0FBT1IsU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUkxQixNQUFNLENBQUMyQixLQUFYLENBQWlCLEtBQWpCLEVBQXdCRCxTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXhDWTtBQXlDYixzQkFBb0IsU0FBU2tLLGVBQVQsQ0FBeUJyRCxRQUF6QixFQUFtQztBQUNuRG5JLFNBQUssQ0FBQ21JLFFBQUQsRUFBVztBQUNoQnJHLFNBQUcsRUFBRWQsTUFEVztBQUVoQkQsVUFBSSxFQUFFQyxNQUZVO0FBR2hCNkMsaUJBQVcsRUFBRTdDLE1BSEc7QUFJaEJxQyxZQUFNLEVBQUVyQyxNQUpRO0FBS2hCNEgsa0JBQVksRUFBRTVILE1BTEU7QUFNaEJ5SSxnQkFBVSxFQUFFdUIsTUFOSTtBQU9oQmxDLGlCQUFXLEVBQUU5SCxNQVBHO0FBT0s7QUFDckI7QUFDQWdHLGdCQUFVLEVBQUVoRyxNQVRJO0FBVWhCO0FBQ0EyRixvQkFBYyxFQUFFM0YsTUFYQTtBQVloQjtBQUNBMkksb0JBQWMsRUFBRXVCLE9BYkE7QUFjaEI7QUFDQWxDLGdCQUFVLEVBQUVoSSxNQWZJO0FBZUk7QUFDcEJrSSxhQUFPLEVBQUVsSSxNQWhCTztBQWlCaEJ5QyxXQUFLLEVBQUV6QyxNQWpCUztBQWtCaEJxSSxjQUFRLEVBQUU2QixPQWxCTTtBQW1CaEIzQixpQkFBVyxFQUFFMkIsT0FuQkc7QUFvQmhCckIsc0JBQWdCLEVBQUU3SSxNQXBCRjtBQXFCaEIrSSxjQUFRLEVBQUUvSSxNQXJCTTtBQXNCaEJLLG9CQUFjLEVBQUVMLE1BdEJBO0FBdUJoQnFILGtCQUFZLEVBQUU4QyxLQUFLLENBQUNFLEtBQU4sQ0FBWXJLLE1BQVosQ0F2QkU7QUF3QmhCdUgsYUFBTyxFQUFFNEMsS0FBSyxDQUFDRSxLQUFOLENBQVlySyxNQUFaO0FBeEJPLEtBQVgsQ0FBTDtBQTJCRnVFLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQTBDMkMsUUFBMUM7O0FBQ0EsUUFBSTtBQUNGLFlBQU15QyxVQUFVLEdBQUd6QyxRQUFRLENBQUNyRyxHQUE1QjtBQUNBaUQsZUFBUyxDQUFDcEUsTUFBVixDQUFpQmlLLFVBQWpCLEVBQTZCO0FBQUM5SCxZQUFJO0FBQUlwQixlQUFLLEVBQUUsS0FBS0M7QUFBaEIsV0FBMkJ3RyxRQUEzQjtBQUFMLE9BQTdCOztBQUVBLFVBQUl2SSxNQUFNLENBQUMwTCxRQUFYLEVBQXFCO0FBQ25CLDZCQUFPLG1CQUFQLEVBQTRCQyxJQUE1QixDQUFpQyxDQUFDO0FBQUNyTCxpQkFBTyxFQUFFaUY7QUFBVixTQUFELEtBQXlCO0FBQ3hEQSxrQkFBUSxDQUFDeEUsTUFBVDtBQUFrQmlLLHNCQUFsQjtBQUE4QmxKLGlCQUFLLEVBQUUsS0FBS0M7QUFBMUMsYUFBcUR3RyxRQUFyRDtBQUNELFNBRkQ7QUFHRDs7QUFDRCxhQUFPeUMsVUFBUCxDQVRFLENBU2lCO0FBQ3BCLEtBVkQsQ0FVRSxPQUFPdEosU0FBUCxFQUFrQjtBQUNsQixZQUFNLElBQUkxQixNQUFNLENBQUMyQixLQUFYLENBQWlCLEtBQWpCLEVBQXdCRCxTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQW5GWTtBQW9GYixzQkFBb0IsU0FBU21LLGVBQVQsQ0FBeUIzSixHQUF6QixFQUE4QjtBQUNoRDlCLFNBQUssQ0FBQzhCLEdBQUQsRUFBTWQsTUFBTixDQUFMOztBQUVBLFFBQUk7QUFDRjtBQUNBLFVBQUlwQixNQUFNLENBQUMwTCxRQUFYLEVBQXFCO0FBQ25CLDZCQUFPLG1CQUFQLEVBQTRCQyxJQUE1QixDQUFpQyxDQUFDO0FBQUNyTCxpQkFBTyxFQUFFaUY7QUFBVixTQUFELEtBQXlCO0FBQ3hEQSxrQkFBUSxDQUFDcUYsY0FBVCxDQUF3QjtBQUFDMUk7QUFBRCxXQUF4QjtBQUNELFNBRkQ7QUFHRCxPQU5DLENBT0Y7OztBQUNBLGFBQU9pRCxTQUFTLENBQUNuRSxNQUFWLENBQWlCa0IsR0FBakIsQ0FBUDtBQUNELEtBVEQsQ0FTRSxPQUFPUixTQUFQLEVBQWtCO0FBQ2xCLFlBQU0sSUFBSTFCLE1BQU0sQ0FBQzJCLEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JELFNBQXhCLENBQU47QUFDRDtBQUNGLEdBbkdZO0FBb0diLHVCQUFxQixTQUFTb0ssZ0JBQVQsQ0FBMEI1SixHQUExQixFQUErQjZKLElBQS9CLEVBQXFDO0FBQ3hEM0wsU0FBSyxDQUFDOEIsR0FBRCxFQUFNZCxNQUFOLENBQUw7QUFDQWhCLFNBQUssQ0FBQzJMLElBQUQsRUFBT3ZKLElBQVAsQ0FBTDtBQUVBbUQsV0FBTyxDQUFDQyxHQUFSLENBQVksaUNBQVosRUFBK0MxRCxHQUEvQzs7QUFDQSxRQUFJO0FBQ0YsWUFBTWdFLE1BQU0sR0FBR2YsU0FBUyxDQUFDcEUsTUFBVixDQUFpQm1CLEdBQWpCLEVBQXNCO0FBQUNnQixZQUFJLEVBQUU7QUFDMUNrRSxvQkFBVSxFQUFFLEtBRDhCO0FBRTFDYixtQkFBUyxFQUFFLEVBRitCO0FBRzFDYyxtQkFBUyxFQUFFMEUsSUFIK0I7QUFJMUM3RSxpQkFBTyxFQUFFO0FBSmlDO0FBQVAsT0FBdEIsQ0FBZjs7QUFPQSxVQUFJbEgsTUFBTSxDQUFDMEwsUUFBWCxFQUFxQjtBQUNuQiw2QkFBTyxtQkFBUCxFQUE0QkMsSUFBNUIsQ0FBaUMsQ0FBQztBQUFDckwsaUJBQU8sRUFBRWlGO0FBQVYsU0FBRCxLQUF5QjtBQUN4REEsa0JBQVEsQ0FBQ21GLE9BQVQsQ0FBaUI7QUFBQ3hJLGVBQUQ7QUFBTUosaUJBQUssRUFBRSxLQUFLQztBQUFsQixXQUFqQjtBQUNELFNBRkQ7QUFHRDs7QUFFRCxhQUFPbUUsTUFBUDtBQUNELEtBZkQsQ0FlRSxPQUFNeEUsU0FBTixFQUFpQjtBQUNqQixZQUFNLElBQUkxQixNQUFNLENBQUMyQixLQUFYLENBQWlCLEtBQWpCLEVBQXdCRCxTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQTNIWTtBQTRIYixnQ0FBOEIsU0FBU3NLLHlCQUFULENBQW1DOUosR0FBbkMsRUFBd0M7QUFDcEU5QixTQUFLLENBQUM4QixHQUFELEVBQU1kLE1BQU4sQ0FBTDtBQUVBdUUsV0FBTyxDQUFDQyxHQUFSLENBQVksMENBQVosRUFBd0QxRCxHQUF4RDs7QUFDQSxRQUFJO0FBQ0YsWUFBTTtBQUFDdUU7QUFBRCxVQUFrQnRCLFNBQVMsQ0FBQ1QsT0FBVixDQUFrQnhDLEdBQWxCLENBQXhCO0FBQ0EsWUFBTWdFLE1BQU0sR0FBR2YsU0FBUyxDQUFDcEUsTUFBVixDQUFpQm1CLEdBQWpCLEVBQXNCO0FBQUNnQixZQUFJLEVBQUU7QUFDMUM2RCx3QkFBYyxFQUFFTixhQUQwQjtBQUUxQ0YsbUJBQVMsRUFBRSxDQUYrQjtBQUcxQ2Esb0JBQVUsRUFBRTtBQUg4QjtBQUFQLE9BQXRCLENBQWY7O0FBTUEsVUFBSXBILE1BQU0sQ0FBQzBMLFFBQVgsRUFBcUI7QUFDbkIsNkJBQU8sbUJBQVAsRUFBNEJDLElBQTVCLENBQWlDLENBQUM7QUFBQ3JMLGlCQUFPLEVBQUVpRjtBQUFWLFNBQUQsS0FBeUI7QUFDeERBLGtCQUFRLENBQUNzRixnQkFBVCxDQUEwQjtBQUFDM0ksZUFBRDtBQUFNdUU7QUFBTixXQUExQjtBQUNELFNBRkQ7QUFHRDs7QUFFRCxhQUFPUCxNQUFQO0FBQ0QsS0FmRCxDQWVFLE9BQU14RSxTQUFOLEVBQWlCO0FBQ2pCLFlBQU0sSUFBSTFCLE1BQU0sQ0FBQzJCLEtBQVgsQ0FBaUIsS0FBakIsRUFBd0JELFNBQXhCLENBQU47QUFDRDtBQUNGLEdBbEpZO0FBbUpiLGdDQUE4QixTQUFTdUsseUJBQVQsQ0FBbUNsRyxNQUFuQyxFQUEyQztBQUN2RTNGLFNBQUssQ0FBQzJGLE1BQUQsRUFBUztBQUNabEMsV0FBSyxFQUFFMEgsS0FBSyxDQUFDRSxLQUFOLENBQVlySyxNQUFaLENBREs7QUFFWjRILGtCQUFZLEVBQUV1QyxLQUFLLENBQUNFLEtBQU4sQ0FBWXJLLE1BQVosQ0FGRjtBQUdaNkMsaUJBQVcsRUFBRXNILEtBQUssQ0FBQ0UsS0FBTixDQUFZckssTUFBWixDQUhEO0FBSVpLLG9CQUFjLEVBQUU4SixLQUFLLENBQUNFLEtBQU4sQ0FBWXJLLE1BQVo7QUFKSixLQUFULENBQUw7QUFNQSxVQUFNMkssSUFBSSxHQUFHLElBQUl2SixJQUFKLEVBQWI7O0FBRUEsUUFBSTtBQUNGLFlBQU0wSixZQUFZLEdBQUcsRUFBckI7O0FBRUEsVUFBSW5HLE1BQU0sQ0FBQ2xDLEtBQVgsRUFBa0I7QUFDaEJxSSxvQkFBWSxDQUFDckksS0FBYixHQUFxQmtDLE1BQU0sQ0FBQ2xDLEtBQTVCO0FBQ0Q7O0FBRUQsVUFBSWtDLE1BQU0sQ0FBQ2lELFlBQVgsRUFBeUI7QUFDdkJrRCxvQkFBWSxDQUFDbEQsWUFBYixHQUE0QmpELE1BQU0sQ0FBQ2lELFlBQW5DO0FBQ0Q7O0FBRUQsVUFBSWpELE1BQU0sQ0FBQzlCLFdBQVgsRUFBd0I7QUFDdEJpSSxvQkFBWSxDQUFDakksV0FBYixHQUEyQjhCLE1BQU0sQ0FBQzlCLFdBQWxDO0FBQ0Q7O0FBRUQsVUFBSThCLE1BQU0sQ0FBQ3RFLGNBQVgsRUFBMkI7QUFDekJ5SyxvQkFBWSxDQUFDekssY0FBYixHQUE4QnNFLE1BQU0sQ0FBQ3RFLGNBQXJDO0FBQ0Q7O0FBRUQsWUFBTXlFLE1BQU0sR0FBR2YsU0FBUyxDQUFDcEUsTUFBVixDQUFpQm1MLFlBQWpCLEVBQStCO0FBQUNoSixZQUFJLEVBQUU7QUFBRXBCLGVBQUssRUFBRSxLQUFLQyxNQUFkO0FBQXNCcUYsb0JBQVUsRUFBRSxLQUFsQztBQUF5Q2IsbUJBQVMsRUFBRSxFQUFwRDtBQUF3RGMsbUJBQVMsRUFBRTBFLElBQW5FO0FBQXlFN0UsaUJBQU8sRUFBRTtBQUFsRjtBQUFQLE9BQS9CLEVBQWlJO0FBQUVpRixhQUFLLEVBQUU7QUFBVCxPQUFqSSxDQUFmOztBQUNBLFVBQUluTSxNQUFNLENBQUMwTCxRQUFYLEVBQXFCO0FBQ25CLDZCQUFPLG1CQUFQLEVBQTRCQyxJQUE1QixDQUFpQyxDQUFDO0FBQUNyTCxpQkFBTyxFQUFFaUY7QUFBVixTQUFELEtBQXlCO0FBQ3hEQSxrQkFBUSxDQUFDb0YsZ0JBQVQsaUNBQThCNUUsTUFBOUI7QUFBc0NqRSxpQkFBSyxFQUFFLEtBQUtDO0FBQWxEO0FBQ0QsU0FGRDtBQUdEO0FBQ0YsS0F6QkQsQ0F5QkUsT0FBTUwsU0FBTixFQUFpQjtBQUNqQixZQUFNLElBQUkxQixNQUFNLENBQUMyQixLQUFYLENBQWlCLEtBQWpCLEVBQXdCRCxTQUF4QixDQUFOO0FBQ0Q7QUFDRixHQXhMWTtBQXlMYixvQkFBa0IsU0FBUzBLLGFBQVQsQ0FBdUJDLGFBQXZCLEVBQXNDO0FBQ3REak0sU0FBSyxDQUFDaU0sYUFBRCxFQUFnQmpMLE1BQWhCLENBQUw7QUFFQSxVQUFNbUgsUUFBUSxHQUFHcEQsU0FBUyxDQUFDVCxPQUFWLENBQWtCMkgsYUFBbEIsQ0FBakI7QUFDQSxXQUFPOUQsUUFBUSxDQUFDckcsR0FBaEIsQ0FKc0QsQ0FNdEQ7O0FBQ0EsVUFBTWYsSUFBSSxHQUFHb0gsUUFBUSxDQUFDcEgsSUFBVCxHQUFnQixPQUE3QjtBQUNBLFVBQU1tTCxLQUFLLEdBQUduSCxTQUFTLENBQUMxRSxJQUFWLENBQWU7QUFBQ1UsVUFBSSxFQUFFLElBQUlvTCxNQUFKLENBQVksSUFBR3BMLElBQUssRUFBcEI7QUFBUCxLQUFmLEVBQStDbUwsS0FBL0MsRUFBZDtBQUVBLFVBQU1FLFdBQVcsbUNBQ1pqRSxRQURZO0FBRWZwSCxVQUFJLEVBQUVBLElBQUksR0FBSSxJQUFHbUwsS0FBSyxHQUFHQSxLQUFLLEdBQUcsQ0FBWCxHQUFlLEVBQUc7QUFGekIsTUFBakI7O0FBS0EsUUFBSTtBQUNGLFlBQU1wSyxHQUFHLEdBQUdpRCxTQUFTLENBQUNyRSxNQUFWO0FBQW1CZ0IsYUFBSyxFQUFFLEtBQUtDO0FBQS9CLFNBQTBDeUssV0FBMUMsRUFBWjs7QUFDQSxVQUFJeE0sTUFBTSxDQUFDMEwsUUFBWCxFQUFxQjtBQUNuQiw2QkFBTyxtQkFBUCxFQUE0QkMsSUFBNUIsQ0FBaUMsQ0FBQztBQUFDckwsaUJBQU8sRUFBRWlGO0FBQVYsU0FBRCxLQUF5QjtBQUN4REEsa0JBQVEsQ0FBQ3pFLE1BQVQ7QUFBa0JvQixlQUFsQjtBQUF1QkosaUJBQUssRUFBRSxLQUFLQztBQUFuQyxhQUE4Q3lLLFdBQTlDO0FBQ0QsU0FGRDtBQUdEOztBQUNELGFBQU90SyxHQUFQO0FBQ0QsS0FSRCxDQVFFLE9BQU1SLFNBQU4sRUFBaUI7QUFDakIsWUFBTSxJQUFJMUIsTUFBTSxDQUFDMkIsS0FBWCxDQUFpQixLQUFqQixFQUF3QkQsU0FBeEIsQ0FBTjtBQUNEO0FBQ0YsR0FuTlk7QUFxTmIsd0JBQXNCLFNBQVMrSyxrQkFBVCxHQUE4QjtBQUNsRCxRQUFJO0FBQ0YsVUFBSXpNLE1BQU0sQ0FBQzBMLFFBQVgsRUFBcUI7QUFDbkIsNkJBQU8sbUJBQVAsRUFBNEJDLElBQTVCLENBQWlDLENBQUM7QUFBQ3JMLGlCQUFPLEVBQUVpRjtBQUFWLFNBQUQsS0FBeUI7QUFDeERBLGtCQUFRLENBQUN3QyxrQkFBVCxDQUE0QixLQUFLaEcsTUFBakM7QUFDRCxTQUZEO0FBR0Q7QUFDRixLQU5ELENBTUUsT0FBTUwsU0FBTixFQUFpQjtBQUNqQixZQUFNLElBQUkxQixNQUFNLENBQUMyQixLQUFYLENBQWlCLEtBQWpCLEVBQXdCRCxTQUF4QixDQUFOO0FBQ0Q7QUFDRjtBQS9OWSxDQUFmO0FBa09Bb0IsU0FBUyxDQUFDO0FBQ1J2QixTQUFPLEVBQUUsQ0FDUCxrQkFETyxFQUVQLGtCQUZPLEVBR1Asa0JBSE8sQ0FERDtBQU1SNkIsT0FBSyxFQUFFLENBTkM7QUFPUkMsV0FBUyxFQUFFO0FBUEgsQ0FBRCxDQUFULEM7Ozs7Ozs7Ozs7O0FDdk9BLElBQUlyRCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBSVgsSUFBSXVNLE1BQUo7O0FBRUEsTUFBTUMsVUFBVSxHQUFHLENBQUM1SyxNQUFELEVBQVM7QUFBRTZLLGNBQUY7QUFBZ0JDO0FBQWhCLENBQVQsS0FBdUM7QUFDeEQsTUFBSTtBQUNGN00sVUFBTSxDQUFDOE0sS0FBUCxDQUFhL0wsTUFBYixDQUFvQmdCLE1BQXBCLEVBQTRCO0FBQzFCbUIsVUFBSSxFQUFFO0FBQ0osNEJBQW9CMEosWUFEaEI7QUFFSkM7QUFGSTtBQURvQixLQUE1QjtBQU1ELEdBUEQsQ0FPRSxPQUFPbkwsU0FBUCxFQUFrQjtBQUNsQixVQUFNLElBQUlDLEtBQUosQ0FBVyw0QkFBMkJELFNBQVMsQ0FBQzJFLE9BQVEsRUFBeEQsQ0FBTjtBQUNEO0FBQ0YsQ0FYRDs7QUFhQSxNQUFNMEcsV0FBVyxHQUFHLENBQUM7QUFBRWhMLFFBQUY7QUFBVThLO0FBQVYsQ0FBRCxFQUFzQkcsT0FBdEIsS0FBa0M7QUFDcEQsTUFBSTtBQUNGTixVQUFNLEdBQUdNLE9BQVQ7QUFDQUwsY0FBVSxDQUFDNUssTUFBRCxFQUFTOEssT0FBVCxDQUFWO0FBQ0FILFVBQU0sQ0FBQ08sT0FBUDtBQUNELEdBSkQsQ0FJRSxPQUFPdkwsU0FBUCxFQUFrQjtBQUNsQmdMLFVBQU0sQ0FBQ1EsTUFBUCxDQUFjeEwsU0FBUyxDQUFDMkUsT0FBeEI7QUFDRDtBQUNGLENBUkQ7O0FBbkJBcEcsTUFBTSxDQUFDcUIsYUFBUCxDQTZCZTZMLE9BQU8sSUFDcEIsSUFBSUMsT0FBSixDQUFZLENBQUNILE9BQUQsRUFBVUMsTUFBVixLQUNWSCxXQUFXLENBQUNJLE9BQUQsRUFBVTtBQUFFRixTQUFGO0FBQVdDO0FBQVgsQ0FBVixDQURiLENBOUJGLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSWxOLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJa04sUUFBSjtBQUFhcE4sTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQ21OLFVBQVEsQ0FBQ2xOLENBQUQsRUFBRztBQUFDa04sWUFBUSxHQUFDbE4sQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJNE0sV0FBSjtBQUFnQjlNLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUM0TSxlQUFXLEdBQUM1TSxDQUFaO0FBQWM7O0FBQTFCLENBQTdCLEVBQXlELENBQXpEO0FBQTRELElBQUkyQyxTQUFKO0FBQWM3QyxNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDMkMsYUFBUyxHQUFDM0MsQ0FBVjtBQUFZOztBQUF4QixDQUExQyxFQUFvRSxDQUFwRTtBQU1uU0gsTUFBTSxDQUFDdUIsT0FBUCxDQUFlO0FBQ2IsaUNBQStCLFNBQVMrTCwwQkFBVCxHQUFzQztBQUNuRSxXQUFPRCxRQUFRLENBQUNFLHFCQUFULENBQStCLEtBQUt4TCxNQUFwQyxDQUFQO0FBQ0QsR0FIWTtBQUliLHVCQUFxQixTQUFTeUwsZ0JBQVQsQ0FBMEJYLE9BQTFCLEVBQW1DO0FBQ3REek0sU0FBSyxDQUFDeU0sT0FBRCxFQUFVO0FBQ2JELGtCQUFZLEVBQUV4TCxNQUREO0FBRWJ5TCxhQUFPLEVBQUU7QUFDUDFMLFlBQUksRUFBRTtBQUNKc00sZUFBSyxFQUFFck0sTUFESDtBQUVKc00sY0FBSSxFQUFFdE07QUFGRjtBQURDO0FBRkksS0FBVixDQUFMO0FBVUEsV0FBTzJMLFdBQVcsQ0FBQztBQUFFaEwsWUFBTSxFQUFFLEtBQUtBLE1BQWY7QUFBdUI4SztBQUF2QixLQUFELENBQVgsQ0FDSmxCLElBREksQ0FDQ2dDLFFBQVEsSUFBSUEsUUFEYixFQUVKQyxLQUZJLENBRUdsTSxTQUFELElBQWU7QUFDcEIsWUFBTSxJQUFJMUIsTUFBTSxDQUFDMkIsS0FBWCxDQUFpQixLQUFqQixFQUF3QkQsU0FBeEIsQ0FBTjtBQUNELEtBSkksQ0FBUDtBQUtEO0FBcEJZLENBQWY7QUF1QkFvQixTQUFTLENBQUM7QUFDUnZCLFNBQU8sRUFBRSxDQUNQLDZCQURPLEVBRVAsbUJBRk8sQ0FERDtBQUtSNkIsT0FBSyxFQUFFLENBTEM7QUFNUkMsV0FBUyxFQUFFO0FBTkgsQ0FBRCxDQUFULEM7Ozs7Ozs7Ozs7O0FDN0JBLElBQUlyRCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBRVhILE1BQU0sQ0FBQ08sT0FBUCxDQUFlLG1CQUFmLEVBQW9DLFNBQVNzTixZQUFULEdBQXdCO0FBQzFELFNBQU83TixNQUFNLENBQUM4TSxLQUFQLENBQWFyTSxJQUFiLENBQWtCLEtBQUtzQixNQUF2QixFQUErQjtBQUNwQytMLFVBQU0sRUFBRTtBQUNOQyxZQUFNLEVBQUUsQ0FERjtBQUVObEIsYUFBTyxFQUFFLENBRkg7QUFHTnpJLGNBQVEsRUFBRTtBQUhKO0FBRDRCLEdBQS9CLENBQVA7QUFPRCxDQVJELEU7Ozs7Ozs7Ozs7O0FDRkEsSUFBSXBFLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJNk4sY0FBSjtBQUFtQi9OLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBDQUFaLEVBQXVEO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUM2TixrQkFBYyxHQUFDN04sQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBdkQsRUFBc0YsQ0FBdEY7QUFBeUYsSUFBSThOLGFBQUo7QUFBa0JoTyxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQ0FBWixFQUE4QztBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDOE4saUJBQWEsR0FBQzlOLENBQWQ7QUFBZ0I7O0FBQTVCLENBQTlDLEVBQTRFLENBQTVFO0FBSzFQSCxNQUFNLENBQUN1QixPQUFQLENBQWU7QUFDYixxQkFBbUIsU0FBUzJNLGNBQVQsQ0FBd0JDLFFBQXhCLEVBQWtDO0FBQ25EL04sU0FBSyxDQUFDK04sUUFBRCxFQUFXL00sTUFBWCxDQUFMO0FBQ0EsV0FBTzZNLGFBQWEsQ0FBQ0QsY0FBYyxDQUFFLFNBQVFHLFFBQVMsS0FBbkIsQ0FBZixDQUFwQjtBQUNEO0FBSlksQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBbE8sTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJbU4sUUFBSjtBQUFhcE4sTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQ21OLFVBQVEsQ0FBQ2xOLENBQUQsRUFBRztBQUFDa04sWUFBUSxHQUFDbE4sQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUVia04sUUFBUSxDQUFDZSxZQUFULENBQXNCLENBQUNqQixPQUFELEVBQVVrQixJQUFWLEtBQW1CO0FBQ3ZDLFFBQU1DLFlBQVksR0FBR0QsSUFBckI7QUFDQSxNQUFJbEIsT0FBTyxDQUFDTixPQUFaLEVBQXFCeUIsWUFBWSxDQUFDekIsT0FBYixHQUF1Qk0sT0FBTyxDQUFDTixPQUEvQjtBQUNyQixTQUFPeUIsWUFBUDtBQUNELENBSkQsRTs7Ozs7Ozs7Ozs7QUNGQXJPLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlDQUFaO0FBQXVERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5Q0FBWjtBQUF1REQsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVo7QUFBb0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaO0FBQW9ERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw0Q0FBWjtBQUEwREQsTUFBTSxDQUFDQyxJQUFQLENBQVksdUNBQVo7QUFBcURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtDQUFaO0FBQTZERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWjtBQUE4Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVo7QUFBOENELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFDQUFaO0FBQW1ERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQ0FBWjtBQUFnRCxJQUFJcUYsUUFBSjtBQUFhdEYsTUFBTSxDQUFDQyxJQUFQLENBQVkscUNBQVosRUFBa0Q7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ29GLFlBQVEsR0FBQ3BGLENBQVQ7QUFBVzs7QUFBdkIsQ0FBbEQsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSWdGLFNBQUo7QUFBY2xGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNnRixhQUFTLEdBQUNoRixDQUFWO0FBQVk7O0FBQXhCLENBQTVDLEVBQXNFLENBQXRFO0FBbUIxcUIsTUFBTW9JLFFBQVEsR0FBRztBQUNmckcsS0FBRyxFQUFFLEtBRFU7QUFFZkosT0FBSyxFQUFFLE9BRlE7QUFHZlgsTUFBSSxFQUFFLE1BSFM7QUFJZjhDLGFBQVcsRUFBRSxhQUpFO0FBS2ZSLFFBQU0sRUFBRSxRQUxPO0FBTWZ1RixjQUFZLEVBQUUsY0FOQztBQU9mYSxZQUFVLEVBQUUsRUFQRztBQVFmWCxhQUFXLEVBQUUsYUFSRTtBQVNmYSxnQkFBYyxFQUFFLElBVEQ7QUFVZlgsWUFBVSxFQUFFLFlBVkc7QUFXZkUsU0FBTyxFQUFFLFNBWE07QUFZZnpGLE9BQUssRUFBRSxPQVpRO0FBYWZwQyxnQkFBYyxFQUFFLGdCQWJEO0FBY2ZnSSxVQUFRLEVBQUU7QUFkSyxDQUFqQixDLENBa0JBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUVBLDZCOzs7Ozs7Ozs7OztBQ2xEQSxJQUFJOEUsVUFBSjtBQUFldE8sTUFBTSxDQUFDQyxJQUFQLENBQVksOEJBQVosRUFBMkM7QUFBQ3FPLFlBQVUsQ0FBQ3BPLENBQUQsRUFBRztBQUFDb08sY0FBVSxHQUFDcE8sQ0FBWDtBQUFhOztBQUE1QixDQUEzQyxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJb0YsUUFBSjtBQUFhdEYsTUFBTSxDQUFDQyxJQUFQLENBQVkscUNBQVosRUFBa0Q7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ29GLFlBQVEsR0FBQ3BGLENBQVQ7QUFBVzs7QUFBdkIsQ0FBbEQsRUFBMkUsQ0FBM0U7QUFJeEdvTyxVQUFVLENBQUNDLE1BQVgsQ0FBa0I7QUFDaEI1SSxLQUFHLEVBQUU7QUFEVyxDQUFsQjtBQUlBMkksVUFBVSxDQUFDaEUsR0FBWCxDQUFlO0FBQ2JwSixNQUFJLEVBQUUsZUFETzs7QUFFYnNOLFVBQVEsQ0FBQ0MsTUFBRCxFQUFTO0FBQ2YsV0FBT0EsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVosQ0FBUDtBQUNELEdBSlk7O0FBS2JDLEtBQUcsR0FBRztBQUNKLFdBQU9ySixRQUFRLENBQUNtQixjQUFULEVBQVA7QUFDRDs7QUFQWSxDQUFmO0FBVUE2SCxVQUFVLENBQUNNLEtBQVgsRzs7Ozs7Ozs7Ozs7QUNsQkEsSUFBSTdPLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFFWCxJQUFJSCxNQUFNLENBQUM4TyxhQUFYLEVBQTBCQyxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsUUFBWixHQUF1QmpQLE1BQU0sQ0FBQ3FGLFFBQVAsQ0FBZ0JDLE9BQWhCLENBQXdCMkosUUFBL0MsQzs7Ozs7Ozs7Ozs7QUNGMUIsSUFBSUMsTUFBSjtBQUFXalAsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQytPLFVBQU0sR0FBQy9PLENBQVA7QUFBUzs7QUFBckIsQ0FBbkMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSUgsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeUIsU0FBSjtBQUFjM0IsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ0ksU0FBTyxDQUFDSCxDQUFELEVBQUc7QUFBQ3lCLGFBQVMsR0FBQ3pCLENBQVY7QUFBWTs7QUFBeEIsQ0FBNUMsRUFBc0UsQ0FBdEU7O0FBSXRKLE1BQU1nUCxhQUFhLEdBQUdwTixNQUFNLEtBQUs7QUFDL0JxTixZQUFVLEVBQUV4TixTQURtQjtBQUUvQnlOLGNBQVksRUFBRSxDQUFDLGFBQUQsRUFBZ0IsU0FBaEIsQ0FGaUI7QUFHL0JDLFNBQU8sRUFBRSxJQUhzQjtBQUkvQkMsWUFBVSxFQUFFLENBSm1COztBQUsvQkMsT0FBSyxDQUFDQyxTQUFELEVBQVk7QUFDZixXQUFPO0FBQ0wzTixXQUFLLEVBQUVDLE1BREY7QUFFTGEsV0FBSyxFQUFHLGFBQVk2TSxTQUFTLEdBQUcsQ0FBRSxFQUY3QjtBQUdMNU0sVUFBSSxFQUFHLGlDQUFnQzRNLFNBQVMsR0FBRyxDQUFFO0FBSGhELEtBQVA7QUFLRDs7QUFYOEIsQ0FBTCxDQUE1Qjs7QUFjQVAsTUFBTSxDQUFDbFAsTUFBTSxDQUFDOE0sS0FBUixFQUFlO0FBQ25CdUMsY0FBWSxFQUFFLENBQUMsYUFBRCxFQUFnQixTQUFoQixDQURLO0FBRW5CQyxTQUFPLEVBQUUsSUFGVTtBQUduQkksTUFBSSxFQUFFLENBQUM7QUFDTEMsU0FBSyxFQUFFLGlCQURGO0FBRUxDLFlBQVEsRUFBRSxVQUZMO0FBR0wvQyxXQUFPLEVBQUU7QUFDUDFMLFVBQUksRUFBRTtBQUNKc00sYUFBSyxFQUFFLE1BREg7QUFFSkMsWUFBSSxFQUFFO0FBRkY7QUFEQyxLQUhKO0FBU0xtQyxTQUFLLEVBQUUsQ0FBQyxPQUFELENBVEY7O0FBVUxILFFBQUksQ0FBQzNOLE1BQUQsRUFBUztBQUNYLGFBQU9vTixhQUFhLENBQUNwTixNQUFELENBQXBCO0FBQ0Q7O0FBWkksR0FBRCxDQUhhO0FBaUJuQndOLFlBQVUsRUFBRSxDQWpCTzs7QUFrQm5CQyxPQUFLLENBQUM3SCxLQUFELEVBQVFtSSxLQUFSLEVBQWU7QUFDbEIsVUFBTUMsU0FBUyxHQUFHcEksS0FBSyxHQUFHLENBQTFCO0FBQ0EsV0FBTztBQUNMZ0ksV0FBSyxFQUFHLFFBQU9JLFNBQVUsV0FEcEI7QUFFTEgsY0FBUSxFQUFFLFVBRkw7QUFHTC9DLGFBQU8sRUFBRTtBQUNQMUwsWUFBSSxFQUFFO0FBQ0pzTSxlQUFLLEVBQUVxQyxLQUFLLENBQUMzTyxJQUFOLENBQVc2TyxTQUFYLEVBREg7QUFFSnRDLGNBQUksRUFBRW9DLEtBQUssQ0FBQzNPLElBQU4sQ0FBVzhPLFFBQVg7QUFGRjtBQURDLE9BSEo7QUFTTEosV0FBSyxFQUFFLENBQUMsTUFBRCxDQVRGOztBQVVMSCxVQUFJLENBQUMzTixNQUFELEVBQVM7QUFDWCxlQUFPb04sYUFBYSxDQUFDcE4sTUFBRCxDQUFwQjtBQUNEOztBQVpJLEtBQVA7QUFjRDs7QUFsQ2tCLENBQWYsQ0FBTixDOzs7Ozs7Ozs7OztBQ2xCQTlCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVo7QUFBMEJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVo7QUFBMkJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLE9BQVo7QUFBcUJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVo7QUFBMEJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVo7QUFBdUJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRTs7Ozs7Ozs7Ozs7QUNBM0hELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaO0FBQTJDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWjtBQUEyQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVo7QUFBd0NELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaO0FBQXdDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWjtBQUE4Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVksMkJBQVo7QUFBeUNELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1DQUFaLEU7Ozs7Ozs7Ozs7O0FDQTdQLElBQUlnUSxFQUFKO0FBQU9qUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxJQUFaLEVBQWlCO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUMrUCxNQUFFLEdBQUMvUCxDQUFIO0FBQUs7O0FBQWpCLENBQWpCLEVBQW9DLENBQXBDO0FBQVBGLE1BQU0sQ0FBQ3FCLGFBQVAsQ0FFZTZPLElBQUksSUFBSUQsRUFBRSxDQUFDRSxZQUFILENBQWlCLGNBQWFELElBQUssRUFBbkMsRUFBc0MsTUFBdEMsQ0FGdkIsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJRSxNQUFKLEVBQVdDLFlBQVg7QUFBd0JyUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNtUSxRQUFNLENBQUNsUSxDQUFELEVBQUc7QUFBQ2tRLFVBQU0sR0FBQ2xRLENBQVA7QUFBUyxHQUFwQjs7QUFBcUJtUSxjQUFZLENBQUNuUSxDQUFELEVBQUc7QUFBQ21RLGdCQUFZLEdBQUNuUSxDQUFiO0FBQWU7O0FBQXBELENBQXpCLEVBQStFLENBQS9FO0FBQXhCRixNQUFNLENBQUNxQixhQUFQLENBRWUsQ0FBQ2lQLFFBQUQsRUFBV3BELE9BQVgsS0FBdUI7QUFDcEMsUUFBTXFELE1BQU0sR0FBRyxJQUFJSCxNQUFKLEVBQWY7QUFDQSxRQUFNSSxNQUFNLEdBQUd0RCxPQUFPLEdBQUcsSUFBSW1ELFlBQUosQ0FBaUJuRCxPQUFqQixDQUFILEdBQStCLElBQUltRCxZQUFKLEVBQXJEO0FBQ0EsUUFBTUksTUFBTSxHQUFHRixNQUFNLENBQUNHLEtBQVAsQ0FBYUosUUFBYixDQUFmO0FBQ0EsU0FBT0UsTUFBTSxDQUFDRyxNQUFQLENBQWNGLE1BQWQsQ0FBUDtBQUNELENBUEQsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJMVEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJMFEsY0FBSjtBQUFtQjVRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlCQUFaLEVBQXNDO0FBQUMyUSxnQkFBYyxDQUFDMVEsQ0FBRCxFQUFHO0FBQUMwUSxrQkFBYyxHQUFDMVEsQ0FBZjtBQUFpQjs7QUFBcEMsQ0FBdEMsRUFBNEUsQ0FBNUU7QUFBbkZGLE1BQU0sQ0FBQ3FCLGFBQVAsQ0FHZSxDQUFDO0FBQUVDLFNBQUY7QUFBVzZCLE9BQVg7QUFBa0JDO0FBQWxCLENBQUQsS0FBbUM7QUFDaEQsTUFBSXJELE1BQU0sQ0FBQzBMLFFBQVgsRUFBcUI7QUFDbkJtRixrQkFBYyxDQUFDQyxPQUFmLENBQXVCO0FBQ3JCM1AsVUFBSSxDQUFDQSxJQUFELEVBQU87QUFBRSxlQUFPSSxPQUFPLENBQUN3UCxPQUFSLENBQWdCNVAsSUFBaEIsSUFBd0IsQ0FBQyxDQUFoQztBQUFvQyxPQUQ1Qjs7QUFFckI2UCxrQkFBWSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWM7O0FBRlYsS0FBdkIsRUFHRzVOLEtBSEgsRUFHVUMsU0FIVjtBQUlEO0FBQ0YsQ0FWRCxFOzs7Ozs7Ozs7OztBQ0FBcEQsTUFBTSxDQUFDQyxJQUFQLENBQVksMkJBQVosRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgRGVwYXJ0bWVudENvZGVzIGZyb20gJy4uL0RlcGFydG1lbnRDb2Rlcyc7XG5cbk1ldGVvci5wdWJsaXNoKCdkZXBhcnRtZW50Q29kZXMnLCBmdW5jdGlvbiBkZXBhcnRtZW50Q29kZXMoKSB7XG4gIHJldHVybiBEZXBhcnRtZW50Q29kZXMuZmluZCgpO1xufSk7XG4iLCIvKiBlc2xpbnQtZGlzYWJsZSBjb25zaXN0ZW50LXJldHVybiAqL1xuXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5cbmNvbnN0IERlcGFydG1lbnRDb2RlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdEZXBhcnRtZW50Q29kZXMnKTtcblxuRGVwYXJ0bWVudENvZGVzLmFsbG93KHtcbiAgaW5zZXJ0OiAoKSA9PiBmYWxzZSxcbiAgdXBkYXRlOiAoKSA9PiBmYWxzZSxcbiAgcmVtb3ZlOiAoKSA9PiBmYWxzZSxcbn0pO1xuXG5EZXBhcnRtZW50Q29kZXMuZGVueSh7XG4gIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgdXBkYXRlOiAoKSA9PiB0cnVlLFxuICByZW1vdmU6ICgpID0+IHRydWUsXG59KTtcblxuRGVwYXJ0bWVudENvZGVzLnNjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICBuYW1lOiBTdHJpbmcsXG59KTtcblxuRGVwYXJ0bWVudENvZGVzLmF0dGFjaFNjaGVtYShEZXBhcnRtZW50Q29kZXMuc2NoZW1hKTtcblxuZXhwb3J0IGRlZmF1bHQgRGVwYXJ0bWVudENvZGVzO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgRGVwYXJ0bWVudENvZGVzIGZyb20gJy4vRGVwYXJ0bWVudENvZGVzJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAnZGVwYXJ0bWVudENvZGVzLmluc2VydCc6IGZ1bmN0aW9uIGRlcGFydG1lbnRDb2Rlc0luc2VydChkZXBhcnRtZW50Q29kZSkge1xuICAgIGNoZWNrKGRlcGFydG1lbnRDb2RlLCB7XG4gICAgICBuYW1lOiBTdHJpbmcsXG4gICAgfSk7XG5cbiAgICB0cnkge1xuICAgICAgcmV0dXJuIERlcGFydG1lbnRDb2Rlcy5pbnNlcnQoZGVwYXJ0bWVudENvZGUpO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IERvY3VtZW50cyBmcm9tICcuLi9Eb2N1bWVudHMnO1xuXG5NZXRlb3IucHVibGlzaCgnZG9jdW1lbnRzJywgZnVuY3Rpb24gZG9jdW1lbnRzKCkge1xuICByZXR1cm4gRG9jdW1lbnRzLmZpbmQoeyBvd25lcjogdGhpcy51c2VySWQgfSk7XG59KTtcblxuLy8gTm90ZTogZG9jdW1lbnRzLnZpZXcgaXMgYWxzbyB1c2VkIHdoZW4gZWRpdGluZyBhbiBleGlzdGluZyBkb2N1bWVudC5cbk1ldGVvci5wdWJsaXNoKCdkb2N1bWVudHMudmlldycsIGZ1bmN0aW9uIGRvY3VtZW50c1ZpZXcoZG9jdW1lbnRJZCkge1xuICBjaGVjayhkb2N1bWVudElkLCBTdHJpbmcpO1xuICByZXR1cm4gRG9jdW1lbnRzLmZpbmQoeyBfaWQ6IGRvY3VtZW50SWQsIG93bmVyOiB0aGlzLnVzZXJJZCB9KTtcbn0pO1xuIiwiLyogZXNsaW50LWRpc2FibGUgY29uc2lzdGVudC1yZXR1cm4gKi9cblxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG5jb25zdCBEb2N1bWVudHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignRG9jdW1lbnRzJyk7XG5cbkRvY3VtZW50cy5hbGxvdyh7XG4gIGluc2VydDogKCkgPT4gZmFsc2UsXG4gIHVwZGF0ZTogKCkgPT4gZmFsc2UsXG4gIHJlbW92ZTogKCkgPT4gZmFsc2UsXG59KTtcblxuRG9jdW1lbnRzLmRlbnkoe1xuICBpbnNlcnQ6ICgpID0+IHRydWUsXG4gIHVwZGF0ZTogKCkgPT4gdHJ1ZSxcbiAgcmVtb3ZlOiAoKSA9PiB0cnVlLFxufSk7XG5cbkRvY3VtZW50cy5zY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgb3duZXI6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgbGFiZWw6ICdUaGUgSUQgb2YgdGhlIHVzZXIgdGhpcyBkb2N1bWVudCBiZWxvbmdzIHRvLicsXG4gIH0sXG4gIGNyZWF0ZWRBdDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBkYXRlIHRoaXMgZG9jdW1lbnQgd2FzIGNyZWF0ZWQuJyxcbiAgICBhdXRvVmFsdWUoKSB7XG4gICAgICBpZiAodGhpcy5pc0luc2VydCkgcmV0dXJuIChuZXcgRGF0ZSgpKS50b0lTT1N0cmluZygpO1xuICAgIH0sXG4gIH0sXG4gIHVwZGF0ZWRBdDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBkYXRlIHRoaXMgZG9jdW1lbnQgd2FzIGxhc3QgdXBkYXRlZC4nLFxuICAgIGF1dG9WYWx1ZSgpIHtcbiAgICAgIGlmICh0aGlzLmlzSW5zZXJ0IHx8IHRoaXMuaXNVcGRhdGUpIHJldHVybiAobmV3IERhdGUoKSkudG9JU09TdHJpbmcoKTtcbiAgICB9LFxuICB9LFxuICB0aXRsZToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSB0aXRsZSBvZiB0aGUgZG9jdW1lbnQuJyxcbiAgfSxcbiAgYm9keToge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBsYWJlbDogJ1RoZSBib2R5IG9mIHRoZSBkb2N1bWVudC4nLFxuICB9LFxufSk7XG5cbkRvY3VtZW50cy5hdHRhY2hTY2hlbWEoRG9jdW1lbnRzLnNjaGVtYSk7XG5cbmV4cG9ydCBkZWZhdWx0IERvY3VtZW50cztcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IERvY3VtZW50cyBmcm9tICcuL0RvY3VtZW50cyc7XG5pbXBvcnQgcmF0ZUxpbWl0IGZyb20gJy4uLy4uL21vZHVsZXMvcmF0ZS1saW1pdCc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ2RvY3VtZW50cy5pbnNlcnQnOiBmdW5jdGlvbiBkb2N1bWVudHNJbnNlcnQoZG9jKSB7XG4gICAgY2hlY2soZG9jLCB7XG4gICAgICB0aXRsZTogU3RyaW5nLFxuICAgICAgYm9keTogU3RyaW5nLFxuICAgIH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBEb2N1bWVudHMuaW5zZXJ0KHsgb3duZXI6IHRoaXMudXNlcklkLCAuLi5kb2MgfSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ2RvY3VtZW50cy51cGRhdGUnOiBmdW5jdGlvbiBkb2N1bWVudHNVcGRhdGUoZG9jKSB7XG4gICAgY2hlY2soZG9jLCB7XG4gICAgICBfaWQ6IFN0cmluZyxcbiAgICAgIHRpdGxlOiBTdHJpbmcsXG4gICAgICBib2R5OiBTdHJpbmcsXG4gICAgfSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgZG9jdW1lbnRJZCA9IGRvYy5faWQ7XG4gICAgICBEb2N1bWVudHMudXBkYXRlKGRvY3VtZW50SWQsIHsgJHNldDogZG9jIH0pO1xuICAgICAgcmV0dXJuIGRvY3VtZW50SWQ7IC8vIFJldHVybiBfaWQgc28gd2UgY2FuIHJlZGlyZWN0IHRvIGRvY3VtZW50IGFmdGVyIHVwZGF0ZS5cbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAnZG9jdW1lbnRzLnJlbW92ZSc6IGZ1bmN0aW9uIGRvY3VtZW50c1JlbW92ZShkb2N1bWVudElkKSB7XG4gICAgY2hlY2soZG9jdW1lbnRJZCwgU3RyaW5nKTtcblxuICAgIHRyeSB7XG4gICAgICByZXR1cm4gRG9jdW1lbnRzLnJlbW92ZShkb2N1bWVudElkKTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxufSk7XG5cbnJhdGVMaW1pdCh7XG4gIG1ldGhvZHM6IFtcbiAgICAnZG9jdW1lbnRzLmluc2VydCcsXG4gICAgJ2RvY3VtZW50cy51cGRhdGUnLFxuICAgICdkb2N1bWVudHMucmVtb3ZlJyxcbiAgXSxcbiAgbGltaXQ6IDUsXG4gIHRpbWVSYW5nZTogMTAwMCxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgRm9ybWF0cyBmcm9tICcuLi9Gb3JtYXRzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ2Zvcm1hdHMnLCBmdW5jdGlvbiBmb3JtYXRzKCkge1xuICByZXR1cm4gRm9ybWF0cy5maW5kKCk7XG59KTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIGNvbnNpc3RlbnQtcmV0dXJuICovXG5cbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuY29uc3QgRm9ybWF0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdGb3JtYXRzJyk7XG5cbkZvcm1hdHMuYWxsb3coe1xuICBpbnNlcnQ6ICgpID0+IGZhbHNlLFxuICB1cGRhdGU6ICgpID0+IGZhbHNlLFxuICByZW1vdmU6ICgpID0+IGZhbHNlLFxufSk7XG5cbkZvcm1hdHMuZGVueSh7XG4gIGluc2VydDogKCkgPT4gdHJ1ZSxcbiAgdXBkYXRlOiAoKSA9PiB0cnVlLFxuICByZW1vdmU6ICgpID0+IHRydWUsXG59KTtcblxuRm9ybWF0cy5zY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgbmFtZTogU3RyaW5nLFxufSk7XG5cbkZvcm1hdHMuYXR0YWNoU2NoZW1hKEZvcm1hdHMuc2NoZW1hKTtcblxuZXhwb3J0IGRlZmF1bHQgRm9ybWF0cztcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IEZvcm1hdHMgZnJvbSAnLi9Gb3JtYXRzJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAnZm9ybWF0cy5pbnNlcnQnOiBmdW5jdGlvbiBmb3JtYXRzSW5zZXJ0KGZvcm1hdCkge1xuICAgIGNoZWNrKGZvcm1hdCwge1xuICAgICAgbmFtZTogU3RyaW5nLFxuICAgIH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBGb3JtYXRzLmluc2VydChmb3JtYXQpO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IEdyb3VwcyBmcm9tICcuLi9Hcm91cHMnO1xuXG5NZXRlb3IucHVibGlzaCgnZ3JvdXBzJywgZnVuY3Rpb24gZ3JvdXBzKCkge1xuICByZXR1cm4gR3JvdXBzLmZpbmQoKTtcbn0pO1xuIiwiLyogZXNsaW50LWRpc2FibGUgY29uc2lzdGVudC1yZXR1cm4gKi9cblxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuXG5jb25zdCBHcm91cHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignR3JvdXBzJyk7XG5cbkdyb3Vwcy5hbGxvdyh7XG4gIGluc2VydDogKCkgPT4gZmFsc2UsXG4gIHVwZGF0ZTogKCkgPT4gZmFsc2UsXG4gIHJlbW92ZTogKCkgPT4gZmFsc2UsXG59KTtcblxuR3JvdXBzLmRlbnkoe1xuICBpbnNlcnQ6ICgpID0+IHRydWUsXG4gIHVwZGF0ZTogKCkgPT4gdHJ1ZSxcbiAgcmVtb3ZlOiAoKSA9PiB0cnVlLFxufSk7XG5cbkdyb3Vwcy5zY2hlbWEgPSBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgbmFtZTogU3RyaW5nLFxufSk7XG5cbkdyb3Vwcy5hdHRhY2hTY2hlbWEoR3JvdXBzLnNjaGVtYSk7XG5cbmV4cG9ydCBkZWZhdWx0IEdyb3VwcztcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IEdyb3VwcyBmcm9tICcuL0dyb3Vwcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ2dyb3Vwcy5pbnNlcnQnOiBmdW5jdGlvbiBncm91cHNJbnNlcnQoZ3JvdXApIHtcbiAgICBjaGVjayhncm91cCwge1xuICAgICAgbmFtZTogU3RyaW5nLFxuICAgIH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBHcm91cHMuaW5zZXJ0KGdyb3VwKTtcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBNZXNzYWdlVHlwZXMgZnJvbSAnLi4vTWVzc2FnZVR5cGVzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ21lc3NhZ2VUeXBlcycsIGZ1bmN0aW9uIG1lc3NhZ2VUeXBlcygpIHtcbiAgcmV0dXJuIE1lc3NhZ2VUeXBlcy5maW5kKCk7XG59KTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIGNvbnNpc3RlbnQtcmV0dXJuICovXG5cbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuY29uc3QgTWVzc2FnZVR5cGVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ01lc3NhZ2VUeXBlcycpO1xuXG5NZXNzYWdlVHlwZXMuYWxsb3coe1xuICBpbnNlcnQ6ICgpID0+IGZhbHNlLFxuICB1cGRhdGU6ICgpID0+IGZhbHNlLFxuICByZW1vdmU6ICgpID0+IGZhbHNlLFxufSk7XG5cbk1lc3NhZ2VUeXBlcy5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiB0cnVlLFxuICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIHJlbW92ZTogKCkgPT4gdHJ1ZSxcbn0pO1xuXG5NZXNzYWdlVHlwZXMuc2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIG5hbWU6IFN0cmluZyxcbn0pO1xuXG5NZXNzYWdlVHlwZXMuYXR0YWNoU2NoZW1hKE1lc3NhZ2VUeXBlcy5zY2hlbWEpO1xuXG5leHBvcnQgZGVmYXVsdCBNZXNzYWdlVHlwZXM7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBNZXNzYWdlVHlwZXMgZnJvbSAnLi9NZXNzYWdlVHlwZXMnO1xuaW1wb3J0IHJhdGVMaW1pdCBmcm9tICcuLi8uLi9tb2R1bGVzL3JhdGUtbGltaXQnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdtZXNzYWdlVHlwZXMuaW5zZXJ0JzogZnVuY3Rpb24gbWVzc2FnZVR5cGVzSW5zZXJ0KG1lc3NhZ2VUeXBlKSB7XG4gICAgY2hlY2sobWVzc2FnZVR5cGUsIHtcbiAgICAgIG5hbWU6IFN0cmluZyxcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICByZXR1cm4gTWVzc2FnZVR5cGVzLmluc2VydChtZXNzYWdlVHlwZSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgeyBTZXJ2aWNlQ29uZmlndXJhdGlvbiB9IGZyb20gJ21ldGVvci9zZXJ2aWNlLWNvbmZpZ3VyYXRpb24nO1xuaW1wb3J0IHJhdGVMaW1pdCBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL3JhdGUtbGltaXQnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdvYXV0aC52ZXJpZnlDb25maWd1cmF0aW9uJzogZnVuY3Rpb24gb2F1dGhWZXJpZnlDb25maWd1cmF0aW9uKHNlcnZpY2VzKSB7XG4gICAgY2hlY2soc2VydmljZXMsIEFycmF5KTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB2ZXJpZmllZFNlcnZpY2VzID0gW107XG4gICAgICBzZXJ2aWNlcy5mb3JFYWNoKChzZXJ2aWNlKSA9PiB7XG4gICAgICAgIGlmIChTZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucy5maW5kT25lKHsgc2VydmljZSB9KSkge1xuICAgICAgICAgIHZlcmlmaWVkU2VydmljZXMucHVzaChzZXJ2aWNlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICByZXR1cm4gdmVyaWZpZWRTZXJ2aWNlcy5zb3J0KCk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbn0pO1xuXG5yYXRlTGltaXQoe1xuICBtZXRob2RzOiBbXG4gICAgJ29hdXRoLnZlcmlmeUNvbmZpZ3VyYXRpb24nLFxuICBdLFxuICBsaW1pdDogNSxcbiAgdGltZVJhbmdlOiAxMDAwLFxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBRdWV1ZXMgZnJvbSAnLi4vUXVldWVzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3F1ZXVlcycsIGZ1bmN0aW9uIHF1ZXVlcygpIHtcbiAgcmV0dXJuIFF1ZXVlcy5maW5kKCk7XG59KTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIGNvbnNpc3RlbnQtcmV0dXJuICovXG5cbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuY29uc3QgUXVldWVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ1F1ZXVlcycpO1xuXG5RdWV1ZXMuYWxsb3coe1xuICBpbnNlcnQ6ICgpID0+IGZhbHNlLFxuICB1cGRhdGU6ICgpID0+IGZhbHNlLFxuICByZW1vdmU6ICgpID0+IGZhbHNlLFxufSk7XG5cblF1ZXVlcy5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiB0cnVlLFxuICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIHJlbW92ZTogKCkgPT4gdHJ1ZSxcbn0pO1xuXG5RdWV1ZXMuc2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIG5hbWU6IFN0cmluZyxcbn0pO1xuXG5RdWV1ZXMuYXR0YWNoU2NoZW1hKFF1ZXVlcy5zY2hlbWEpO1xuXG5leHBvcnQgZGVmYXVsdCBRdWV1ZXM7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBRdWV1ZXMgZnJvbSAnLi9RdWV1ZXMnO1xuaW1wb3J0IHJhdGVMaW1pdCBmcm9tICcuLi8uLi9tb2R1bGVzL3JhdGUtbGltaXQnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICdxdWV1ZXMuaW5zZXJ0JzogZnVuY3Rpb24gcXVldWVzSW5zZXJ0KHF1ZXVlKSB7XG4gICAgY2hlY2socXVldWUsIHtcbiAgICAgIG5hbWU6IFN0cmluZyxcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICByZXR1cm4gUXVldWVzLmluc2VydChxdWV1ZSk7XG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBQb29sIH0gZnJvbSAncGcnO1xuaW1wb3J0IGpzZGlmZiBmcm9tICdkaWZmJztcbmltcG9ydCBUZXN0Q2FzZXMgZnJvbSAnLi4vVGVzdENhc2VzJztcbmltcG9ydCBRdWV1ZXMgZnJvbSAnLi4vLi4vUXVldWVzL1F1ZXVlcyc7XG5pbXBvcnQgR3JvdXBzIGZyb20gJy4uLy4uL0dyb3Vwcy9Hcm91cHMnO1xuaW1wb3J0IE1lc3NhZ2VUeXBlcyBmcm9tICcuLi8uLi9NZXNzYWdlVHlwZXMvTWVzc2FnZVR5cGVzJztcbmltcG9ydCBEZXBhcnRtZW50Q29kZXMgZnJvbSAnLi4vLi4vRGVwYXJ0bWVudENvZGVzL0RlcGFydG1lbnRDb2Rlcyc7XG5pbXBvcnQgRm9ybWF0cyBmcm9tICcuLi8uLi9Gb3JtYXRzL0Zvcm1hdHMnO1xuXG5jb25zdCBwb29sID0gbmV3IFBvb2woTWV0ZW9yLnNldHRpbmdzLnByaXZhdGUucG9zdGdyZXMpO1xuXG5jb25zdCBvbGRQb29sUXVlcnkgPSBwb29sLnF1ZXJ5O1xucG9vbC5xdWVyeSA9ICguLi5hcmdzKSA9PiB7XG4gIGNvbnNvbGUubG9nKCdRVUVSWTonLCBhcmdzKTtcbiAgcmV0dXJuIG9sZFBvb2xRdWVyeS5hcHBseShwb29sLCBhcmdzKTtcbn07XG5cbmNvbnN0IGZldGNoID0gYXN5bmMgKHF1ZXJ5LCBwYXJhbXMpID0+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBhd2FpdCBwb29sLmNvbm5lY3QoKTtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQucXVlcnkocXVlcnksIHBhcmFtcyk7XG4gICAgcmVzdWx0LnJvd3MuZm9yRWFjaCgocmVzdWx0KSA9PiB7XG4gICAgICAvLyBOT1RFOiByZXN1bHQgaGVyZSB3aWxsIGxpa2VseSBuZWVkIHRvIGJlIG1hcHBlZCB0byBzcGVjaWZpYyBmaWVsZHMgaW4gTW9uZ29EQiBpbnN0ZWFkIG9mIGEgcGxhaW4gZHVtcC5cbiAgICAgIC8vICBUZXN0Q2FzZXMuaW5zZXJ0KHJlc3VsdCk7XG4gICAgfSk7XG5cbiAgICBhd2FpdCBjbGllbnQucmVsZWFzZSh0cnVlKTtcbiAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGV4Y2VwdGlvbi5tZXNzYWdlKTtcbiAgfVxufTtcblxuY29uc3QgdXBkYXRlU3RhdHVzQW5kRGlmZlJlc3VsdCA9IGFzeW5jIChfaWQsIGRpZmZDb3VudCkgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IHBvb2wuY29ubmVjdCgpO1xuICAgIHZhciBxdWVyeSA9IGBgO1xuXG4gICAgaWYgKGRpZmZDb3VudCA9PSAwKSB7XG4gICAgICBxdWVyeSA9IGBcbiAgICAgICAgdXBkYXRlIGJ1c190ZXN0X2Nhc2VzXG4gICAgICAgIHNldCBjX3Rlc3Rfc3RhdHVzID0gJ3Bhc3NlZCdcbiAgICAgICAgLCBuX2RpZmZfY291bnQgPSAke2RpZmZDb3VudH1cbiAgICAgICAgLCBjX25vdGlmaWNhdGlvbl9zZW50ID0gJydcbiAgICAgICAgd2hlcmUgY190ZXN0X2Nhc2VfaWQgPSAnJHtfaWR9J1xuICAgICAgYDtcbiAgICB9IGVsc2Uge1xuICAgICAgcXVlcnkgPSBgXG4gICAgICAgIHVwZGF0ZSBidXNfdGVzdF9jYXNlc1xuICAgICAgICBzZXQgY190ZXN0X3N0YXR1cyA9ICdmYWlsZWQnXG4gICAgICAgICwgbl9kaWZmX2NvdW50ID0gJHtkaWZmQ291bnR9XG4gICAgICAgICwgY19ub3RpZmljYXRpb25fc2VudCA9ICcnXG4gICAgICAgIHdoZXJlIGNfdGVzdF9jYXNlX2lkID0gJyR7X2lkfSdcbiAgICAgIGA7XG4gICAgfTtcblxuICAgIGNvbnNvbGUubG9nKFwidXBkYXRlU3RhdHVzQW5kRGlmZlJlc3VsdDogXCIsIHF1ZXJ5KTtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmZXRjaChxdWVyeSk7XG4gICAgYXdhaXQgY2xpZW50LnJlbGVhc2UodHJ1ZSlcbiAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGV4Y2VwdGlvbi5tZXNzYWdlKTtcbiAgfVxufTtcblxuY29uc3QgdXBkYXRlRXhwZWN0ZWRSZXN1bHQgPSBhc3luYyAoX2lkLCB0ZXN0UnVuUmVzdWx0KSA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gYXdhaXQgcG9vbC5jb25uZWN0KCk7XG5cbiAgICAvLyB1cGRhdGUgYnVzX3Rlc3RfY2FzZXMgc2V0IHRlc3RfbWVzc2FnZSA9ICQyIHdoZXJlIHRlc3RfY2FzZV9pZCA9ICQxO1xuICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgIHVwZGF0ZSBidXNfdGVzdF9jYXNlcyBzZXRcbiAgICBjX2V4cGVjdGVkX3Jlc3VsdHRyYWNlID0gJHRva2VuJCR7dGVzdFJ1blJlc3VsdH0kdG9rZW4kXG4gICAgLCBjX3Rlc3Rfc3RhdHVzID0gJ3Bhc3NlZCdcbiAgICAsIG5fZGlmZl9jb3VudCA9IDBcbiAgICAsIGNfbm90aWZpY2F0aW9uX3NlbnQgPSAnJ1xuICAgIHdoZXJlXG4gICAgY190ZXN0X2Nhc2VfaWQgPSAnJHtfaWR9J1xuICAgIGA7XG5cbiAgICBjb25zb2xlLmxvZyhcInVwZGF0ZUV4cGVjdGVkUmVzdWx0OiBcIiwgcXVlcnkpO1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5xdWVyeShxdWVyeSk7XG4gICAgYXdhaXQgY2xpZW50LnJlbGVhc2UodHJ1ZSk7XG4gIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgIHRocm93IG5ldyBFcnJvcihleGNlcHRpb24ubWVzc2FnZSk7XG4gIH1cbn07XG5cbmNvbnN0IHBvbGxSZWFkeVRlc3RzID0gYXN5bmMgKCkgPT4ge1xuICB0cnkge1xuICAgIHZhciB0b2RheSA9IG5ldyBEYXRlKCk7XG4gICAgY29uc3QgY2xpZW50ID0gYXdhaXQgcG9vbC5jb25uZWN0KCk7XG4gICAgY29uc3QgcXVlcnkgPSBgXG4gICAgICBzZWxlY3QgY190ZXN0X2Nhc2VfaWQsIGNvYWxlc2NlKGNfZXhwZWN0ZWRfcmVzdWx0dHJhY2UsICcnKSBhcyBjX2V4cGVjdGVkX3Jlc3VsdHRyYWNlXG4gICAgICAsIGNvYWxlc2NlKGNfdGVzdF9ydW5fcmVzdWx0dHJhY2UsICcnKSBhcyBjX3Rlc3RfcnVuX3Jlc3VsdHRyYWNlXG4gICAgICAsIGNvYWxlc2NlKGNfaXBjbGluaywgJycpIGFzIGNfaXBjbGlua1xuICAgICAgZnJvbSBidXNfdGVzdF9jYXNlc1xuICAgICAgd2hlcmUgY190ZXN0X3N0YXR1cyA9ICdyZWFkeSdcbiAgICBgO1xuXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2xpZW50LnF1ZXJ5KHF1ZXJ5KTtcbiAgICByZXN1bHQucm93cy5mb3JFYWNoKChyb3cpID0+IHtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgY190ZXN0X2Nhc2VfaWQ6IF9pZCxcbiAgICAgICAgY19leHBlY3RlZF9yZXN1bHR0cmFjZTogZXhwZWN0ZWRSZXN1bHQsXG4gICAgICAgIGNfdGVzdF9ydW5fcmVzdWx0dHJhY2U6IHRlc3RSdW5SZXN1bHQsXG4gICAgICAgIGNfaXBjbGluazogaXBjTGluayxcbiAgICAgIH0gPSByb3c7XG5cbiAgICAgIC8vY2hlY2sgaWYgdGhlcmUgaXMgYSBNb25nb1JlY29yZCB0byB0aGUgUG9zdGdyZXNxbCBkYXRhLiBJZiBub3Qgc2tpcCB0byB0aGUgbmV4dCBtc2dcbiAgICAgIGlmIChUZXN0Q2FzZXMuZmluZE9uZShfaWQpKSB7XG4gICAgICAgIGNvbnN0IG1vbmdvRXhwZWN0ZWRSZXN1bHQgPSBUZXN0Q2FzZXMuZmluZE9uZShfaWQpLmV4cGVjdGVkUmVzdWx0O1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCdwb2xsUmVhZHlUZXN0cyBUaW1lc3RhbXAgYW5kIElEOiAnLCB0b2RheSwgX2lkKTtcbiAgICAgICAgLy8gdGVzdCByZXN1bHQgaXMgZW1wdHksIG5ldyB0ZXN0IGNhc2VcbiAgICAgICAgaWYgKCFleHBlY3RlZFJlc3VsdCB8fCAhbW9uZ29FeHBlY3RlZFJlc3VsdCkge1xuICAgICAgICAgIFRlc3RDYXNlcy51cGRhdGUoX2lkLCB7XG4gICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgIHRlc3RSdW5SZXN1bHQsXG4gICAgICAgICAgICAgIGV4cGVjdGVkUmVzdWx0OiB0ZXN0UnVuUmVzdWx0LFxuICAgICAgICAgICAgICB0ZXN0U3RhdHVzOiAncGFzc2VkJyxcbiAgICAgICAgICAgICAgZGlmZkNvdW50OiAwLFxuICAgICAgICAgICAgICB0ZXN0U3RhcnQ6IHRvZGF5LFxuICAgICAgICAgICAgICBpcGNMaW5rLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIHVwZGF0ZUV4cGVjdGVkUmVzdWx0KF9pZCwgdGVzdFJ1blJlc3VsdCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gdGVzdCByZXN1bHQgaXMgc2FtZVxuICAgICAgICAgIC8vIHRlc3QgcmVzdWx0IGlzIGRpZmZlcmVudFxuICAgICAgICAgIC8vIGNvbnN0IGRpZmZDb3VudCA9IGRpZmYuZmlsdGVyKHBhcnQgPT4gcGFydC5hZGRlZCB8fCBwYXJ0LnJlbW92ZWQpLmxlbmd0aDtcbiAgICAgICAgICAvL2NvbnN0IGlnbm9yZVdoaXRlc3BhY2UgPSB0cnVlO1xuICAgICAgICAgIC8vY29uc3QgbmV3bGluZUlzVG9rZW4gPSB0cnVlO1xuICAgICAgICAgIFxuICAgICAgICAgIGNvbnNvbGUubG9nKCdXaWxsIG5vdyBjb21wYXJlIG1vbmdvRXhwZWN0ZWRSZXN1bHQgd2l0aCBEQiB0ZXN0UnVuUmVzdWx0IGZvciBJRDogJywgX2lkKTtcbiAgICAgICAgICBjb25zdCBkaWZmID0ganNkaWZmLmRpZmZXb3Jkcyh0ZXN0UnVuUmVzdWx0LnN1YnN0cmluZygwLDQwMDAwKSB8fCAnJywgbW9uZ29FeHBlY3RlZFJlc3VsdC5zdWJzdHJpbmcoMCw0MDAwMCkgfHwgJycpO1xuICAgICAgICAgIC8vY29uc3QgZGlmZiA9IGpzZGlmZi5kaWZmTGluZXModGVzdFJ1blJlc3VsdC5zdWJzdHJpbmcoMCw0MDAwMCkgfHwgJycsIG1vbmdvRXhwZWN0ZWRSZXN1bHQuc3Vic3RyaW5nKDAsNDAwMDApIHx8ICcnLCBpZ25vcmVXaGl0ZXNwYWNlLCBuZXdsaW5lSXNUb2tlbik7XG4gICAgICAgICAgY29uc29sZS5sb2coJ2NvbXBhcmUgY29tcGxldGUgYXQ6ICcsIHRvZGF5KTtcbiAgICAgICAgICBsZXQgZGlmZkNvdW50ID0gMDtcblxuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGRpZmYubWFwKGZ1bmN0aW9uKHBhcnQsIGluZGV4KSB7XG4gICAgICAgICAgICBpZiAocGFydC5hZGRlZCB8fCBwYXJ0LnJlbW92ZWQpIHtcbiAgICAgICAgICAgICAgZGlmZkNvdW50ICs9IDE7XG4gICAgICAgICAgICB9fSk7XG4gICAgICAgICAgXG4gICAgICAgICAgLy9jaGVjayBkaWZmY291bnQgPT0gMCBhbmQgdGhlIGxlbmd0aCBvZiBlaXRoZXIgdGhlIGV4cGVjdGVkIHJlc3VsdCBvZiB0aGUgYWN0dWFsIHJlc3VsdCBpcyBhYm92ZSA0MDAwMCwgY29tcGFyZSB0aGUgdHdvIGxlbmd0aHMuIFxuICAgICAgICAgIC8vSWYgdGhleSBkb24ndCBtYXRjaCB0aGVuIHJlcG9ydCBkaWZmZXJlbmNlXG4gICAgICAgICAgaWYgKGRpZmZDb3VudCA9PSAwICYmIChtb25nb0V4cGVjdGVkUmVzdWx0Lmxlbmd0aCA+IDQwMDAwIHx8ICh0ZXN0UnVuUmVzdWx0Lmxlbmd0aCA+IDQwMDAwKSAmJiBtb25nb0V4cGVjdGVkUmVzdWx0Lmxlbmd0aCAhPSB0ZXN0UnVuUmVzdWx0Lmxlbmd0aCkpIHtcbiAgICAgICAgICAgIGRpZmZDb3VudCA9IDE7XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8vdXBkYXRlIHRoZSBtb25nbyBEQiBpbnN0YW5jZVxuICAgICAgICAgIFRlc3RDYXNlcy51cGRhdGUoX2lkLCB7XG4gICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgIHRlc3RSdW5SZXN1bHQsXG4gICAgICAgICAgICAgIHRlc3RTdGF0dXM6IGRpZmZDb3VudCA9PT0gMCA/ICdwYXNzZWQnIDogJ2ZhaWxlZCcsXG4gICAgICAgICAgICAgIGRpZmZDb3VudCxcbiAgICAgICAgICAgICAgdGVzdFN0YXJ0OiB0b2RheSxcbiAgICAgICAgICAgICAgaXBjTGluayxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICAvL3VwZGF0ZSB0aGUgUG9zdGdyZXNxbCB3aXRoIHRoZSBzYW1lIGluZm9cbiAgICAgICAgICBjb25zb2xlLmxvZygnY2FsbCB1cGRhdGVTdGF0dXNBbmREaWZmUmVzdWx0IHRvIHN0b3JlIGRpZmZDb3VudDogJywgZGlmZkNvdW50KTtcbiAgICAgICAgICB1cGRhdGVTdGF0dXNBbmREaWZmUmVzdWx0KF9pZCwgZGlmZkNvdW50KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgYXdhaXQgY2xpZW50LnJlbGVhc2UodHJ1ZSlcbiAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGV4Y2VwdGlvbi5tZXNzYWdlKTtcbiAgfVxufTtcblxuLy8gZnVuY3Rpb24gdG8gaW1wb3J0IGFsbCBkYXRhIGZyb20gUG9zdGdyZXNxbC4gRGVsZXRlcyBhbGwgZXhpc3RpbmcgZGF0YSBpbiBNb25nby5cbmNvbnN0IGxvYWRGcm9tUG9zdGdyZXNxbCA9IGFzeW5jICh1c2VySWQpID0+IHtcbiAgdHJ5IHtcbiAgICAvLyBkZWZpbmUgdmFsdWUgbGlzdHMgdXNlZCBmb3IgY2hlY2tpbmcgaW5wdXQgZGF0YVxuICAgIHZhciB2YWxpZExpbmVCcmVha3MgPSBbXCJDUlwiLCBcIkNSTEZcIl07XG4gICAgdmFyIHZhbGlkRGVwYXJ0bWVudENvZGVzID0gW1wiY3NcIixcImlzXCIsXCJmc1wiLFwic3NcIixcImRldlwiXVxuXG4gICAgY29uc3QgY2xpZW50ID0gYXdhaXQgcG9vbC5jb25uZWN0KCk7XG4gICAgLy8gcXVlcnkgdG8gZ2V0IGFsbCB0ZXN0X2Nhc2VzIGZyb20gUG9zdGdyZXNxbFxuICAgIGNvbnN0IHF1ZXJ5ID0gYFxuICAgIHNlbGVjdFxuICAgIGNfdGVzdF9jYXNlX2lkLFxuICAgIGNfdGVzdF9jYXNlX25hbWUsXG4gICAgY19ncm91cF9uYW1lLFxuICAgIGNfbWVzc2FnZV90eXBlLFxuICAgIGNfZm9ybWF0LFxuICAgIGNfbG9hZGluZ19xdWV1ZSxcbiAgICBjX3Rlc3RfbWVzc2FnZSxcbiAgICBjX3JoZjJfaGVhZGVyLFxuICAgIGNfY29tbWVudCxcbiAgICBjX2V4cGVjdGVkX3Jlc3VsdHRyYWNlLFxuICAgIGNfdGVzdF9ydW5fcmVzdWx0dHJhY2UsXG4gICAgY19sYXN0X2VkaXRvcixcbiAgICBuX2RpZmZfY291bnQsXG4gICAgbl9hdXRvdGVzdCxcbiAgICBuX2RlbGF5ZWQsXG4gICAgbl9ydW50aW1lX2luX3NlYyxcbiAgICBuX2NvbXBsZXRlc19pbl9pcGMsXG4gICAgY19tcW1kX3VzZXJpZGVudGlmaWVyLFxuICAgIGNfbGluZWJyZWFrLFxuICAgIGNfdGVzdGlkX3ByZWZpeCxcbiAgICBjX2ppcmFfdXJsLFxuICAgIGNfZGVwYXJ0bWVudF9jb2RlXG4gICAgZnJvbSBidXNfdGVzdF9jYXNlc1xuICAgIHdoZXJlIGNfdGVzdF9tZXNzYWdlIGlzIG5vdCBudWxsXG4gICAgYDtcblxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5xdWVyeShxdWVyeSk7XG5cbiAgICAvLyBkZWxldGUgZXhpc3RpbmcgTW9uZ28gcmVjb3Jkc1xuICAgIC8vIGRlbGV0ZSBRdWV1ZXNcbiAgICBHcm91cHMucmVtb3ZlKHt9KTtcbiAgICBRdWV1ZXMucmVtb3ZlKHt9KTtcbiAgICBNZXNzYWdlVHlwZXMucmVtb3ZlKHt9KTtcbiAgICBGb3JtYXRzLnJlbW92ZSh7fSk7XG4gICAgVGVzdENhc2VzLnJlbW92ZSh7fSk7XG4gICAgRGVwYXJ0bWVudENvZGVzLnJlbW92ZSh7fSk7XG5cbiAgICBjb25zdCBzZXRHcm91cHMgPSBuZXcgU2V0KCk7XG4gICAgY29uc3Qgc2V0UXVldWVzID0gbmV3IFNldCgpO1xuICAgIGNvbnN0IHNldE1lc3NhZ2VUeXBlcyA9IG5ldyBTZXQoKTtcbiAgICBjb25zdCBzZXRGb3JtYXRzID0gbmV3IFNldCgpO1xuXG4gICAgY29uc29sZS5sb2coJ3Byb2Nlc3MgZWFjaCByb3cgZnJvbSBQb3N0Z3Jlc3FsJyk7XG4gICAgcmVzdWx0LnJvd3MuZm9yRWFjaCgocm93KSA9PiB7XG4gICAgICBjb25zdCB0ZXN0Q2FzZSA9IHtcbiAgICAgICAgX2lkOiByb3cuY190ZXN0X2Nhc2VfaWQsXG4gICAgICAgIG93bmVyOiB1c2VySWQsXG4gICAgICAgIG5hbWU6IHJvdy5jX3Rlc3RfY2FzZV9uYW1lLFxuICAgICAgICB0ZXN0SWRQcmVmaXg6IHJvdy5jX3Rlc3RpZF9wcmVmaXgsXG4gICAgICAgIGppcmFVUkw6IHJvdy5jX2ppcmFfdXJsLFxuICAgICAgICBncm91cDogcm93LmNfZ3JvdXBfbmFtZSxcbiAgICAgICAgbWVzc2FnZVR5cGU6IHJvdy5jX21lc3NhZ2VfdHlwZSxcbiAgICAgICAgZm9ybWF0OiByb3cuY19mb3JtYXQsXG4gICAgICAgIGxvYWRpbmdRdWV1ZTogcm93LmNfbG9hZGluZ19xdWV1ZSxcbiAgICAgICAgdGVzdE1lc3NhZ2U6IHJvdy5jX3Rlc3RfbWVzc2FnZSwgLy8gY2xvYlxuICAgICAgICB0ZXN0U3RhdHVzOiAncmVhZHknLFxuICAgICAgICByZmgySGVhZGVyOiByb3cuY19yaGYyX2hlYWRlciwgLy8gY2xvYlxuICAgICAgICBjb21tZW50OiByb3cuY19jb21tZW50LFxuICAgICAgICBleHBlY3RlZFJlc3VsdDogcm93LmNfZXhwZWN0ZWRfcmVzdWx0dHJhY2UsIC8vIGNsb2JcbiAgICAgICAgdGVzdFJ1blJlc3VsdDogcm93LmNfdGVzdF9ydW5fcmVzdWx0dHJhY2UsXG4gICAgICAgIGRpZmZDb3VudDogcm93Lm5fZGlmZl9jb3VudCxcbiAgICAgICAgYXV0b1Rlc3Q6IHJvdy5uX2F1dG90ZXN0ID8gdHJ1ZSA6IGZhbHNlLFxuICAgICAgICBkZWxheWVkVGVzdDogcm93Lm5fZGVsYXllZCA/IHRydWUgOiBmYWxzZSxcbiAgICAgICAgcnVuVGltZVNlYzogcm93Lm5fcnVudGltZV9pbl9zZWMsXG4gICAgICAgIGNvbXBsZXRlc0luSXBjOiByb3cubl9jb21wbGV0ZXNfaW5faXBjID8gdHJ1ZSA6IGZhbHNlLFxuICAgICAgICBtcVVzZXJJZGVudGlmaWVyOiByb3cuY19tcW1kX3VzZXJpZGVudGlmaWVyLFxuICAgICAgICBsaW5lZmVlZDogdmFsaWRMaW5lQnJlYWtzLmluY2x1ZGVzKHJvdy5jX2xpbmVicmVhaykgPyByb3cuY19saW5lYnJlYWsgOiBcIkNSTEZcIixcbiAgICAgICAgZGVwYXJ0bWVudENvZGU6IHZhbGlkRGVwYXJ0bWVudENvZGVzLmluY2x1ZGVzKHJvdy5jX2RlcGFydG1lbnRfY29kZSkgPyByb3cuY19kZXBhcnRtZW50X2NvZGUgOiBcImRldlwiICxcbiAgICAgIH07XG5cblxuICAgICAgY29uc29sZS5sb2coJ3Rlc3RDYXNlOiAnLCB0ZXN0Q2FzZSlcbiAgICAgIFRlc3RDYXNlcy5pbnNlcnQodGVzdENhc2UpO1xuICAgICAgc2V0R3JvdXBzLmFkZChyb3cuY19ncm91cF9uYW1lKTtcbiAgICAgIHNldFF1ZXVlcy5hZGQocm93LmNfbG9hZGluZ19xdWV1ZSk7XG4gICAgICBzZXRNZXNzYWdlVHlwZXMuYWRkKHJvdy5jX21lc3NhZ2VfdHlwZSk7XG4gICAgICBzZXRGb3JtYXRzLmFkZChyb3cuY19mb3JtYXQpO1xuICAgIH0pO1xuXG4gICAgc2V0R3JvdXBzLmZvckVhY2gobmFtZSA9PiBHcm91cHMuaW5zZXJ0KHsgbmFtZSB9KSk7XG4gICAgc2V0UXVldWVzLmZvckVhY2gobmFtZSA9PiBRdWV1ZXMuaW5zZXJ0KHsgbmFtZSB9KSk7XG4gICAgc2V0TWVzc2FnZVR5cGVzLmZvckVhY2gobmFtZSA9PiBNZXNzYWdlVHlwZXMuaW5zZXJ0KHsgbmFtZSB9KSk7XG4gICAgc2V0Rm9ybWF0cy5mb3JFYWNoKG5hbWUgPT4gRm9ybWF0cy5pbnNlcnQoeyBuYW1lIH0pKTtcblxuICAgIC8vIFNldCB2YWxpZCBkZXBhcnRtZW50Q29kZXNcbiAgICBEZXBhcnRtZW50Q29kZXMuaW5zZXJ0KHsgbmFtZTogJ2NzJyB9KTtcbiAgICBEZXBhcnRtZW50Q29kZXMuaW5zZXJ0KHsgbmFtZTogJ2ZzJyB9KTtcbiAgICBEZXBhcnRtZW50Q29kZXMuaW5zZXJ0KHsgbmFtZTogJ2lzJyB9KTtcbiAgICBEZXBhcnRtZW50Q29kZXMuaW5zZXJ0KHsgbmFtZTogJ3NzJyB9KTtcbiAgICBEZXBhcnRtZW50Q29kZXMuaW5zZXJ0KHsgbmFtZTogJ2RldicgfSk7XG5cbiAgICBjb25zb2xlLmxvZygnR3JvdXBzOiAnLCBHcm91cHMuZmluZCh7fSkuZmV0Y2goKSk7XG4gICAgY29uc29sZS5sb2coJ0RlcGFydG1lbnRDb2RlczogJywgRGVwYXJ0bWVudENvZGVzLmZpbmQoe30pLmZldGNoKCkpO1xuXG4gICAgYXdhaXQgY2xpZW50LnJlbGVhc2UodHJ1ZSk7XG4gIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgIHRocm93IG5ldyBFcnJvcihleGNlcHRpb24ubWVzc2FnZSk7XG4gIH1cbn07XG5cbmNvbnN0IGluc2VydCA9IGFzeW5jICh0ZXN0Q2FzZSkgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IHBvb2wuY29ubmVjdCgpO1xuICAgIGNvbnN0IHtcbiAgICAgIF9pZCxcbiAgICAgIG93bmVyLFxuICAgICAgbmFtZSxcbiAgICAgIHRlc3RJZFByZWZpeCxcbiAgICAgIG1lc3NhZ2VUeXBlLFxuICAgICAgZm9ybWF0LFxuICAgICAgbG9hZGluZ1F1ZXVlLFxuICAgICAgcnVuVGltZVNlYyxcbiAgICAgIHRlc3RNZXNzYWdlLFxuICAgICAgY29tcGxldGVzSW5JcGMsXG4gICAgICByZmgySGVhZGVyLFxuICAgICAgY29tbWVudCxcbiAgICAgIGdyb3VwLFxuICAgICAgYXV0b1Rlc3QsXG4gICAgICBkZWxheWVkVGVzdCxcbiAgICAgIG1xVXNlcklkZW50aWZpZXIsXG4gICAgICBsaW5lZmVlZCxcbiAgICAgIGppcmFVUkwsXG4gICAgICBkZXBhcnRtZW50Q29kZSxcbiAgICB9ID0gdGVzdENhc2U7XG5cbiAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgIGluc2VydCBpbnRvIGJ1c190ZXN0X2Nhc2VzKFxuICAgICAgICBjX3Rlc3RfY2FzZV9pZCwgY190ZXN0X2Nhc2VfbmFtZSwgY19tZXNzYWdlX3R5cGUsIGNfZm9ybWF0LFxuICAgICAgICBjX2xvYWRpbmdfcXVldWUsIGNfdGVzdF9tZXNzYWdlLCBjX3Rlc3Rfc3RhdHVzLCBjX3JoZjJfaGVhZGVyLFxuICAgICAgICBjX2NvbW1lbnQsIGNfZ3JvdXBfbmFtZSwgY19sYXN0X2VkaXRvciwgbl9ydW50aW1lX2luX3NlYyxcbiAgICAgICAgbl9jb21wbGV0ZXNfaW5faXBjLCBuX2F1dG90ZXN0LCBuX2RlbGF5ZWQsIGNfbXFtZF91c2VyaWRlbnRpZmllciwgY19saW5lYnJlYWssXG4gICAgICAgIGNfdGVzdGlkX3ByZWZpeCwgY19qaXJhX3VybCwgY19kZXBhcnRtZW50X2NvZGVcbiAgICAgIClcbiAgICAgIHZhbHVlcyhcbiAgICAgICAgJyR7X2lkfScsICcke25hbWV9JywgJyR7bWVzc2FnZVR5cGV9JywgJyR7Zm9ybWF0fScsXG4gICAgICAgICcke2xvYWRpbmdRdWV1ZX0nLCAkdG9rZW4kJHt0ZXN0TWVzc2FnZX0kdG9rZW4kLCAnbmV3JywgJHRva2VuJCR7cmZoMkhlYWRlcn0kdG9rZW4kLFxuICAgICAgICAkdG9rZW4kJHtjb21tZW50fSR0b2tlbiQsICcke2dyb3VwfScsICcke293bmVyfScsICR7cnVuVGltZVNlY30sXG4gICAgICAgICR7Y29tcGxldGVzSW5JcGMgPyAxIDogMH0sICR7YXV0b1Rlc3QgPyAxIDogMH0sICR7ZGVsYXllZFRlc3QgPyAxIDogMH0sXG4gICAgICAgICcke21xVXNlcklkZW50aWZpZXJ9JywgJyR7bGluZWZlZWR9JywgJyR7dGVzdElkUHJlZml4fScsICcke2ppcmFVUkx9JyxcbiAgICAgICAgJyR7ZGVwYXJ0bWVudENvZGV9J1xuICAgICAgKTtcbiAgICBgO1xuXG4gICAgY29uc3QgY2xlYW5xdWVyeSA9IHF1ZXJ5LnJlcGxhY2UoLyd1bmRlZmluZWQnLC9nLCAnXFwnXFwnLCcpO1xuXG4gICAgY29uc29sZS5sb2coJ0luc2VydCBuZXcgdGVzdGNhc2Ugd2l0aDonLCBjbGVhbnF1ZXJ5KTtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQucXVlcnkoY2xlYW5xdWVyeSk7XG4gICAgYXdhaXQgY2xpZW50LnJlbGVhc2UodHJ1ZSk7XG4gIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgIHRocm93IG5ldyBFcnJvcihleGNlcHRpb24ubWVzc2FnZSk7XG4gIH1cbn07XG5cbmNvbnN0IHVwZGF0ZSA9IGFzeW5jICh0ZXN0Q2FzZSkgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IHBvb2wuY29ubmVjdCgpO1xuICAgIGNvbnN0IHtcbiAgICAgIF9pZCxcbiAgICAgIG93bmVyLFxuICAgICAgbmFtZSxcbiAgICAgIHRlc3RJZFByZWZpeCxcbiAgICAgIG1lc3NhZ2VUeXBlLFxuICAgICAgZm9ybWF0LFxuICAgICAgbG9hZGluZ1F1ZXVlLFxuICAgICAgcnVuVGltZVNlYyxcbiAgICAgIHRlc3RNZXNzYWdlLFxuICAgICAgdGVzdFJ1blJlc3VsdCxcbiAgICAgIGNvbXBsZXRlc0luSXBjLFxuICAgICAgcmZoMkhlYWRlcixcbiAgICAgIGNvbW1lbnQsXG4gICAgICBncm91cCxcbiAgICAgIGF1dG9UZXN0LFxuICAgICAgZGVsYXllZFRlc3QsXG4gICAgICBtcVVzZXJJZGVudGlmaWVyLFxuICAgICAgbGluZWZlZWQsXG4gICAgICBqaXJhVVJMLFxuICAgICAgZGVwYXJ0bWVudENvZGUsXG4gICAgfSA9IHRlc3RDYXNlO1xuXG4gICAgLy8gdXBkYXRlIGJ1c190ZXN0X2Nhc2VzIHNldCB0ZXN0X21lc3NhZ2UgPSAkMiB3aGVyZSB0ZXN0X2Nhc2VfaWQgPSAkMTtcbiAgICBjb25zdCBxdWVyeSA9IGBcbiAgICB1cGRhdGUgYnVzX3Rlc3RfY2FzZXMgc2V0XG4gICAgY190ZXN0X2Nhc2VfbmFtZSA9ICcke25hbWV9JyxcbiAgICBjX21lc3NhZ2VfdHlwZSA9ICcke21lc3NhZ2VUeXBlfScsXG4gICAgY19mb3JtYXQgPSAnJHtmb3JtYXR9JyxcbiAgICBjX2xvYWRpbmdfcXVldWUgPSAnJHtsb2FkaW5nUXVldWV9JyxcbiAgICBjX3Rlc3RfbWVzc2FnZSA9ICR0b2tlbiQke3Rlc3RNZXNzYWdlfSR0b2tlbiQsXG4gICAgY19leHBlY3RlZF9yZXN1bHR0cmFjZSA9ICR0b2tlbiQke3Rlc3RSdW5SZXN1bHR9JHRva2VuJCxcbiAgICBjX3Rlc3Rfc3RhdHVzID0gJ25ldycsXG4gICAgY19yaGYyX2hlYWRlciA9ICR0b2tlbiQke3JmaDJIZWFkZXJ9JHRva2VuJCxcbiAgICBjX2NvbW1lbnQgPSAkdG9rZW4kJHtjb21tZW50fSR0b2tlbiQsXG4gICAgY19ncm91cF9uYW1lID0gJyR7Z3JvdXB9JyxcbiAgICBjX2xhc3RfZWRpdG9yID0gJyR7b3duZXJ9JyxcbiAgICBuX3J1bnRpbWVfaW5fc2VjID0gJHtydW5UaW1lU2VjfSxcbiAgICBuX2NvbXBsZXRlc19pbl9pcGMgPSAke2NvbXBsZXRlc0luSXBjID8gMSA6IDB9LFxuICAgIG5fYXV0b3Rlc3QgPSAke2F1dG9UZXN0ID8gMSA6IDB9LFxuICAgIG5fZGVsYXllZCA9ICR7ZGVsYXllZFRlc3QgPyAxIDogMH0sXG4gICAgY19tcW1kX3VzZXJpZGVudGlmaWVyID0gJyR7bXFVc2VySWRlbnRpZmllcn0nLFxuICAgIGNfbGluZWJyZWFrID0gJyR7bGluZWZlZWR9JyxcbiAgICBjX3Rlc3RpZF9wcmVmaXggPSAnJHt0ZXN0SWRQcmVmaXh9JyxcbiAgICBjX2ppcmFfdXJsID0gJyR7amlyYVVSTH0nLFxuICAgIGNfZGVwYXJ0bWVudF9jb2RlID0gJyR7ZGVwYXJ0bWVudENvZGV9J1xuICAgIHdoZXJlXG4gICAgY190ZXN0X2Nhc2VfaWQgPSAnJHtfaWR9J1xuICAgIGA7XG5cbiAgICAvLyBlbmFibGUgaGVyZSB0byBzZWUgaW5zZXJ0IGluIGNhc2Ugb2YgZXJyb3JzXG4gICAgY29uc29sZS5sb2coJ1VwZGF0ZSBwb3N0Z3Jlc3FsIHdpdGg6JywgcXVlcnkpO1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5xdWVyeShxdWVyeSk7XG4gICAgYXdhaXQgY2xpZW50LnJlbGVhc2UodHJ1ZSk7XG4gIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgIHRocm93IG5ldyBFcnJvcihleGNlcHRpb24ubWVzc2FnZSk7XG4gIH1cbn07XG5cbmNvbnN0IHJ1blRlc3QgPSBhc3luYyAodGVzdENhc2UpID0+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBhd2FpdCBwb29sLmNvbm5lY3QoKTtcbiAgICBjb25zdCB7XG4gICAgICBfaWQsXG4gICAgICBvd25lcixcbiAgICB9ID0gdGVzdENhc2U7XG5cbiAgICBjb25zdCBxdWVyeSA9IGBcbiAgICB1cGRhdGUgYnVzX3Rlc3RfY2FzZXMgc2V0XG4gICAgY190ZXN0X3N0YXR1cyA9ICdydW4nLFxuICAgIGNfbGFzdF9lZGl0b3IgPSAnJHtvd25lcn0nLFxuICAgIGRfdGVzdF90aW1lID0gc3RhdGVtZW50X3RpbWVzdGFtcCgpXG4gICAgd2hlcmVcbiAgICBjX3Rlc3RfY2FzZV9pZCA9ICcke19pZH0nXG4gICAgYDtcblxuICAgIGNvbnNvbGUubG9nKCdSdW50ZXN0IHdpdGggdXBkYXRlOicsIHF1ZXJ5KVxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5xdWVyeShxdWVyeSk7XG4gICAgYXdhaXQgY2xpZW50LnJlbGVhc2UodHJ1ZSk7XG4gIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgIHRocm93IG5ldyBFcnJvcihleGNlcHRpb24ubWVzc2FnZSk7XG4gIH1cbn07XG5cbmNvbnN0IHJ1blRlc3RzRmlsdGVyZWQgPSBhc3luYyAoe1xuICBncm91cCwgbG9hZGluZ1F1ZXVlLCBtZXNzYWdlVHlwZSwgb3duZXIsIGRlcGFydG1lbnRDb2RlXG59KSA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gYXdhaXQgcG9vbC5jb25uZWN0KCk7XG5cbiAgICBsZXQgcXVlcnkgPSBgXG4gICAgdXBkYXRlIGJ1c190ZXN0X2Nhc2VzIHNldFxuICAgIGNfdGVzdF9zdGF0dXMgPSAncnVuJyxcbiAgICBjX2xhc3RfZWRpdG9yID0gJyR7b3duZXJ9JyxcbiAgICBkX3Rlc3RfdGltZSA9IHN0YXRlbWVudF90aW1lc3RhbXAoKVxuICAgIHdoZXJlIDEgPSAxXG4gICAgYDtcblxuICAgIGlmIChncm91cCkge1xuICAgICAgcXVlcnkgKz0gYCBBTkQgY19ncm91cF9uYW1lID0gJyR7Z3JvdXB9J2A7XG4gICAgfVxuXG4gICAgaWYgKGxvYWRpbmdRdWV1ZSkge1xuICAgICAgcXVlcnkgKz0gYCBBTkQgY19sb2FkaW5nX3F1ZXVlID0gJyR7bG9hZGluZ1F1ZXVlfSdgO1xuICAgIH1cblxuICAgIGlmIChtZXNzYWdlVHlwZSkge1xuICAgICAgcXVlcnkgKz0gYCBBTkQgY19tZXNzYWdlX3R5cGUgPSAnJHttZXNzYWdlVHlwZX0nYDtcbiAgICB9XG5cbiAgICBpZiAoZGVwYXJ0bWVudENvZGUpIHtcbiAgICAgIHF1ZXJ5ICs9IGAgQU5EIGNfZGVwYXJ0bWVudF9jb2RlID0gJyR7ZGVwYXJ0bWVudENvZGV9J2A7XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coJ1J1bnRlc3RGaWx0ZXJlZCB3aXRoIHVwZGF0ZTonLCBxdWVyeSlcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQucXVlcnkocXVlcnkpO1xuICAgIGF3YWl0IGNsaWVudC5yZWxlYXNlKHRydWUpO1xuICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoZXhjZXB0aW9uLm1lc3NhZ2UpO1xuICB9XG59O1xuXG5jb25zdCBkZWxldGVUZXN0Q2FzZSA9IGFzeW5jICh0ZXN0Q2FzZSkgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IHBvb2wuY29ubmVjdCgpO1xuICAgIGNvbnN0IHtcbiAgICAgIF9pZCxcbiAgICB9ID0gdGVzdENhc2U7XG5cbiAgICBjb25zdCBxdWVyeSA9IGBcbiAgICAgIGRlbGV0ZSBmcm9tIGJ1c190ZXN0X2Nhc2VzXG4gICAgICB3aGVyZSBjX3Rlc3RfY2FzZV9pZCA9ICcke19pZH0nXG4gICAgYDtcblxuICAgIGNvbnNvbGUubG9nKCdEZWxldGVUZXN0Q2FzZSB3aXRoIHNxbDogJywgcXVlcnkpO1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGZldGNoKHF1ZXJ5KTtcbiAgICBhd2FpdCBjbGllbnQucmVsZWFzZSh0cnVlKVxuICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoZXhjZXB0aW9uLm1lc3NhZ2UpO1xuICB9XG59O1xuXG5jb25zdCBhY2NlcHRUZXN0UmVzdWx0ID0gYXN5bmMgKHRlc3RDYXNlKSA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gYXdhaXQgcG9vbC5jb25uZWN0KCk7XG4gICAgY29uc3Qge1xuICAgICAgX2lkLFxuICAgICAgdGVzdFJ1blJlc3VsdCxcbiAgICB9ID0gdGVzdENhc2U7XG5cbiAgICBjb25zdCBxdWVyeSA9IGBcbiAgICB1cGRhdGUgYnVzX3Rlc3RfY2FzZXMgc2V0XG4gICAgY19leHBlY3RlZF9yZXN1bHR0cmFjZSA9ICR0b2tlbiQke3Rlc3RSdW5SZXN1bHR9JHRva2VuJFxuICAgIHdoZXJlXG4gICAgY190ZXN0X2Nhc2VfaWQgPSAnJHtfaWR9J1xuICAgIGA7XG5cbiAgICBjb25zb2xlLmxvZygnQWNjZXB0VGVzdFJlc3VsdCB3aXRoIHNxbDogJywgcXVlcnkpO1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5xdWVyeShxdWVyeSk7XG4gICAgYXdhaXQgY2xpZW50LnJlbGVhc2UodHJ1ZSk7XG4gIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgIHRocm93IG5ldyBFcnJvcihleGNlcHRpb24ubWVzc2FnZSk7XG4gIH1cbn07XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgZmV0Y2gsXG4gIGxvYWRGcm9tUG9zdGdyZXNxbCxcbiAgaW5zZXJ0LFxuICB1cGRhdGUsXG4gIHJ1blRlc3QsXG4gIHJ1blRlc3RzRmlsdGVyZWQsXG4gIHBvbGxSZWFkeVRlc3RzLFxuICB1cGRhdGVTdGF0dXNBbmREaWZmUmVzdWx0LFxuICBkZWxldGVUZXN0Q2FzZSxcbiAgYWNjZXB0VGVzdFJlc3VsdCxcbiAgdXBkYXRlRXhwZWN0ZWRSZXN1bHQsXG59O1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgVGVzdENhc2VzIGZyb20gJy4uL1Rlc3RDYXNlcyc7XG5cbk1ldGVvci5wdWJsaXNoKCd0ZXN0Q2FzZXMnLCBmdW5jdGlvbiB0ZXN0Q2FzZXMoKSB7XG4gIHJldHVybiBUZXN0Q2FzZXMuZmluZCgpO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd0ZXN0Q2FzZXMudmlldycsIGZ1bmN0aW9uIHRlc3RDYXNlc1ZpZXcodGVzdENhc2VJZCkge1xuICBjaGVjayh0ZXN0Q2FzZUlkLCBTdHJpbmcpO1xuICByZXR1cm4gVGVzdENhc2VzLmZpbmQodGVzdENhc2VJZCk7XG59KTtcbiIsIi8qIGVzbGludC1kaXNhYmxlIGNvbnNpc3RlbnQtcmV0dXJuICovXG5cbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuY29uc3QgVGVzdENhc2VzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ1Rlc3RDYXNlcycpO1xuXG5UZXN0Q2FzZXMuYWxsb3coe1xuICBpbnNlcnQ6ICgpID0+IGZhbHNlLFxuICB1cGRhdGU6ICgpID0+IGZhbHNlLFxuICByZW1vdmU6ICgpID0+IGZhbHNlLFxufSk7XG5cblRlc3RDYXNlcy5kZW55KHtcbiAgaW5zZXJ0OiAoKSA9PiB0cnVlLFxuICB1cGRhdGU6ICgpID0+IHRydWUsXG4gIHJlbW92ZTogKCkgPT4gdHJ1ZSxcbn0pO1xuXG5UZXN0Q2FzZXMuc2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIG93bmVyOiBTaW1wbGVTY2hlbWEuUmVnRXguSWQsXG4gIG5hbWU6IFN0cmluZyxcbiAgdGVzdElkUHJlZml4OiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBqaXJhVVJMOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBtZXNzYWdlVHlwZTogU3RyaW5nLFxuICBmb3JtYXQ6IFN0cmluZyxcbiAgbG9hZGluZ1F1ZXVlOiBTdHJpbmcsXG4gIHJ1blRpbWVTZWM6IE51bWJlcixcbiAgdGVzdE1lc3NhZ2U6IFN0cmluZywgLy8gY2xvYlxuICB0ZXN0UnVuUmVzdWx0OiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LCAvLyBjbG9iXG4gIHRlc3RTdGF0dXM6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgYWxsb3dlZFZhbHVlczogWydydW4nLCAnbG9hZGluZycsICdyZWFkeScsICdwYXNzZWQnLCAnZmFpbGVkJ10sXG4gIH0sXG4gIHRlc3RTdGFydDoge1xuICAgIHR5cGU6IERhdGUsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sIC8vIGludGVybmFsXG4gIGV4cGVjdGVkUmVzdWx0OiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LCAvLyBvdmVydmlldyBub3QgZWRpdG9yXG4gIGNvbXBsZXRlc0luSXBjOiBCb29sZWFuLFxuICByZmgySGVhZGVyOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LCAvLyBjbG9iXG4gIGNvbW1lbnQ6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWUsXG4gIH0sIC8vIGNsb2IsXG4gIGdyb3VwOiBTdHJpbmcsXG4gIGF1dG9UZXN0OiBCb29sZWFuLFxuICBkZWxheWVkVGVzdDogQm9vbGVhbixcbiAgZGlmZkNvdW50OiB7XG4gICAgdHlwZTogTnVtYmVyLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBtcVVzZXJJZGVudGlmaWVyOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlLFxuICB9LFxuICBsaW5lZmVlZDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBhbGxvd2VkVmFsdWVzOiBbJ0xGJywgJ0NSTEYnXSxcbiAgfSxcbiAgaXBjTGluazoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDogdHJ1ZSxcbiAgfSxcbiAgZGVwYXJ0bWVudENvZGU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgYWxsb3dlZFZhbHVlczogWydjcycsICdmcycsICdpcycsICdzcycsICdkZXYnXSxcbiAgfSxcbn0pO1xuXG5UZXN0Q2FzZXMuYXR0YWNoU2NoZW1hKFRlc3RDYXNlcy5zY2hlbWEpO1xuXG5leHBvcnQgZGVmYXVsdCBUZXN0Q2FzZXM7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrLCBNYXRjaCB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5pbXBvcnQgVGVzdENhc2VzIGZyb20gJy4vVGVzdENhc2VzJztcbmltcG9ydCByYXRlTGltaXQgZnJvbSAnLi4vLi4vbW9kdWxlcy9yYXRlLWxpbWl0JztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAndGVzdENhc2VzLmluc2VydCc6IGZ1bmN0aW9uIHRlc3RDYXNlc0luc2VydCh0ZXN0Q2FzZSkge1xuICAgIGNoZWNrKHRlc3RDYXNlLCB7XG4gICAgICBuYW1lOiBTdHJpbmcsXG4gICAgICBtZXNzYWdlVHlwZTogU3RyaW5nLFxuICAgICAgZm9ybWF0OiBTdHJpbmcsXG4gICAgICBsb2FkaW5nUXVldWU6IFN0cmluZyxcbiAgICAgIHJ1blRpbWVTZWM6IE51bWJlcixcbiAgICAgIHRlc3RNZXNzYWdlOiBTdHJpbmcsIC8vIGNsb2JcbiAgICAgIC8vIHRlc3RSdW5SZXN1bHQ6IFN0cmluZywgLy8gY2xvYlxuICAgICAgdGVzdFN0YXR1czogU3RyaW5nLFxuICAgICAgLy8gdGVzdFN0YXJ0OiBEYXRlLFxuICAgICAgZXhwZWN0ZWRSZXN1bHQ6IFN0cmluZyxcbiAgICAgIC8vIHRlc3RSZXBvcnQ6IFN0cmluZywgLy8gY2xvYlxuICAgICAgY29tcGxldGVzSW5JcGM6IEJvb2xlYW4sXG4gICAgICAvLyBsYXN0UnVuUmVzdWx0OiBTdHJpbmcsIC8vIGNsb2JcbiAgICAgIHJmaDJIZWFkZXI6IFN0cmluZywgLy8gY2xvYlxuICAgICAgY29tbWVudDogU3RyaW5nLFxuICAgICAgZ3JvdXA6IFN0cmluZyxcbiAgICAgIGF1dG9UZXN0OiBCb29sZWFuLFxuICAgICAgZGVsYXllZFRlc3Q6IEJvb2xlYW4sXG4gICAgICBtcVVzZXJJZGVudGlmaWVyOiBTdHJpbmcsXG4gICAgICBsaW5lZmVlZDogU3RyaW5nLFxuICAgICAgZGVwYXJ0bWVudENvZGU6IFN0cmluZyxcbiAgICAgIHRlc3RJZFByZWZpeDogTWF0Y2guTWF5YmUoU3RyaW5nKSxcbiAgICAgIGppcmFVUkw6IE1hdGNoLk1heWJlKFN0cmluZyksXG4gICAgfSk7XG4gICAgLy8gY29uc29sZS5sb2coJ21ldGhvZHMudGVzdENhc2VzLmluc2VydDogJywgdGVzdENhc2UpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IF9pZCA9IFRlc3RDYXNlcy5pbnNlcnQoeyBvd25lcjogdGhpcy51c2VySWQsIC4uLnRlc3RDYXNlIH0pO1xuICAgICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgICBpbXBvcnQoJy4vc2VydmVyL3Bvc3RncmVzJykudGhlbigoe2RlZmF1bHQ6IHBvc3RncmVzfSkgPT4ge1xuICAgICAgICAgIHBvc3RncmVzLmluc2VydCh7IF9pZCwgb3duZXI6IHRoaXMudXNlcklkLCAuLi50ZXN0Q2FzZSB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gX2lkO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICd0ZXN0Q2FzZXMudXBkYXRlJzogZnVuY3Rpb24gdGVzdENhc2VzVXBkYXRlKHRlc3RDYXNlKSB7XG4gICAgICBjaGVjayh0ZXN0Q2FzZSwge1xuICAgICAgX2lkOiBTdHJpbmcsXG4gICAgICBuYW1lOiBTdHJpbmcsXG4gICAgICBtZXNzYWdlVHlwZTogU3RyaW5nLFxuICAgICAgZm9ybWF0OiBTdHJpbmcsXG4gICAgICBsb2FkaW5nUXVldWU6IFN0cmluZyxcbiAgICAgIHJ1blRpbWVTZWM6IE51bWJlcixcbiAgICAgIHRlc3RNZXNzYWdlOiBTdHJpbmcsIC8vIGNsb2JcbiAgICAgIC8vIHRlc3RSdW5SZXN1bHQ6IFN0cmluZywgLy8gY2xvYlxuICAgICAgdGVzdFN0YXR1czogU3RyaW5nLFxuICAgICAgLy8gdGVzdFN0YXJ0OiBEYXRlLFxuICAgICAgZXhwZWN0ZWRSZXN1bHQ6IFN0cmluZyxcbiAgICAgIC8vIHRlc3RSZXBvcnQ6IFN0cmluZywgLy8gY2xvYlxuICAgICAgY29tcGxldGVzSW5JcGM6IEJvb2xlYW4sXG4gICAgICAvLyBsYXN0UnVuUmVzdWx0OiBTdHJpbmcsIC8vIGNsb2JcbiAgICAgIHJmaDJIZWFkZXI6IFN0cmluZywgLy8gY2xvYlxuICAgICAgY29tbWVudDogU3RyaW5nLFxuICAgICAgZ3JvdXA6IFN0cmluZyxcbiAgICAgIGF1dG9UZXN0OiBCb29sZWFuLFxuICAgICAgZGVsYXllZFRlc3Q6IEJvb2xlYW4sXG4gICAgICBtcVVzZXJJZGVudGlmaWVyOiBTdHJpbmcsXG4gICAgICBsaW5lZmVlZDogU3RyaW5nLFxuICAgICAgZGVwYXJ0bWVudENvZGU6IFN0cmluZyxcbiAgICAgIHRlc3RJZFByZWZpeDogTWF0Y2guTWF5YmUoU3RyaW5nKSxcbiAgICAgIGppcmFVUkw6IE1hdGNoLk1heWJlKFN0cmluZyksXG4gICAgfSk7XG5cbiAgICBjb25zb2xlLmxvZygnbWV0aG9kcy50ZXN0Q2FzZXMudXBkYXRlOiAnLCB0ZXN0Q2FzZSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRlc3RDYXNlSWQgPSB0ZXN0Q2FzZS5faWQ7XG4gICAgICBUZXN0Q2FzZXMudXBkYXRlKHRlc3RDYXNlSWQsIHskc2V0OiB7IG93bmVyOiB0aGlzLnVzZXJJZCwgLi4udGVzdENhc2UgfSB9KTtcblxuICAgICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgICBpbXBvcnQoJy4vc2VydmVyL3Bvc3RncmVzJykudGhlbigoe2RlZmF1bHQ6IHBvc3RncmVzfSkgPT4ge1xuICAgICAgICAgIHBvc3RncmVzLnVwZGF0ZSh7IHRlc3RDYXNlSWQsIG93bmVyOiB0aGlzLnVzZXJJZCwgLi4udGVzdENhc2UgfSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRlc3RDYXNlSWQ7IC8vIFJldHVybiBfaWQgc28gd2UgY2FuIHJlZGlyZWN0IHRvIHRoZSB0ZXN0Y2FzZSBhZnRlciB1cGRhdGUuXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ3Rlc3RDYXNlcy5yZW1vdmUnOiBmdW5jdGlvbiB0ZXN0Q2FzZXNSZW1vdmUoX2lkKSB7XG4gICAgY2hlY2soX2lkLCBTdHJpbmcpO1xuXG4gICAgdHJ5IHtcbiAgICAgIC8vZmlyc3QgdHJ5IHRvIGRlbGV0ZSBmcm9tIFBvc3RncmVzcWxcbiAgICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgICAgaW1wb3J0KCcuL3NlcnZlci9wb3N0Z3JlcycpLnRoZW4oKHtkZWZhdWx0OiBwb3N0Z3Jlc30pID0+IHtcbiAgICAgICAgICBwb3N0Z3Jlcy5kZWxldGVUZXN0Q2FzZSh7X2lkfSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgLy8gdGhlbiByZW1vdmUgZnJvbSBNb25nb0RCXG4gICAgICByZXR1cm4gVGVzdENhc2VzLnJlbW92ZShfaWQpO1xuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICd0ZXN0Q2FzZXMucnVuVGVzdCc6IGZ1bmN0aW9uIHRlc3RDYXNlc1J1blRlc3QoX2lkLCBkYXRlKSB7XG4gICAgY2hlY2soX2lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKGRhdGUsIERhdGUpO1xuICAgIFxuICAgIGNvbnNvbGUubG9nKCdjYWxsZWQgcnVuVGVzdCBtZXRob2Qgb24gRW50cnk6JywgX2lkKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gVGVzdENhc2VzLnVwZGF0ZShfaWQsIHskc2V0OiB7XG4gICAgICAgIHRlc3RTdGF0dXM6ICdydW4nLFxuICAgICAgICBkaWZmQ291bnQ6ICcnLFxuICAgICAgICB0ZXN0U3RhcnQ6IGRhdGUsXG4gICAgICAgIGlwY0xpbms6ICcnLFxuICAgICAgfX0pO1xuXG4gICAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICAgIGltcG9ydCgnLi9zZXJ2ZXIvcG9zdGdyZXMnKS50aGVuKCh7ZGVmYXVsdDogcG9zdGdyZXN9KSA9PiB7XG4gICAgICAgICAgcG9zdGdyZXMucnVuVGVzdCh7X2lkLCBvd25lcjogdGhpcy51c2VySWR9KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSBjYXRjaChleGNlcHRpb24pIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJzUwMCcsIGV4Y2VwdGlvbik7XG4gICAgfVxuICB9LFxuICAndGVzdENhc2VzLmFjY2VwdFRlc3RSZXN1bHQnOiBmdW5jdGlvbiB0ZXN0Q2FzZXNBY2NlcHRUZXN0UmVzdWx0KF9pZCkge1xuICAgIGNoZWNrKF9pZCwgU3RyaW5nKTtcblxuICAgIGNvbnNvbGUubG9nKCdjYWxsZWQgYWNjZXB0VGVzdFJlc3VsdCBtZXRob2Qgb24gRW50cnk6JywgX2lkKTtcbiAgICB0cnkge1xuICAgICAgY29uc3Qge3Rlc3RSdW5SZXN1bHR9ID0gVGVzdENhc2VzLmZpbmRPbmUoX2lkKTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFRlc3RDYXNlcy51cGRhdGUoX2lkLCB7JHNldDoge1xuICAgICAgICBleHBlY3RlZFJlc3VsdDogdGVzdFJ1blJlc3VsdCxcbiAgICAgICAgZGlmZkNvdW50OiAwLFxuICAgICAgICB0ZXN0U3RhdHVzOiAncGFzc2VkJyxcbiAgICAgIH19KTtcblxuICAgICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgICBpbXBvcnQoJy4vc2VydmVyL3Bvc3RncmVzJykudGhlbigoe2RlZmF1bHQ6IHBvc3RncmVzfSkgPT4ge1xuICAgICAgICAgIHBvc3RncmVzLmFjY2VwdFRlc3RSZXN1bHQoe19pZCwgdGVzdFJ1blJlc3VsdH0pO1xuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9IGNhdGNoKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG4gICd0ZXN0Q2FzZXMucnVuVGVzdHNGaWx0ZXJlZCc6IGZ1bmN0aW9uIHRlc3RDYXNlc1J1blRlc3RzRmlsdGVyZWQocGFyYW1zKSB7XG4gICAgY2hlY2socGFyYW1zLCB7XG4gICAgICBncm91cDogTWF0Y2guTWF5YmUoU3RyaW5nKSxcbiAgICAgIGxvYWRpbmdRdWV1ZTogTWF0Y2guTWF5YmUoU3RyaW5nKSxcbiAgICAgIG1lc3NhZ2VUeXBlOiBNYXRjaC5NYXliZShTdHJpbmcpLFxuICAgICAgZGVwYXJ0bWVudENvZGU6IE1hdGNoLk1heWJlKFN0cmluZyksXG4gICAgfSk7XG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKCk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdXBkYXRlUGFyYW1zID0ge307XG5cbiAgICAgIGlmIChwYXJhbXMuZ3JvdXApIHtcbiAgICAgICAgdXBkYXRlUGFyYW1zLmdyb3VwID0gcGFyYW1zLmdyb3VwO1xuICAgICAgfVxuXG4gICAgICBpZiAocGFyYW1zLmxvYWRpbmdRdWV1ZSkge1xuICAgICAgICB1cGRhdGVQYXJhbXMubG9hZGluZ1F1ZXVlID0gcGFyYW1zLmxvYWRpbmdRdWV1ZTtcbiAgICAgIH1cblxuICAgICAgaWYgKHBhcmFtcy5tZXNzYWdlVHlwZSkge1xuICAgICAgICB1cGRhdGVQYXJhbXMubWVzc2FnZVR5cGUgPSBwYXJhbXMubWVzc2FnZVR5cGU7XG4gICAgICB9XG5cbiAgICAgIGlmIChwYXJhbXMuZGVwYXJ0bWVudENvZGUpIHtcbiAgICAgICAgdXBkYXRlUGFyYW1zLmRlcGFydG1lbnRDb2RlID0gcGFyYW1zLmRlcGFydG1lbnRDb2RlO1xuICAgICAgfVxuXG4gICAgICBjb25zdCByZXN1bHQgPSBUZXN0Q2FzZXMudXBkYXRlKHVwZGF0ZVBhcmFtcywgeyRzZXQ6IHsgb3duZXI6IHRoaXMudXNlcklkLCB0ZXN0U3RhdHVzOiAncnVuJywgZGlmZkNvdW50OiAnJywgdGVzdFN0YXJ0OiBkYXRlLCBpcGNMaW5rOiAnJywgfSB9LCB7IG11bHRpOiB0cnVlIH0pO1xuICAgICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgICBpbXBvcnQoJy4vc2VydmVyL3Bvc3RncmVzJykudGhlbigoe2RlZmF1bHQ6IHBvc3RncmVzfSkgPT4ge1xuICAgICAgICAgIHBvc3RncmVzLnJ1blRlc3RzRmlsdGVyZWQoey4uLnBhcmFtcywgb3duZXI6IHRoaXMudXNlcklkfSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2goZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfSxcbiAgJ3Rlc3RDYXNlcy5jb3B5JzogZnVuY3Rpb24gdGVzdENhc2VzQ29weShvbGRUZXN0Q2FzZUlkKSB7XG4gICAgY2hlY2sob2xkVGVzdENhc2VJZCwgU3RyaW5nKTtcblxuICAgIGNvbnN0IHRlc3RDYXNlID0gVGVzdENhc2VzLmZpbmRPbmUob2xkVGVzdENhc2VJZCk7XG4gICAgZGVsZXRlIHRlc3RDYXNlLl9pZDtcblxuICAgIC8vY3JlYXRlIG5ldyBOYW1lIHZhbHVlIHdpdGggQ09QWSBzdHJpbmdcbiAgICBjb25zdCBuYW1lID0gdGVzdENhc2UubmFtZSArICcgQ29weSc7XG4gICAgY29uc3QgY291bnQgPSBUZXN0Q2FzZXMuZmluZCh7bmFtZTogbmV3IFJlZ0V4cChgXiR7bmFtZX1gKX0pLmNvdW50KCk7XG5cbiAgICBjb25zdCBuZXdUZXN0Q2FzZSA9IHtcbiAgICAgIC4uLnRlc3RDYXNlLFxuICAgICAgbmFtZTogbmFtZSArIGAgJHtjb3VudCA/IGNvdW50ICsgMSA6ICcnfWAsXG4gICAgfTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBfaWQgPSBUZXN0Q2FzZXMuaW5zZXJ0KHsgb3duZXI6IHRoaXMudXNlcklkLCAuLi5uZXdUZXN0Q2FzZSB9KTtcbiAgICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgICAgaW1wb3J0KCcuL3NlcnZlci9wb3N0Z3JlcycpLnRoZW4oKHtkZWZhdWx0OiBwb3N0Z3Jlc30pID0+IHtcbiAgICAgICAgICBwb3N0Z3Jlcy5pbnNlcnQoeyBfaWQsIG93bmVyOiB0aGlzLnVzZXJJZCwgLi4ubmV3VGVzdENhc2UgfSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIF9pZDtcbiAgICB9IGNhdGNoKGV4Y2VwdGlvbikge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignNTAwJywgZXhjZXB0aW9uKTtcbiAgICB9XG4gIH0sXG5cbiAgJ2ltcG9ydFBvc3RncmVzSW5mbyc6IGZ1bmN0aW9uIGltcG9ydFBvc3RncmVzSW5mbygpIHtcbiAgICB0cnkge1xuICAgICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgICBpbXBvcnQoJy4vc2VydmVyL3Bvc3RncmVzJykudGhlbigoe2RlZmF1bHQ6IHBvc3RncmVzfSkgPT4ge1xuICAgICAgICAgIHBvc3RncmVzLmxvYWRGcm9tUG9zdGdyZXNxbCh0aGlzLnVzZXJJZCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2goZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgIH1cbiAgfVxufSk7XG5cbnJhdGVMaW1pdCh7XG4gIG1ldGhvZHM6IFtcbiAgICAndGVzdENhc2VzLmluc2VydCcsXG4gICAgJ3Rlc3RDYXNlcy51cGRhdGUnLFxuICAgICd0ZXN0Q2FzZXMucmVtb3ZlJyxcbiAgXSxcbiAgbGltaXQ6IDUsXG4gIHRpbWVSYW5nZTogMTAwMCxcbn0pO1xuIiwiLyogZXNsaW50LWRpc2FibGUgY29uc2lzdGVudC1yZXR1cm4gKi9cblxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbmxldCBhY3Rpb247XG5cbmNvbnN0IHVwZGF0ZVVzZXIgPSAodXNlcklkLCB7IGVtYWlsQWRkcmVzcywgcHJvZmlsZSB9KSA9PiB7XG4gIHRyeSB7XG4gICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh1c2VySWQsIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgJ2VtYWlscy4wLmFkZHJlc3MnOiBlbWFpbEFkZHJlc3MsXG4gICAgICAgIHByb2ZpbGUsXG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYFtlZGl0UHJvZmlsZS51cGRhdGVVc2VyXSAke2V4Y2VwdGlvbi5tZXNzYWdlfWApO1xuICB9XG59O1xuXG5jb25zdCBlZGl0UHJvZmlsZSA9ICh7IHVzZXJJZCwgcHJvZmlsZSB9LCBwcm9taXNlKSA9PiB7XG4gIHRyeSB7XG4gICAgYWN0aW9uID0gcHJvbWlzZTtcbiAgICB1cGRhdGVVc2VyKHVzZXJJZCwgcHJvZmlsZSk7XG4gICAgYWN0aW9uLnJlc29sdmUoKTtcbiAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgYWN0aW9uLnJlamVjdChleGNlcHRpb24ubWVzc2FnZSk7XG4gIH1cbn07XG5cbmV4cG9ydCBkZWZhdWx0IG9wdGlvbnMgPT5cbiAgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT5cbiAgICBlZGl0UHJvZmlsZShvcHRpb25zLCB7IHJlc29sdmUsIHJlamVjdCB9KSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuaW1wb3J0IGVkaXRQcm9maWxlIGZyb20gJy4vZWRpdC1wcm9maWxlJztcbmltcG9ydCByYXRlTGltaXQgZnJvbSAnLi4vLi4vLi4vbW9kdWxlcy9yYXRlLWxpbWl0JztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAndXNlcnMuc2VuZFZlcmlmaWNhdGlvbkVtYWlsJzogZnVuY3Rpb24gdXNlcnNTZW5kVmVyaWZpY2F0aW9uRW1haWwoKSB7XG4gICAgcmV0dXJuIEFjY291bnRzLnNlbmRWZXJpZmljYXRpb25FbWFpbCh0aGlzLnVzZXJJZCk7XG4gIH0sXG4gICd1c2Vycy5lZGl0UHJvZmlsZSc6IGZ1bmN0aW9uIHVzZXJzRWRpdFByb2ZpbGUocHJvZmlsZSkge1xuICAgIGNoZWNrKHByb2ZpbGUsIHtcbiAgICAgIGVtYWlsQWRkcmVzczogU3RyaW5nLFxuICAgICAgcHJvZmlsZToge1xuICAgICAgICBuYW1lOiB7XG4gICAgICAgICAgZmlyc3Q6IFN0cmluZyxcbiAgICAgICAgICBsYXN0OiBTdHJpbmcsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGVkaXRQcm9maWxlKHsgdXNlcklkOiB0aGlzLnVzZXJJZCwgcHJvZmlsZSB9KVxuICAgICAgLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UpXG4gICAgICAuY2F0Y2goKGV4Y2VwdGlvbikgPT4ge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCc1MDAnLCBleGNlcHRpb24pO1xuICAgICAgfSk7XG4gIH0sXG59KTtcblxucmF0ZUxpbWl0KHtcbiAgbWV0aG9kczogW1xuICAgICd1c2Vycy5zZW5kVmVyaWZpY2F0aW9uRW1haWwnLFxuICAgICd1c2Vycy5lZGl0UHJvZmlsZScsXG4gIF0sXG4gIGxpbWl0OiA1LFxuICB0aW1lUmFuZ2U6IDEwMDAsXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5NZXRlb3IucHVibGlzaCgndXNlcnMuZWRpdFByb2ZpbGUnLCBmdW5jdGlvbiB1c2Vyc1Byb2ZpbGUoKSB7XG4gIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh0aGlzLnVzZXJJZCwge1xuICAgIGZpZWxkczoge1xuICAgICAgZW1haWxzOiAxLFxuICAgICAgcHJvZmlsZTogMSxcbiAgICAgIHNlcnZpY2VzOiAxLFxuICAgIH0sXG4gIH0pO1xufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCBnZXRQcml2YXRlRmlsZSBmcm9tICcuLi8uLi8uLi9tb2R1bGVzL3NlcnZlci9nZXQtcHJpdmF0ZS1maWxlJztcbmltcG9ydCBwYXJzZU1hcmtkb3duIGZyb20gJy4uLy4uLy4uL21vZHVsZXMvcGFyc2UtbWFya2Rvd24nO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICd1dGlsaXR5LmdldFBhZ2UnOiBmdW5jdGlvbiB1dGlsaXR5R2V0UGFnZShmaWxlTmFtZSkge1xuICAgIGNoZWNrKGZpbGVOYW1lLCBTdHJpbmcpO1xuICAgIHJldHVybiBwYXJzZU1hcmtkb3duKGdldFByaXZhdGVGaWxlKGBwYWdlcy8ke2ZpbGVOYW1lfS5tZGApKTtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0ICcuL29uLWNyZWF0ZS11c2VyLmpzJztcbiIsImltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuXG5BY2NvdW50cy5vbkNyZWF0ZVVzZXIoKG9wdGlvbnMsIHVzZXIpID0+IHtcbiAgY29uc3QgdXNlclRvQ3JlYXRlID0gdXNlcjtcbiAgaWYgKG9wdGlvbnMucHJvZmlsZSkgdXNlclRvQ3JlYXRlLnByb2ZpbGUgPSBvcHRpb25zLnByb2ZpbGU7XG4gIHJldHVybiB1c2VyVG9DcmVhdGU7XG59KTtcbiIsImltcG9ydCAnLi4vLi4vYXBpL0RvY3VtZW50cy9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL1Rlc3RDYXNlcy9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL0dyb3Vwcy9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL1F1ZXVlcy9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL01lc3NhZ2VUeXBlcy9zZXJ2ZXIvcHVibGljYXRpb25zJztcbmltcG9ydCAnLi4vLi4vYXBpL0Zvcm1hdHMvc2VydmVyL3B1YmxpY2F0aW9ucyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9EZXBhcnRtZW50Q29kZXMvc2VydmVyL3B1YmxpY2F0aW9ucyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL09BdXRoL3NlcnZlci9tZXRob2RzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvVXNlcnMvc2VydmVyL21ldGhvZHMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvVXNlcnMvc2VydmVyL3B1YmxpY2F0aW9ucyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL1V0aWxpdHkvc2VydmVyL21ldGhvZHMnO1xuXG5pbXBvcnQgcG9zdGdyZXMgZnJvbSAnLi4vLi4vYXBpL1Rlc3RDYXNlcy9zZXJ2ZXIvcG9zdGdyZXMnO1xuaW1wb3J0IFRlc3RDYXNlcyBmcm9tICcuLi8uLi9hcGkvVGVzdENhc2VzL1Rlc3RDYXNlcyc7XG5cblxuY29uc3QgdGVzdENhc2UgPSB7XG4gIF9pZDogJ19pZCcsXG4gIG93bmVyOiAnb3duZXInLFxuICBuYW1lOiAnbmFtZScsXG4gIG1lc3NhZ2VUeXBlOiAnbWVzc2FnZVR5cGUnLFxuICBmb3JtYXQ6ICdmb3JtYXQnLFxuICBsb2FkaW5nUXVldWU6ICdsb2FkaW5nUXVldWUnLFxuICBydW5UaW1lU2VjOiA2MCxcbiAgdGVzdE1lc3NhZ2U6ICd0ZXN0TWVzc2FnZScsXG4gIGNvbXBsZXRlc0luSXBjOiB0cnVlLFxuICByZmgySGVhZGVyOiAncmZoMkhlYWRlcicsXG4gIGNvbW1lbnQ6ICdjb21tZW50JyxcbiAgZ3JvdXA6ICdncm91cCcsXG4gIGRlcGFydG1lbnRDb2RlOiAnZGVwYXJ0bWVudENvZGUnLFxuICBhdXRvVGVzdDogdHJ1ZSxcbn07XG5cblxuLy8gcG9zdGdyZXMuaW5zZXJ0KHRlc3RDYXNlKTtcblxuLy8gcG9zdGdyZXMuZmV0Y2goYFxuLy8gICBzZWxlY3QgZmtfdGVzdF9jYXNlX2lkIGFzIHRlc3RDYXNlSWQsXG4vLyAgIHJlc3VsdCBhcyBleHBlY3RlZFJlc3VsdFxuLy8gICBmcm9tIGJ1c190ZXN0X3J1bnNcbi8vICAgd2hlcmUgcnVuc3RhdGUgPSAncmVhZHknXG4vLyBgKTtcblxuLy8gcG9zdGdyZXMudXBkYXRlKHsuLi50ZXN0Q2FzZSwgdGVzdE1lc3NhZ2U6ICduZXcgdGVzdCBtZXNzYWdlJ30pO1xuXG4vLyBwb3N0Z3Jlcy5ydW5UZXN0KHRlc3RDYXNlKTtcblxuLy8gcG9zdGdyZXMucG9sbFJlYWR5VGVzdHMoKTtcbiIsImltcG9ydCB7IFN5bmNlZENyb24gfSBmcm9tICdtZXRlb3IvcGVyY29sYXRlOnN5bmNlZC1jcm9uJztcblxuaW1wb3J0IHBvc3RncmVzIGZyb20gJy4uLy4uL2FwaS9UZXN0Q2FzZXMvc2VydmVyL3Bvc3RncmVzJztcblxuU3luY2VkQ3Jvbi5jb25maWcoe1xuICBsb2c6IGZhbHNlLFxufSk7XG5cblN5bmNlZENyb24uYWRkKHtcbiAgbmFtZTogJ1BvbGwgcG9zdGdyZXMnLFxuICBzY2hlZHVsZShwYXJzZXIpIHtcbiAgICByZXR1cm4gcGFyc2VyLnRleHQoJ2V2ZXJ5IDEgbWludXRlJyk7XG4gIH0sXG4gIGpvYigpIHtcbiAgICByZXR1cm4gcG9zdGdyZXMucG9sbFJlYWR5VGVzdHMoKTtcbiAgfSxcbn0pO1xuXG5TeW5jZWRDcm9uLnN0YXJ0KCk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuaWYgKE1ldGVvci5pc0RldmVsb3BtZW50KSBwcm9jZXNzLmVudi5NQUlMX1VSTCA9IE1ldGVvci5zZXR0aW5ncy5wcml2YXRlLk1BSUxfVVJMO1xuIiwiaW1wb3J0IHNlZWRlciBmcm9tICdAY2xldmVyYmVhZ2xlL3NlZWRlcic7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBEb2N1bWVudHMgZnJvbSAnLi4vLi4vYXBpL0RvY3VtZW50cy9Eb2N1bWVudHMnO1xuXG5jb25zdCBkb2N1bWVudHNTZWVkID0gdXNlcklkID0+ICh7XG4gIGNvbGxlY3Rpb246IERvY3VtZW50cyxcbiAgZW52aXJvbm1lbnRzOiBbJ2RldmVsb3BtZW50JywgJ3N0YWdpbmcnXSxcbiAgbm9MaW1pdDogdHJ1ZSxcbiAgbW9kZWxDb3VudDogNSxcbiAgbW9kZWwoZGF0YUluZGV4KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG93bmVyOiB1c2VySWQsXG4gICAgICB0aXRsZTogYERvY3VtZW50ICMke2RhdGFJbmRleCArIDF9YCxcbiAgICAgIGJvZHk6IGBUaGlzIGlzIHRoZSBib2R5IG9mIGRvY3VtZW50ICMke2RhdGFJbmRleCArIDF9YCxcbiAgICB9O1xuICB9LFxufSk7XG5cbnNlZWRlcihNZXRlb3IudXNlcnMsIHtcbiAgZW52aXJvbm1lbnRzOiBbJ2RldmVsb3BtZW50JywgJ3N0YWdpbmcnXSxcbiAgbm9MaW1pdDogdHJ1ZSxcbiAgZGF0YTogW3tcbiAgICBlbWFpbDogJ2FkbWluQGFkbWluLmNvbScsXG4gICAgcGFzc3dvcmQ6ICdwYXNzd29yZCcsXG4gICAgcHJvZmlsZToge1xuICAgICAgbmFtZToge1xuICAgICAgICBmaXJzdDogJ0FuZHknLFxuICAgICAgICBsYXN0OiAnV2FyaG9sJyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICByb2xlczogWydhZG1pbiddLFxuICAgIGRhdGEodXNlcklkKSB7XG4gICAgICByZXR1cm4gZG9jdW1lbnRzU2VlZCh1c2VySWQpO1xuICAgIH0sXG4gIH1dLFxuICBtb2RlbENvdW50OiA1LFxuICBtb2RlbChpbmRleCwgZmFrZXIpIHtcbiAgICBjb25zdCB1c2VyQ291bnQgPSBpbmRleCArIDE7XG4gICAgcmV0dXJuIHtcbiAgICAgIGVtYWlsOiBgdXNlciske3VzZXJDb3VudH1AdGVzdC5jb21gLFxuICAgICAgcGFzc3dvcmQ6ICdwYXNzd29yZCcsXG4gICAgICBwcm9maWxlOiB7XG4gICAgICAgIG5hbWU6IHtcbiAgICAgICAgICBmaXJzdDogZmFrZXIubmFtZS5maXJzdE5hbWUoKSxcbiAgICAgICAgICBsYXN0OiBmYWtlci5uYW1lLmxhc3ROYW1lKCksXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgcm9sZXM6IFsndXNlciddLFxuICAgICAgZGF0YSh1c2VySWQpIHtcbiAgICAgICAgcmV0dXJuIGRvY3VtZW50c1NlZWQodXNlcklkKTtcbiAgICAgIH0sXG4gICAgfTtcbiAgfSxcbn0pO1xuIiwiaW1wb3J0ICcuL2FjY291bnRzJztcbmltcG9ydCAnLi4vYm90aC9hcGknO1xuaW1wb3J0ICcuL2FwaSc7XG5pbXBvcnQgJy4vZml4dHVyZXMnO1xuaW1wb3J0ICcuL2VtYWlsJztcbmltcG9ydCAnLi9jcm9uJztcbiIsImltcG9ydCAnLi4vLi4vYXBpL0RvY3VtZW50cy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL1Rlc3RDYXNlcy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL0dyb3Vwcy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL1F1ZXVlcy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL01lc3NhZ2VUeXBlcy9tZXRob2RzJztcbmltcG9ydCAnLi4vLi4vYXBpL0Zvcm1hdHMvbWV0aG9kcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9EZXBhcnRtZW50Q29kZXMvbWV0aG9kcyc7XG4iLCJpbXBvcnQgZnMgZnJvbSAnZnMnO1xuXG5leHBvcnQgZGVmYXVsdCBwYXRoID0+IGZzLnJlYWRGaWxlU3luYyhgYXNzZXRzL2FwcC8ke3BhdGh9YCwgJ3V0ZjgnKTtcbiIsImltcG9ydCB7IFBhcnNlciwgSHRtbFJlbmRlcmVyIH0gZnJvbSAnY29tbW9ubWFyayc7XG5cbmV4cG9ydCBkZWZhdWx0IChtYXJrZG93biwgb3B0aW9ucykgPT4ge1xuICBjb25zdCByZWFkZXIgPSBuZXcgUGFyc2VyKCk7XG4gIGNvbnN0IHdyaXRlciA9IG9wdGlvbnMgPyBuZXcgSHRtbFJlbmRlcmVyKG9wdGlvbnMpIDogbmV3IEh0bWxSZW5kZXJlcigpO1xuICBjb25zdCBwYXJzZWQgPSByZWFkZXIucGFyc2UobWFya2Rvd24pO1xuICByZXR1cm4gd3JpdGVyLnJlbmRlcihwYXJzZWQpO1xufTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgRERQUmF0ZUxpbWl0ZXIgfSBmcm9tICdtZXRlb3IvZGRwLXJhdGUtbGltaXRlcic7XG5cbmV4cG9ydCBkZWZhdWx0ICh7IG1ldGhvZHMsIGxpbWl0LCB0aW1lUmFuZ2UgfSkgPT4ge1xuICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgRERQUmF0ZUxpbWl0ZXIuYWRkUnVsZSh7XG4gICAgICBuYW1lKG5hbWUpIHsgcmV0dXJuIG1ldGhvZHMuaW5kZXhPZihuYW1lKSA+IC0xOyB9LFxuICAgICAgY29ubmVjdGlvbklkKCkgeyByZXR1cm4gdHJ1ZTsgfSxcbiAgICB9LCBsaW1pdCwgdGltZVJhbmdlKTtcbiAgfVxufTtcbiIsImltcG9ydCAnLi4vaW1wb3J0cy9zdGFydHVwL3NlcnZlcic7XG4iXX0=
