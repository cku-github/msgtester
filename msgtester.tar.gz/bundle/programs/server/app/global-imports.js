/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
ReactiveVar = Package['reactive-var'].ReactiveVar;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
ECMAScript = Package.ecmascript.ECMAScript;
ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;
Roles = Package['alanning:roles'].Roles;
Accounts = Package['accounts-base'].Accounts;
ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
Bert = Package['themeteorchef:bert'].Bert;
Collection2 = Package['aldeed:collection2-core'].Collection2;
DDPRateLimiter = Package['ddp-rate-limiter'].DDPRateLimiter;
SyncedCron = Package['percolate:synced-cron'].SyncedCron;
OAuth = Package.oauth.OAuth;
Oauth = Package.oauth.Oauth;
_ = Package.underscore._;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
WebAppInternals = Package.webapp.WebAppInternals;
main = Package.webapp.main;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
meteorInstall = Package.modules.meteorInstall;
meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
Promise = Package.promise.Promise;
Facebook = Package['facebook-oauth'].Facebook;
Github = Package['github-oauth'].Github;
Google = Package['google-oauth'].Google;
Autoupdate = Package.autoupdate.Autoupdate;

